namespace SMKMart
{
    partial class FormLogin
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlKiri = new System.Windows.Forms.Panel();
            this.lblLogoSmk = new System.Windows.Forms.Label();
            this.lblLogoMart = new SMKMart.Controls.RoundedLabel();
            this.lblTagline = new System.Windows.Forms.Label();
            this.pnlStruk = new SMKMart.Controls.RoundedPanel();
            this.lblStruk = new System.Windows.Forms.Label();
            this.pnlKanan = new System.Windows.Forms.Panel();
            this.lblMasuk = new System.Windows.Forms.Label();
            this.lblSubMasuk = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.txtUser = new SMKMart.Controls.RoundedTextBox();
            this.lblSandi = new System.Windows.Forms.Label();
            this.txtPass = new SMKMart.Controls.RoundedTextBox();
            this.lblLihat = new System.Windows.Forms.Label();
            this.chkIngat = new System.Windows.Forms.CheckBox();
            this.lnkLupa = new System.Windows.Forms.LinkLabel();
            this.btnMasuk = new SMKMart.Controls.RoundedButton();
            this.lblBelum = new System.Windows.Forms.Label();
            this.lnkDaftar = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            this.pnlKiri.SuspendLayout();
            this.pnlStruk.SuspendLayout();
            this.pnlKanan.SuspendLayout();
            //
            // pnlKiri
            //
            this.pnlKiri.Location = new System.Drawing.Point(0, 0);
            this.pnlKiri.Size = new System.Drawing.Size(468, 656);
            this.pnlKiri.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.pnlKiri.Name = "pnlKiri";
            this.pnlKiri.Controls.Add(this.lblLogoSmk);
            this.pnlKiri.Controls.Add(this.lblLogoMart);
            this.pnlKiri.Controls.Add(this.lblTagline);
            this.pnlKiri.Controls.Add(this.pnlStruk);
            // lblLogoSmk
            //
            this.lblLogoSmk.Location = new System.Drawing.Point(40, 36);
            this.lblLogoSmk.AutoSize = true;
            this.lblLogoSmk.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.lblLogoSmk.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblLogoSmk.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblLogoSmk.Text = "SMK";
            this.lblLogoSmk.Name = "lblLogoSmk";
            // lblLogoMart
            //
            this.lblLogoMart.Location = new System.Drawing.Point(116, 34);
            this.lblLogoMart.Size = new System.Drawing.Size(84, 40);
            this.lblLogoMart.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblLogoMart.ForeColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.lblLogoMart.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblLogoMart.Radius = 8;
            this.lblLogoMart.Text = "Mart";
            this.lblLogoMart.Name = "lblLogoMart";
            // lblTagline
            //
            this.lblTagline.Location = new System.Drawing.Point(40, 150);
            this.lblTagline.AutoSize = true;
            this.lblTagline.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.lblTagline.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblTagline.Font = new System.Drawing.Font("Segoe UI", 28F, System.Drawing.FontStyle.Bold);
            this.lblTagline.Text = "Belanja kebutuhan\r\nsekolah, tanpa\r\nantre.";
            this.lblTagline.Name = "lblTagline";
            // pnlStruk
            //
            this.pnlStruk.Location = new System.Drawing.Point(40, 400);
            this.pnlStruk.Size = new System.Drawing.Size(290, 172);
            this.pnlStruk.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.pnlStruk.FillColor = System.Drawing.Color.FromArgb(251, 247, 236);
            this.pnlStruk.Radius = 4;
            this.pnlStruk.Name = "pnlStruk";
            this.pnlStruk.Controls.Add(this.lblStruk);
            // lblStruk
            //
            this.lblStruk.Location = new System.Drawing.Point(14, 14);
            this.lblStruk.AutoSize = true;
            this.lblStruk.BackColor = System.Drawing.Color.FromArgb(251, 247, 236);
            this.lblStruk.ForeColor = System.Drawing.Color.FromArgb(34, 34, 34);
            this.lblStruk.Font = new System.Drawing.Font("Courier New", 9F);
            this.lblStruk.Text = "           SMKMART            \r\n        Struk Belanja         \r\n------------------------------\r\n2 Buku tulis             9.000\r\n1 Pulpen hitam           3.500\r\n1 Roti cokelat           6.500\r\n------------------------------\r\nTotal                   19.000";
            this.lblStruk.Name = "lblStruk";
            // pnlKanan
            //
            this.pnlKanan.Location = new System.Drawing.Point(468, 0);
            this.pnlKanan.Size = new System.Drawing.Size(468, 656);
            this.pnlKanan.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlKanan.Name = "pnlKanan";
            this.pnlKanan.Controls.Add(this.lblMasuk);
            this.pnlKanan.Controls.Add(this.lblSubMasuk);
            this.pnlKanan.Controls.Add(this.lblUser);
            this.pnlKanan.Controls.Add(this.txtUser);
            this.pnlKanan.Controls.Add(this.lblSandi);
            this.pnlKanan.Controls.Add(this.txtPass);
            this.pnlKanan.Controls.Add(this.lblLihat);
            this.pnlKanan.Controls.Add(this.chkIngat);
            this.pnlKanan.Controls.Add(this.lnkLupa);
            this.pnlKanan.Controls.Add(this.btnMasuk);
            this.pnlKanan.Controls.Add(this.lblBelum);
            this.pnlKanan.Controls.Add(this.lnkDaftar);
            // lblMasuk
            //
            this.lblMasuk.Location = new System.Drawing.Point(60, 96);
            this.lblMasuk.AutoSize = true;
            this.lblMasuk.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblMasuk.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblMasuk.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            this.lblMasuk.Text = "Masuk";
            this.lblMasuk.Name = "lblMasuk";
            // lblSubMasuk
            //
            this.lblSubMasuk.Location = new System.Drawing.Point(62, 148);
            this.lblSubMasuk.AutoSize = true;
            this.lblSubMasuk.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSubMasuk.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSubMasuk.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSubMasuk.Text = "Gunakan akun SMKMart kamu.";
            this.lblSubMasuk.Name = "lblSubMasuk";
            // lblUser
            //
            this.lblUser.Location = new System.Drawing.Point(60, 196);
            this.lblUser.AutoSize = true;
            this.lblUser.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblUser.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblUser.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblUser.Text = "NIS atau username";
            this.lblUser.Name = "lblUser";
            // txtUser
            //
            this.txtUser.Location = new System.Drawing.Point(60, 222);
            this.txtUser.Size = new System.Drawing.Size(350, 46);
            this.txtUser.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.txtUser.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtUser.PlaceholderText = "mis. 2024001";
            this.txtUser.Name = "txtUser";
            // lblSandi
            //
            this.lblSandi.Location = new System.Drawing.Point(60, 286);
            this.lblSandi.AutoSize = true;
            this.lblSandi.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSandi.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblSandi.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblSandi.Text = "Kata sandi";
            this.lblSandi.Name = "lblSandi";
            // txtPass
            //
            this.txtPass.Location = new System.Drawing.Point(60, 312);
            this.txtPass.Size = new System.Drawing.Size(350, 46);
            this.txtPass.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.txtPass.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtPass.UseSystemPasswordChar = true;
            this.txtPass.RightPadding = 70;
            this.txtPass.Name = "txtPass";
            // lblLihat
            //
            this.lblLihat.Location = new System.Drawing.Point(356, 326);
            this.lblLihat.AutoSize = true;
            this.lblLihat.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.lblLihat.ForeColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblLihat.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblLihat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblLihat.Text = "Lihat";
            this.lblLihat.Name = "lblLihat";
            // chkIngat
            //
            this.chkIngat.Location = new System.Drawing.Point(58, 374);
            this.chkIngat.AutoSize = true;
            this.chkIngat.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.chkIngat.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.chkIngat.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.chkIngat.Text = "Ingat saya";
            this.chkIngat.UseVisualStyleBackColor = false;
            this.chkIngat.Name = "chkIngat";
            // lnkLupa
            //
            this.lnkLupa.Location = new System.Drawing.Point(296, 376);
            this.lnkLupa.AutoSize = true;
            this.lnkLupa.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lnkLupa.ActiveLinkColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lnkLupa.LinkColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lnkLupa.VisitedLinkColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lnkLupa.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnkLupa.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lnkLupa.Text = "Lupa kata sandi?";
            this.lnkLupa.Name = "lnkLupa";
            // btnMasuk
            //
            this.btnMasuk.Location = new System.Drawing.Point(60, 420);
            this.btnMasuk.Size = new System.Drawing.Size(350, 50);
            this.btnMasuk.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnMasuk.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnMasuk.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnMasuk.Radius = 12;
            this.btnMasuk.UseVisualStyleBackColor = false;
            this.btnMasuk.Text = "Masuk";
            this.btnMasuk.Name = "btnMasuk";
            // lblBelum
            //
            this.lblBelum.Location = new System.Drawing.Point(118, 496);
            this.lblBelum.AutoSize = true;
            this.lblBelum.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblBelum.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblBelum.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblBelum.Text = "Belum punya akun?";
            this.lblBelum.Name = "lblBelum";
            // lnkDaftar
            //
            this.lnkDaftar.Location = new System.Drawing.Point(246, 496);
            this.lnkDaftar.AutoSize = true;
            this.lnkDaftar.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lnkDaftar.ActiveLinkColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lnkDaftar.LinkColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lnkDaftar.VisitedLinkColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lnkDaftar.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnkDaftar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lnkDaftar.Text = "Daftar";
            this.lnkDaftar.Name = "lnkDaftar";
            //
            // FormLogin
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.ClientSize = new System.Drawing.Size(936, 656);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Name = "FormLogin";
            this.Controls.Add(this.pnlKiri);
            this.Controls.Add(this.pnlKanan);
            this.Text = "SMKMart - Masuk";
            this.pnlKiri.ResumeLayout(false);
            this.pnlStruk.ResumeLayout(false);
            this.pnlKanan.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel pnlKiri;
        private System.Windows.Forms.Label lblLogoSmk;
        private SMKMart.Controls.RoundedLabel lblLogoMart;
        private System.Windows.Forms.Label lblTagline;
        private SMKMart.Controls.RoundedPanel pnlStruk;
        private System.Windows.Forms.Label lblStruk;
        private System.Windows.Forms.Panel pnlKanan;
        private System.Windows.Forms.Label lblMasuk;
        private System.Windows.Forms.Label lblSubMasuk;
        private System.Windows.Forms.Label lblUser;
        private SMKMart.Controls.RoundedTextBox txtUser;
        private System.Windows.Forms.Label lblSandi;
        private SMKMart.Controls.RoundedTextBox txtPass;
        private System.Windows.Forms.Label lblLihat;
        private System.Windows.Forms.CheckBox chkIngat;
        private System.Windows.Forms.LinkLabel lnkLupa;
        private SMKMart.Controls.RoundedButton btnMasuk;
        private System.Windows.Forms.Label lblBelum;
        private System.Windows.Forms.LinkLabel lnkDaftar;
    }
}
