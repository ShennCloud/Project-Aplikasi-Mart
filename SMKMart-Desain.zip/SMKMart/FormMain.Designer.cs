namespace SMKMart
{
    partial class FormMain
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.pnlSidebar = new System.Windows.Forms.Panel();
            this.lblLogoSmk = new System.Windows.Forms.Label();
            this.lblLogoMart = new SMKMart.Controls.RoundedLabel();
            this.btnNavDashboard = new SMKMart.Controls.RoundedButton();
            this.btnNavPenjualan = new SMKMart.Controls.RoundedButton();
            this.btnNavBarang = new SMKMart.Controls.RoundedButton();
            this.btnNavGudang = new SMKMart.Controls.RoundedButton();
            this.btnNavLaporan = new SMKMart.Controls.RoundedButton();
            this.btnNavPengguna = new SMKMart.Controls.RoundedButton();
            this.pnlGarisSidebar = new SMKMart.Controls.RoundedPanel();
            this.btnKeluar = new SMKMart.Controls.RoundedButton();
            this.pnlContent = new System.Windows.Forms.Panel();
            this.ucDashboard1 = new SMKMart.Pages.ucDashboard();
            this.SuspendLayout();
            this.pnlSidebar.SuspendLayout();
            this.pnlContent.SuspendLayout();
            //
            // pnlSidebar
            //
            this.pnlSidebar.Location = new System.Drawing.Point(0, 0);
            this.pnlSidebar.Size = new System.Drawing.Size(210, 720);
            this.pnlSidebar.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.pnlSidebar.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
            this.pnlSidebar.Name = "pnlSidebar";
            this.pnlSidebar.Controls.Add(this.lblLogoSmk);
            this.pnlSidebar.Controls.Add(this.lblLogoMart);
            this.pnlSidebar.Controls.Add(this.btnNavDashboard);
            this.pnlSidebar.Controls.Add(this.btnNavPenjualan);
            this.pnlSidebar.Controls.Add(this.btnNavBarang);
            this.pnlSidebar.Controls.Add(this.btnNavGudang);
            this.pnlSidebar.Controls.Add(this.btnNavLaporan);
            this.pnlSidebar.Controls.Add(this.btnNavPengguna);
            this.pnlSidebar.Controls.Add(this.pnlGarisSidebar);
            this.pnlSidebar.Controls.Add(this.btnKeluar);
            // lblLogoSmk
            //
            this.lblLogoSmk.Location = new System.Drawing.Point(22, 22);
            this.lblLogoSmk.AutoSize = true;
            this.lblLogoSmk.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.lblLogoSmk.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblLogoSmk.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblLogoSmk.Text = "SMK";
            this.lblLogoSmk.Name = "lblLogoSmk";
            // lblLogoMart
            //
            this.lblLogoMart.Location = new System.Drawing.Point(78, 20);
            this.lblLogoMart.Size = new System.Drawing.Size(66, 34);
            this.lblLogoMart.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblLogoMart.ForeColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.lblLogoMart.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblLogoMart.Radius = 7;
            this.lblLogoMart.Text = "Mart";
            this.lblLogoMart.Name = "lblLogoMart";
            // btnNavDashboard
            //
            this.btnNavDashboard.Location = new System.Drawing.Point(12, 90);
            this.btnNavDashboard.Size = new System.Drawing.Size(186, 42);
            this.btnNavDashboard.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnNavDashboard.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnNavDashboard.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnNavDashboard.Radius = 12;
            this.btnNavDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavDashboard.TextPadding = 18;
            this.btnNavDashboard.UseVisualStyleBackColor = false;
            this.btnNavDashboard.Text = "Dashboard";
            this.btnNavDashboard.Name = "btnNavDashboard";
            // btnNavPenjualan
            //
            this.btnNavPenjualan.Location = new System.Drawing.Point(12, 140);
            this.btnNavPenjualan.Size = new System.Drawing.Size(186, 42);
            this.btnNavPenjualan.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.btnNavPenjualan.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnNavPenjualan.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnNavPenjualan.Radius = 12;
            this.btnNavPenjualan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavPenjualan.TextPadding = 18;
            this.btnNavPenjualan.UseVisualStyleBackColor = false;
            this.btnNavPenjualan.Text = "Penjualan";
            this.btnNavPenjualan.Name = "btnNavPenjualan";
            // btnNavBarang
            //
            this.btnNavBarang.Location = new System.Drawing.Point(12, 190);
            this.btnNavBarang.Size = new System.Drawing.Size(186, 42);
            this.btnNavBarang.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.btnNavBarang.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnNavBarang.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnNavBarang.Radius = 12;
            this.btnNavBarang.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavBarang.TextPadding = 18;
            this.btnNavBarang.UseVisualStyleBackColor = false;
            this.btnNavBarang.Text = "Data barang";
            this.btnNavBarang.Name = "btnNavBarang";
            // btnNavGudang
            //
            this.btnNavGudang.Location = new System.Drawing.Point(12, 240);
            this.btnNavGudang.Size = new System.Drawing.Size(186, 42);
            this.btnNavGudang.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.btnNavGudang.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnNavGudang.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnNavGudang.Radius = 12;
            this.btnNavGudang.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavGudang.TextPadding = 18;
            this.btnNavGudang.UseVisualStyleBackColor = false;
            this.btnNavGudang.Text = "Gudang";
            this.btnNavGudang.Name = "btnNavGudang";
            // btnNavLaporan
            //
            this.btnNavLaporan.Location = new System.Drawing.Point(12, 290);
            this.btnNavLaporan.Size = new System.Drawing.Size(186, 42);
            this.btnNavLaporan.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.btnNavLaporan.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnNavLaporan.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnNavLaporan.Radius = 12;
            this.btnNavLaporan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavLaporan.TextPadding = 18;
            this.btnNavLaporan.UseVisualStyleBackColor = false;
            this.btnNavLaporan.Text = "Laporan";
            this.btnNavLaporan.Name = "btnNavLaporan";
            // btnNavPengguna
            //
            this.btnNavPengguna.Location = new System.Drawing.Point(12, 340);
            this.btnNavPengguna.Size = new System.Drawing.Size(186, 42);
            this.btnNavPengguna.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.btnNavPengguna.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnNavPengguna.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnNavPengguna.Radius = 12;
            this.btnNavPengguna.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNavPengguna.TextPadding = 18;
            this.btnNavPengguna.UseVisualStyleBackColor = false;
            this.btnNavPengguna.Text = "Pengguna";
            this.btnNavPengguna.Name = "btnNavPengguna";
            // pnlGarisSidebar
            //
            this.pnlGarisSidebar.Location = new System.Drawing.Point(12, 640);
            this.pnlGarisSidebar.Size = new System.Drawing.Size(186, 1);
            this.pnlGarisSidebar.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.pnlGarisSidebar.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGarisSidebar.Radius = 0;
            this.pnlGarisSidebar.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
            this.pnlGarisSidebar.Name = "pnlGarisSidebar";
            // btnKeluar
            //
            this.btnKeluar.Location = new System.Drawing.Point(12, 654);
            this.btnKeluar.Size = new System.Drawing.Size(186, 42);
            this.btnKeluar.BackColor = System.Drawing.Color.FromArgb(10, 27, 63);
            this.btnKeluar.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnKeluar.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnKeluar.Radius = 12;
            this.btnKeluar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKeluar.TextPadding = 18;
            this.btnKeluar.UseVisualStyleBackColor = false;
            this.btnKeluar.Text = "Keluar";
            this.btnKeluar.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
            this.btnKeluar.Name = "btnKeluar";
            // pnlContent
            //
            this.pnlContent.Location = new System.Drawing.Point(210, 0);
            this.pnlContent.Size = new System.Drawing.Size(970, 720);
            this.pnlContent.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlContent.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            this.pnlContent.Name = "pnlContent";
            this.pnlContent.Controls.Add(this.ucDashboard1);
            // ucDashboard1
            //
            this.ucDashboard1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucDashboard1.Name = "ucDashboard1";
            //
            // FormMain
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.ClientSize = new System.Drawing.Size(1180, 720);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Name = "FormMain";
            this.Controls.Add(this.pnlSidebar);
            this.Controls.Add(this.pnlContent);
            this.Text = "SMKMart";
            this.pnlSidebar.ResumeLayout(false);
            this.pnlContent.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel pnlSidebar;
        private System.Windows.Forms.Label lblLogoSmk;
        private SMKMart.Controls.RoundedLabel lblLogoMart;
        private SMKMart.Controls.RoundedButton btnNavDashboard;
        private SMKMart.Controls.RoundedButton btnNavPenjualan;
        private SMKMart.Controls.RoundedButton btnNavBarang;
        private SMKMart.Controls.RoundedButton btnNavGudang;
        private SMKMart.Controls.RoundedButton btnNavLaporan;
        private SMKMart.Controls.RoundedButton btnNavPengguna;
        private SMKMart.Controls.RoundedPanel pnlGarisSidebar;
        private SMKMart.Controls.RoundedButton btnKeluar;
        private System.Windows.Forms.Panel pnlContent;
        private SMKMart.Pages.ucDashboard ucDashboard1;
    }
}
