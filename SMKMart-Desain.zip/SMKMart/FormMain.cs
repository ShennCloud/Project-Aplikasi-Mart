using System.Windows.Forms;

namespace SMKMart
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }
    }
}
