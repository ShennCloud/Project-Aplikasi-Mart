using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SMKMart.Controls
{
    // Tombol datar dengan sudut membulat + efek hover.
    public class RoundedButton : Button
    {
        private int _radius = 12;
        private int _textPadding;
        private bool _hover;
        private bool _down;

        public RoundedButton()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            Cursor = Cursors.Hand;
            UseVisualStyleBackColor = false;
        }

        [Category("Rounded")]
        public int Radius
        {
            get => _radius;
            set { _radius = value; Invalidate(); }
        }

        // Jarak teks dari sisi kiri/kanan (berguna untuk TextAlign = MiddleLeft)
        [Category("Rounded")]
        public int TextPadding
        {
            get => _textPadding;
            set { _textPadding = value; Invalidate(); }
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; _down = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { _down = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { _down = false; Invalidate(); base.OnMouseUp(e); }

        protected override void OnPaintBackground(PaintEventArgs pevent)
        {
            pevent.Graphics.Clear(UiHelper.Behind(this));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Color fill = BackColor;
            if (!Enabled) fill = UiHelper.Shift(fill, -30);
            else if (_down) fill = UiHelper.Shift(fill, -14);
            else if (_hover) fill = UiHelper.Shift(fill, 14);

            var rect = new RectangleF(0, 0, Width - 1, Height - 1);
            using (var path = UiHelper.RoundRect(rect, _radius))
            using (var brush = new SolidBrush(fill))
                g.FillPath(brush, path);

            TextFormatFlags flags = TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine |
                                    TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding;
            var a = TextAlign;
            if (a == ContentAlignment.MiddleLeft || a == ContentAlignment.TopLeft || a == ContentAlignment.BottomLeft)
                flags |= TextFormatFlags.Left;
            else if (a == ContentAlignment.MiddleRight || a == ContentAlignment.TopRight || a == ContentAlignment.BottomRight)
                flags |= TextFormatFlags.Right;
            else
                flags |= TextFormatFlags.HorizontalCenter;

            var textRect = new Rectangle(_textPadding, 0, Math.Max(1, Width - _textPadding * 2), Height);
            TextRenderer.DrawText(g, Text, Font, textRect, ForeColor, flags);
        }
    }
}
