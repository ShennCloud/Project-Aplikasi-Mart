using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SMKMart.Controls
{
    // Label dengan latar membulat (dipakai untuk badge, avatar, dan logo "Mart").
    public class RoundedLabel : Label
    {
        private int _radius = 8;

        public RoundedLabel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            AutoSize = false;
            TextAlign = ContentAlignment.MiddleCenter;
        }

        [Category("Rounded")]
        public int Radius
        {
            get => _radius;
            set { _radius = value; Invalidate(); }
        }

        protected override void OnPaintBackground(PaintEventArgs pevent)
        {
            pevent.Graphics.Clear(UiHelper.Behind(this));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var rect = new RectangleF(0, 0, Width - 1, Height - 1);
            using (var path = UiHelper.RoundRect(rect, _radius))
            using (var brush = new SolidBrush(BackColor))
                g.FillPath(brush, path);

            TextFormatFlags flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter |
                                    TextFormatFlags.SingleLine | TextFormatFlags.NoPadding;
            TextRenderer.DrawText(g, Text, Font, ClientRectangle, ForeColor, flags);
        }
    }
}
