using System;
using System.Drawing;
using System.Windows.Forms;

namespace SMKMart.Controls
{
    // DataGridView bertema gelap (tanpa border, baris rata, header redup).
    public class DarkGrid : DataGridView
    {
        public DarkGrid()
        {
            Color kartu = Color.FromArgb(17, 27, 52);
            Color garis = Color.FromArgb(36, 50, 90);
            Color kecil = Color.FromArgb(143, 163, 214);
            Color pilih = Color.FromArgb(44, 67, 150);

            DoubleBuffered = true;
            BackgroundColor = kartu;
            BorderStyle = BorderStyle.None;
            CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            GridColor = garis;
            EnableHeadersVisualStyles = false;
            ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            ColumnHeadersHeight = 34;
            ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
            {
                BackColor = kartu,
                ForeColor = kecil,
                SelectionBackColor = kartu,
                SelectionForeColor = kecil,
                Font = new Font("Segoe UI", 9F),
                Alignment = DataGridViewContentAlignment.MiddleLeft,
                Padding = new Padding(6, 0, 6, 0)
            };
            DefaultCellStyle = new DataGridViewCellStyle
            {
                BackColor = kartu,
                ForeColor = Color.White,
                SelectionBackColor = pilih,
                SelectionForeColor = Color.White,
                Font = new Font("Segoe UI", 10F),
                Padding = new Padding(6, 0, 6, 0)
            };
            RowHeadersVisible = false;
            AllowUserToAddRows = false;
            AllowUserToDeleteRows = false;
            AllowUserToResizeRows = false;
            AllowUserToResizeColumns = false;
            ReadOnly = true;
            SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            MultiSelect = false;
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            RowTemplate.Height = 32;
        }
    }
}
