using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace SMKMart.Controls
{
    // Kotak input gelap dengan sudut membulat (TextBox di dalam RoundedPanel).
    // Pakai seperti TextBox biasa: .Text, .PlaceholderText, .UseSystemPasswordChar, .ReadOnly
    // TextBox aslinya bisa diakses lewat .Inner
    public class RoundedTextBox : RoundedPanel
    {
        private readonly TextBox _inner;
        private int _rightPadding = 14;
        private bool _focused;

        public RoundedTextBox()
        {
            Radius = 12;
            FillColor = Color.FromArgb(10, 17, 38);
            BorderColor = Color.FromArgb(36, 50, 90);
            BorderSize = 1;
            Size = new Size(240, 46);

            _inner = new TextBox
            {
                BorderStyle = BorderStyle.None,
                BackColor = FillColor,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11F)
            };
            _inner.GotFocus += (s, e) => { _focused = true; Invalidate(); };
            _inner.LostFocus += (s, e) => { _focused = false; Invalidate(); };
            _inner.TextChanged += (s, e) => OnTextChanged(e);
            Controls.Add(_inner);
            Click += (s, e) => _inner.Focus();
            LayoutInner();
        }

        [Browsable(false)]
        public TextBox Inner => _inner;

        [Browsable(true)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        [EditorBrowsable(EditorBrowsableState.Always)]
        public override string Text
        {
            get => _inner == null ? string.Empty : _inner.Text;
            set { if (_inner != null) _inner.Text = value; }
        }

        [Category("Rounded"), DefaultValue("")]
        public string PlaceholderText
        {
            get => _inner.PlaceholderText;
            set => _inner.PlaceholderText = value;
        }

        [Category("Rounded"), DefaultValue(false)]
        public bool UseSystemPasswordChar
        {
            get => _inner.UseSystemPasswordChar;
            set => _inner.UseSystemPasswordChar = value;
        }

        [Category("Rounded"), DefaultValue(false)]
        public bool ReadOnly
        {
            get => _inner.ReadOnly;
            set => _inner.ReadOnly = value;
        }

        // Ruang kosong di sisi kanan (mis. untuk tombol "Lihat")
        [Category("Rounded"), DefaultValue(14)]
        public int RightPadding
        {
            get => _rightPadding;
            set { _rightPadding = value; LayoutInner(); }
        }

        protected override Color CurrentBorderColor =>
            _focused ? Color.FromArgb(107, 140, 255) : base.CurrentBorderColor;

        protected override void OnFillColorChanged()
        {
            if (_inner != null) _inner.BackColor = FillColor;
        }

        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            LayoutInner();
        }

        private void LayoutInner()
        {
            if (_inner == null) return;
            _inner.Left = 14;
            _inner.Width = Math.Max(20, Width - 14 - _rightPadding);
            _inner.Top = Math.Max(0, (Height - _inner.Height) / 2);
        }
    }
}
