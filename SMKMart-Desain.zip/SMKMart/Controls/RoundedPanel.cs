using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SMKMart.Controls
{
    // Panel dengan sudut membulat. BackColor = warna di belakang (samakan dengan induk),
    // FillColor = warna kartu.
    public class RoundedPanel : Panel
    {
        private int _radius = 14;
        private Color _fill = Color.FromArgb(17, 27, 52);
        private Color _border = Color.Transparent;
        private int _borderSize;

        public RoundedPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        [Category("Rounded")]
        public int Radius
        {
            get => _radius;
            set { _radius = value; Invalidate(); }
        }

        [Category("Rounded")]
        public Color FillColor
        {
            get => _fill;
            set { _fill = value; OnFillColorChanged(); Invalidate(); }
        }

        [Category("Rounded")]
        public Color BorderColor
        {
            get => _border;
            set { _border = value; Invalidate(); }
        }

        [Category("Rounded")]
        public int BorderSize
        {
            get => _borderSize;
            set { _borderSize = value; Invalidate(); }
        }

        protected virtual Color CurrentBorderColor => _border;

        protected virtual void OnFillColorChanged()
        {
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var rect = new RectangleF(0.5f, 0.5f, Width - 1.5f, Height - 1.5f);
            using (var path = UiHelper.RoundRect(rect, _radius))
            using (var brush = new SolidBrush(_fill))
            {
                g.FillPath(brush, path);
                if (_borderSize > 0 && CurrentBorderColor.A > 0)
                {
                    using (var pen = new Pen(CurrentBorderColor, _borderSize))
                        g.DrawPath(pen, path);
                }
            }
        }
    }
}
