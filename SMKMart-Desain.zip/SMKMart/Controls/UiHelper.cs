using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SMKMart.Controls
{
    internal static class UiHelper
    {
        public static GraphicsPath RoundRect(RectangleF r, float radius)
        {
            var path = new GraphicsPath();
            float d = Math.Min(radius * 2f, Math.Min(r.Width, r.Height));
            if (d <= 0.5f)
            {
                path.AddRectangle(r);
                return path;
            }
            path.AddArc(r.X, r.Y, d, d, 180, 90);
            path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
            path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        // Warna latar di belakang kontrol (supaya sudut membulat menyatu dengan induknya).
        public static Color Behind(Control c)
        {
            for (Control p = c.Parent; p != null; p = p.Parent)
            {
                if (p is RoundedPanel rp) return rp.FillColor;
                if (p.BackColor.A == 255) return p.BackColor;
            }
            return SystemColors.Control;
        }

        public static Color Shift(Color c, int d)
        {
            return Color.FromArgb(c.A,
                Math.Max(0, Math.Min(255, c.R + d)),
                Math.Max(0, Math.Min(255, c.G + d)),
                Math.Max(0, Math.Min(255, c.B + d)));
        }
    }
}
