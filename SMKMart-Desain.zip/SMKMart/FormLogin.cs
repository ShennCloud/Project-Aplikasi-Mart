using System.Windows.Forms;

namespace SMKMart
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }
    }
}
