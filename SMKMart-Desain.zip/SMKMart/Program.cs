using System;
using System.Windows.Forms;

namespace SMKMart
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            // Ganti ke FormMain kalau mau langsung melihat tampilan utama.
            Application.Run(new FormLogin());
        }
    }
}
