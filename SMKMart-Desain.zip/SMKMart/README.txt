SMKMart - DESAIN WinForms (tanpa logika program)
================================================

Buka:  SMKMart.csproj  di Visual Studio Insiders.
Target: net10.0-windows (ganti ke net8.0-windows di .csproj kalau SDK kamu belum ada .NET 10).

LANGKAH PERTAMA: Build > Build Solution (Ctrl+Shift+B).
Kontrol buatan (RoundedPanel, RoundedButton, dst.) harus di-build dulu
supaya Designer bisa menampilkannya.

Isi:
  FormLogin            - halaman masuk
  FormMain             - sidebar + panel konten (pnlContent)
  Pages\ucDashboard
  Pages\ucPenjualan
  Pages\ucDataBarang
  Pages\ucGudangMasuk / ucGudangKeluar / ucGudangStok
  Pages\ucLaporanPenjualan / ucLaporanGudang
  Pages\ucPengguna
  Controls\            - kontrol bantu (sudut membulat, tabel gelap)

Semua halaman adalah UserControl berukuran 970 x 720, dipasang ke pnlContent di FormMain.
Pindah halaman: pnlContent.Controls.Clear(); pnlContent.Controls.Add(new ucX { Dock = DockStyle.Fill });

Tiap kontrol sudah diberi nama (btnSimpan, txtNama, dgvBarang, cboKategori, dst.).
Teks, warna, ukuran bisa diubah lewat Properties seperti biasa.
Method IsiContoh() di tiap halaman hanya data contoh agar Designer tidak kosong - hapus kalau tidak perlu.
