using System.Drawing;
using System.Windows.Forms;

namespace SMKMart.Pages
{
    public partial class ucDataBarang : UserControl
    {
        public ucDataBarang()
        {
            InitializeComponent();
            IsiContoh();
        }

        // DATA CONTOH supaya tampilan di Designer tidak kosong.
        // Hapus method ini (dan pemanggilannya) kalau sudah mengisi data sendiri.
        private void IsiContoh()
        {
            dgvBarang.Rows.Add("BRG-001", "Buku tulis", "ATK", "4.500", "42", "10", "Aman");
            dgvBarang.Rows.Add("BRG-002", "Pulpen hitam", "ATK", "3.500", "60", "15", "Aman");
            dgvBarang.Rows.Add("BRG-003", "Mi instan", "Makanan", "3.200", "9", "15", "Menipis");
            dgvBarang.Rows.Add("BRG-004", "Beras 5 kg", "Sembako", "68.000", "3", "10", "Menipis");
            dgvBarang.Rows[2].Cells["colStatus"].Style.ForeColor = Color.FromArgb(255, 200, 61);
            dgvBarang.Rows[3].Cells["colStatus"].Style.ForeColor = Color.FromArgb(255, 200, 61);
            dgvBarang.ClearSelection();
        }
    }
}
