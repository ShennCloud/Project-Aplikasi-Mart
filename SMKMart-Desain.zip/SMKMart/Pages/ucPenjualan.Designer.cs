namespace SMKMart.Pages
{
    partial class ucPenjualan
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblJudul = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.txtCari = new SMKMart.Controls.RoundedTextBox();
            this.flpBarang = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlProduk1 = new SMKMart.Controls.RoundedPanel();
            this.lblProdukNama1 = new System.Windows.Forms.Label();
            this.lblProdukHarga1 = new System.Windows.Forms.Label();
            this.lblProdukStok1 = new System.Windows.Forms.Label();
            this.pnlProduk2 = new SMKMart.Controls.RoundedPanel();
            this.lblProdukNama2 = new System.Windows.Forms.Label();
            this.lblProdukHarga2 = new System.Windows.Forms.Label();
            this.lblProdukStok2 = new System.Windows.Forms.Label();
            this.pnlProduk3 = new SMKMart.Controls.RoundedPanel();
            this.lblProdukNama3 = new System.Windows.Forms.Label();
            this.lblProdukHarga3 = new System.Windows.Forms.Label();
            this.lblProdukStok3 = new System.Windows.Forms.Label();
            this.pnlProduk4 = new SMKMart.Controls.RoundedPanel();
            this.lblProdukNama4 = new System.Windows.Forms.Label();
            this.lblProdukHarga4 = new System.Windows.Forms.Label();
            this.lblProdukStok4 = new System.Windows.Forms.Label();
            this.pnlProduk5 = new SMKMart.Controls.RoundedPanel();
            this.lblProdukNama5 = new System.Windows.Forms.Label();
            this.lblProdukHarga5 = new System.Windows.Forms.Label();
            this.lblProdukStok5 = new System.Windows.Forms.Label();
            this.pnlProduk6 = new SMKMart.Controls.RoundedPanel();
            this.lblProdukNama6 = new System.Windows.Forms.Label();
            this.lblProdukHarga6 = new System.Windows.Forms.Label();
            this.lblProdukStok6 = new System.Windows.Forms.Label();
            this.pnlKeranjang = new SMKMart.Controls.RoundedPanel();
            this.lblKeranjang = new System.Windows.Forms.Label();
            this.dgvKeranjang = new SMKMart.Controls.DarkGrid();
            this.pnlGarisKeranjang = new SMKMart.Controls.RoundedPanel();
            this.lblTotalCaption = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.lblUangCaption = new System.Windows.Forms.Label();
            this.txtUang = new SMKMart.Controls.RoundedTextBox();
            this.lblKembalian = new System.Windows.Forms.Label();
            this.btnBayar = new SMKMart.Controls.RoundedButton();
            this.btnKosongkan = new SMKMart.Controls.RoundedButton();
            this.colBarang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colSubtotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKeranjang)).BeginInit();
            this.SuspendLayout();
            this.flpBarang.SuspendLayout();
            this.pnlProduk1.SuspendLayout();
            this.pnlProduk2.SuspendLayout();
            this.pnlProduk3.SuspendLayout();
            this.pnlProduk4.SuspendLayout();
            this.pnlProduk5.SuspendLayout();
            this.pnlProduk6.SuspendLayout();
            this.pnlKeranjang.SuspendLayout();
            //
            // lblJudul
            //
            this.lblJudul.Location = new System.Drawing.Point(28, 20);
            this.lblJudul.AutoSize = true;
            this.lblJudul.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblJudul.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblJudul.Text = "Penjualan";
            this.lblJudul.Name = "lblJudul";
            // lblSub
            //
            this.lblSub.Location = new System.Drawing.Point(30, 62);
            this.lblSub.AutoSize = true;
            this.lblSub.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSub.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSub.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSub.Text = "TRX-0039 · Kasir: Rina";
            this.lblSub.Name = "lblSub";
            // txtCari
            //
            this.txtCari.Location = new System.Drawing.Point(600, 20);
            this.txtCari.Size = new System.Drawing.Size(342, 46);
            this.txtCari.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.txtCari.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtCari.PlaceholderText = "Cari nama atau kode barang";
            this.txtCari.Name = "txtCari";
            // flpBarang
            //
            this.flpBarang.Location = new System.Drawing.Point(28, 90);
            this.flpBarang.Size = new System.Drawing.Size(600, 606);
            this.flpBarang.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.flpBarang.AutoScroll = true;
            this.flpBarang.Name = "flpBarang";
            this.flpBarang.Controls.Add(this.pnlProduk1);
            this.flpBarang.Controls.Add(this.pnlProduk2);
            this.flpBarang.Controls.Add(this.pnlProduk3);
            this.flpBarang.Controls.Add(this.pnlProduk4);
            this.flpBarang.Controls.Add(this.pnlProduk5);
            this.flpBarang.Controls.Add(this.pnlProduk6);
            // pnlProduk1
            //
            this.pnlProduk1.Size = new System.Drawing.Size(176, 112);
            this.pnlProduk1.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlProduk1.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlProduk1.Radius = 14;
            this.pnlProduk1.Margin = new System.Windows.Forms.Padding(0, 0, 14, 14);
            this.pnlProduk1.Name = "pnlProduk1";
            this.pnlProduk1.Controls.Add(this.lblProdukNama1);
            this.pnlProduk1.Controls.Add(this.lblProdukHarga1);
            this.pnlProduk1.Controls.Add(this.lblProdukStok1);
            // lblProdukNama1
            //
            this.lblProdukNama1.Location = new System.Drawing.Point(14, 14);
            this.lblProdukNama1.AutoSize = true;
            this.lblProdukNama1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukNama1.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblProdukNama1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukNama1.Text = "Buku tulis";
            this.lblProdukNama1.Name = "lblProdukNama1";
            // lblProdukHarga1
            //
            this.lblProdukHarga1.Location = new System.Drawing.Point(14, 44);
            this.lblProdukHarga1.AutoSize = true;
            this.lblProdukHarga1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukHarga1.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblProdukHarga1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukHarga1.Text = "Rp 4.500";
            this.lblProdukHarga1.Name = "lblProdukHarga1";
            // lblProdukStok1
            //
            this.lblProdukStok1.Location = new System.Drawing.Point(14, 74);
            this.lblProdukStok1.AutoSize = true;
            this.lblProdukStok1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukStok1.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblProdukStok1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblProdukStok1.Text = "Stok 42";
            this.lblProdukStok1.Name = "lblProdukStok1";
            // pnlProduk2
            //
            this.pnlProduk2.Size = new System.Drawing.Size(176, 112);
            this.pnlProduk2.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlProduk2.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlProduk2.Radius = 14;
            this.pnlProduk2.Margin = new System.Windows.Forms.Padding(0, 0, 14, 14);
            this.pnlProduk2.Name = "pnlProduk2";
            this.pnlProduk2.Controls.Add(this.lblProdukNama2);
            this.pnlProduk2.Controls.Add(this.lblProdukHarga2);
            this.pnlProduk2.Controls.Add(this.lblProdukStok2);
            // lblProdukNama2
            //
            this.lblProdukNama2.Location = new System.Drawing.Point(14, 14);
            this.lblProdukNama2.AutoSize = true;
            this.lblProdukNama2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukNama2.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblProdukNama2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukNama2.Text = "Pulpen hitam";
            this.lblProdukNama2.Name = "lblProdukNama2";
            // lblProdukHarga2
            //
            this.lblProdukHarga2.Location = new System.Drawing.Point(14, 44);
            this.lblProdukHarga2.AutoSize = true;
            this.lblProdukHarga2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukHarga2.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblProdukHarga2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukHarga2.Text = "Rp 3.500";
            this.lblProdukHarga2.Name = "lblProdukHarga2";
            // lblProdukStok2
            //
            this.lblProdukStok2.Location = new System.Drawing.Point(14, 74);
            this.lblProdukStok2.AutoSize = true;
            this.lblProdukStok2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukStok2.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblProdukStok2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblProdukStok2.Text = "Stok 60";
            this.lblProdukStok2.Name = "lblProdukStok2";
            // pnlProduk3
            //
            this.pnlProduk3.Size = new System.Drawing.Size(176, 112);
            this.pnlProduk3.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlProduk3.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlProduk3.Radius = 14;
            this.pnlProduk3.Margin = new System.Windows.Forms.Padding(0, 0, 14, 14);
            this.pnlProduk3.Name = "pnlProduk3";
            this.pnlProduk3.Controls.Add(this.lblProdukNama3);
            this.pnlProduk3.Controls.Add(this.lblProdukHarga3);
            this.pnlProduk3.Controls.Add(this.lblProdukStok3);
            // lblProdukNama3
            //
            this.lblProdukNama3.Location = new System.Drawing.Point(14, 14);
            this.lblProdukNama3.AutoSize = true;
            this.lblProdukNama3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukNama3.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblProdukNama3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukNama3.Text = "Roti cokelat";
            this.lblProdukNama3.Name = "lblProdukNama3";
            // lblProdukHarga3
            //
            this.lblProdukHarga3.Location = new System.Drawing.Point(14, 44);
            this.lblProdukHarga3.AutoSize = true;
            this.lblProdukHarga3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukHarga3.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblProdukHarga3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukHarga3.Text = "Rp 6.500";
            this.lblProdukHarga3.Name = "lblProdukHarga3";
            // lblProdukStok3
            //
            this.lblProdukStok3.Location = new System.Drawing.Point(14, 74);
            this.lblProdukStok3.AutoSize = true;
            this.lblProdukStok3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukStok3.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblProdukStok3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblProdukStok3.Text = "Stok 18";
            this.lblProdukStok3.Name = "lblProdukStok3";
            // pnlProduk4
            //
            this.pnlProduk4.Size = new System.Drawing.Size(176, 112);
            this.pnlProduk4.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlProduk4.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlProduk4.Radius = 14;
            this.pnlProduk4.Margin = new System.Windows.Forms.Padding(0, 0, 14, 14);
            this.pnlProduk4.Name = "pnlProduk4";
            this.pnlProduk4.Controls.Add(this.lblProdukNama4);
            this.pnlProduk4.Controls.Add(this.lblProdukHarga4);
            this.pnlProduk4.Controls.Add(this.lblProdukStok4);
            // lblProdukNama4
            //
            this.lblProdukNama4.Location = new System.Drawing.Point(14, 14);
            this.lblProdukNama4.AutoSize = true;
            this.lblProdukNama4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukNama4.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblProdukNama4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukNama4.Text = "Air mineral";
            this.lblProdukNama4.Name = "lblProdukNama4";
            // lblProdukHarga4
            //
            this.lblProdukHarga4.Location = new System.Drawing.Point(14, 44);
            this.lblProdukHarga4.AutoSize = true;
            this.lblProdukHarga4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukHarga4.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblProdukHarga4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukHarga4.Text = "Rp 3.000";
            this.lblProdukHarga4.Name = "lblProdukHarga4";
            // lblProdukStok4
            //
            this.lblProdukStok4.Location = new System.Drawing.Point(14, 74);
            this.lblProdukStok4.AutoSize = true;
            this.lblProdukStok4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukStok4.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblProdukStok4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblProdukStok4.Text = "Stok 75";
            this.lblProdukStok4.Name = "lblProdukStok4";
            // pnlProduk5
            //
            this.pnlProduk5.Size = new System.Drawing.Size(176, 112);
            this.pnlProduk5.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlProduk5.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlProduk5.Radius = 14;
            this.pnlProduk5.BorderColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlProduk5.BorderSize = 2;
            this.pnlProduk5.Margin = new System.Windows.Forms.Padding(0, 0, 14, 14);
            this.pnlProduk5.Name = "pnlProduk5";
            this.pnlProduk5.Controls.Add(this.lblProdukNama5);
            this.pnlProduk5.Controls.Add(this.lblProdukHarga5);
            this.pnlProduk5.Controls.Add(this.lblProdukStok5);
            // lblProdukNama5
            //
            this.lblProdukNama5.Location = new System.Drawing.Point(14, 14);
            this.lblProdukNama5.AutoSize = true;
            this.lblProdukNama5.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukNama5.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblProdukNama5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukNama5.Text = "Mi instan";
            this.lblProdukNama5.Name = "lblProdukNama5";
            // lblProdukHarga5
            //
            this.lblProdukHarga5.Location = new System.Drawing.Point(14, 44);
            this.lblProdukHarga5.AutoSize = true;
            this.lblProdukHarga5.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukHarga5.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblProdukHarga5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukHarga5.Text = "Rp 3.200";
            this.lblProdukHarga5.Name = "lblProdukHarga5";
            // lblProdukStok5
            //
            this.lblProdukStok5.Location = new System.Drawing.Point(14, 74);
            this.lblProdukStok5.AutoSize = true;
            this.lblProdukStok5.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukStok5.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblProdukStok5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblProdukStok5.Text = "Stok 9 (menipis)";
            this.lblProdukStok5.Name = "lblProdukStok5";
            // pnlProduk6
            //
            this.pnlProduk6.Size = new System.Drawing.Size(176, 112);
            this.pnlProduk6.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlProduk6.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlProduk6.Radius = 14;
            this.pnlProduk6.Margin = new System.Windows.Forms.Padding(0, 0, 14, 14);
            this.pnlProduk6.Name = "pnlProduk6";
            this.pnlProduk6.Controls.Add(this.lblProdukNama6);
            this.pnlProduk6.Controls.Add(this.lblProdukHarga6);
            this.pnlProduk6.Controls.Add(this.lblProdukStok6);
            // lblProdukNama6
            //
            this.lblProdukNama6.Location = new System.Drawing.Point(14, 14);
            this.lblProdukNama6.AutoSize = true;
            this.lblProdukNama6.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukNama6.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblProdukNama6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukNama6.Text = "Penggaris";
            this.lblProdukNama6.Name = "lblProdukNama6";
            // lblProdukHarga6
            //
            this.lblProdukHarga6.Location = new System.Drawing.Point(14, 44);
            this.lblProdukHarga6.AutoSize = true;
            this.lblProdukHarga6.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukHarga6.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblProdukHarga6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProdukHarga6.Text = "Rp 2.500";
            this.lblProdukHarga6.Name = "lblProdukHarga6";
            // lblProdukStok6
            //
            this.lblProdukStok6.Location = new System.Drawing.Point(14, 74);
            this.lblProdukStok6.AutoSize = true;
            this.lblProdukStok6.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblProdukStok6.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblProdukStok6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblProdukStok6.Text = "Stok 30";
            this.lblProdukStok6.Name = "lblProdukStok6";
            // pnlKeranjang
            //
            this.pnlKeranjang.Location = new System.Drawing.Point(640, 90);
            this.pnlKeranjang.Size = new System.Drawing.Size(302, 600);
            this.pnlKeranjang.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlKeranjang.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlKeranjang.Radius = 14;
            this.pnlKeranjang.Name = "pnlKeranjang";
            this.pnlKeranjang.Controls.Add(this.lblKeranjang);
            this.pnlKeranjang.Controls.Add(this.dgvKeranjang);
            this.pnlKeranjang.Controls.Add(this.pnlGarisKeranjang);
            this.pnlKeranjang.Controls.Add(this.lblTotalCaption);
            this.pnlKeranjang.Controls.Add(this.lblTotal);
            this.pnlKeranjang.Controls.Add(this.lblUangCaption);
            this.pnlKeranjang.Controls.Add(this.txtUang);
            this.pnlKeranjang.Controls.Add(this.lblKembalian);
            this.pnlKeranjang.Controls.Add(this.btnBayar);
            this.pnlKeranjang.Controls.Add(this.btnKosongkan);
            // lblKeranjang
            //
            this.lblKeranjang.Location = new System.Drawing.Point(18, 14);
            this.lblKeranjang.AutoSize = true;
            this.lblKeranjang.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblKeranjang.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblKeranjang.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblKeranjang.Text = "Keranjang";
            this.lblKeranjang.Name = "lblKeranjang";
            // dgvKeranjang
            //
            this.dgvKeranjang.Location = new System.Drawing.Point(14, 50);
            this.dgvKeranjang.Size = new System.Drawing.Size(274, 226);
            this.dgvKeranjang.BackgroundColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.dgvKeranjang.Name = "dgvKeranjang";
            this.colBarang.HeaderText = "Barang";
            this.colBarang.Name = "colBarang";
            this.colBarang.FillWeight = 46F;
            this.colBarang.MinimumWidth = 6;
            this.colQty.HeaderText = "Qty";
            this.colQty.Name = "colQty";
            this.colQty.FillWeight = 14F;
            this.colQty.MinimumWidth = 6;
            this.colQty.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colQty.HeaderCell.Style = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colSubtotal.HeaderText = "Subtotal";
            this.colSubtotal.Name = "colSubtotal";
            this.colSubtotal.FillWeight = 40F;
            this.colSubtotal.MinimumWidth = 6;
            this.colSubtotal.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colSubtotal.HeaderCell.Style = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.dgvKeranjang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { this.colBarang, this.colQty, this.colSubtotal });
            // pnlGarisKeranjang
            //
            this.pnlGarisKeranjang.Location = new System.Drawing.Point(18, 292);
            this.pnlGarisKeranjang.Size = new System.Drawing.Size(266, 1);
            this.pnlGarisKeranjang.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGarisKeranjang.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGarisKeranjang.Radius = 0;
            this.pnlGarisKeranjang.Name = "pnlGarisKeranjang";
            // lblTotalCaption
            //
            this.lblTotalCaption.Location = new System.Drawing.Point(18, 312);
            this.lblTotalCaption.AutoSize = true;
            this.lblTotalCaption.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTotalCaption.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblTotalCaption.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblTotalCaption.Text = "Total";
            this.lblTotalCaption.Name = "lblTotalCaption";
            // lblTotal
            //
            this.lblTotal.Location = new System.Drawing.Point(120, 300);
            this.lblTotal.Size = new System.Drawing.Size(164, 36);
            this.lblTotal.AutoSize = false;
            this.lblTotal.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTotal.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblTotal.Text = "Rp 19.000";
            this.lblTotal.Name = "lblTotal";
            // lblUangCaption
            //
            this.lblUangCaption.Location = new System.Drawing.Point(18, 352);
            this.lblUangCaption.AutoSize = true;
            this.lblUangCaption.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblUangCaption.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblUangCaption.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblUangCaption.Text = "Uang tunai";
            this.lblUangCaption.Name = "lblUangCaption";
            // txtUang
            //
            this.txtUang.Location = new System.Drawing.Point(18, 374);
            this.txtUang.Size = new System.Drawing.Size(266, 46);
            this.txtUang.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtUang.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtUang.PlaceholderText = "mis. 20.000";
            this.txtUang.Name = "txtUang";
            // lblKembalian
            //
            this.lblKembalian.Location = new System.Drawing.Point(18, 434);
            this.lblKembalian.AutoSize = true;
            this.lblKembalian.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblKembalian.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblKembalian.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblKembalian.Text = "Kembalian: Rp 1.000";
            this.lblKembalian.Name = "lblKembalian";
            // btnBayar
            //
            this.btnBayar.Location = new System.Drawing.Point(18, 474);
            this.btnBayar.Size = new System.Drawing.Size(266, 52);
            this.btnBayar.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnBayar.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnBayar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.btnBayar.Radius = 12;
            this.btnBayar.UseVisualStyleBackColor = false;
            this.btnBayar.Text = "Bayar";
            this.btnBayar.Name = "btnBayar";
            // btnKosongkan
            //
            this.btnKosongkan.Location = new System.Drawing.Point(18, 536);
            this.btnKosongkan.Size = new System.Drawing.Size(266, 42);
            this.btnKosongkan.BackColor = System.Drawing.Color.FromArgb(42, 58, 114);
            this.btnKosongkan.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnKosongkan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnKosongkan.Radius = 12;
            this.btnKosongkan.UseVisualStyleBackColor = false;
            this.btnKosongkan.Text = "Kosongkan keranjang";
            this.btnKosongkan.Name = "btnKosongkan";
            //
            // ucPenjualan
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.Size = new System.Drawing.Size(970, 720);
            this.Name = "ucPenjualan";
            this.Controls.Add(this.lblJudul);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.txtCari);
            this.Controls.Add(this.flpBarang);
            this.Controls.Add(this.pnlKeranjang);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKeranjang)).EndInit();
            this.flpBarang.ResumeLayout(false);
            this.pnlProduk1.ResumeLayout(false);
            this.pnlProduk2.ResumeLayout(false);
            this.pnlProduk3.ResumeLayout(false);
            this.pnlProduk4.ResumeLayout(false);
            this.pnlProduk5.ResumeLayout(false);
            this.pnlProduk6.ResumeLayout(false);
            this.pnlKeranjang.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label lblJudul;
        private System.Windows.Forms.Label lblSub;
        private SMKMart.Controls.RoundedTextBox txtCari;
        private System.Windows.Forms.FlowLayoutPanel flpBarang;
        private SMKMart.Controls.RoundedPanel pnlProduk1;
        private System.Windows.Forms.Label lblProdukNama1;
        private System.Windows.Forms.Label lblProdukHarga1;
        private System.Windows.Forms.Label lblProdukStok1;
        private SMKMart.Controls.RoundedPanel pnlProduk2;
        private System.Windows.Forms.Label lblProdukNama2;
        private System.Windows.Forms.Label lblProdukHarga2;
        private System.Windows.Forms.Label lblProdukStok2;
        private SMKMart.Controls.RoundedPanel pnlProduk3;
        private System.Windows.Forms.Label lblProdukNama3;
        private System.Windows.Forms.Label lblProdukHarga3;
        private System.Windows.Forms.Label lblProdukStok3;
        private SMKMart.Controls.RoundedPanel pnlProduk4;
        private System.Windows.Forms.Label lblProdukNama4;
        private System.Windows.Forms.Label lblProdukHarga4;
        private System.Windows.Forms.Label lblProdukStok4;
        private SMKMart.Controls.RoundedPanel pnlProduk5;
        private System.Windows.Forms.Label lblProdukNama5;
        private System.Windows.Forms.Label lblProdukHarga5;
        private System.Windows.Forms.Label lblProdukStok5;
        private SMKMart.Controls.RoundedPanel pnlProduk6;
        private System.Windows.Forms.Label lblProdukNama6;
        private System.Windows.Forms.Label lblProdukHarga6;
        private System.Windows.Forms.Label lblProdukStok6;
        private SMKMart.Controls.RoundedPanel pnlKeranjang;
        private System.Windows.Forms.Label lblKeranjang;
        private SMKMart.Controls.DarkGrid dgvKeranjang;
        private SMKMart.Controls.RoundedPanel pnlGarisKeranjang;
        private System.Windows.Forms.Label lblTotalCaption;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label lblUangCaption;
        private SMKMart.Controls.RoundedTextBox txtUang;
        private System.Windows.Forms.Label lblKembalian;
        private SMKMart.Controls.RoundedButton btnBayar;
        private SMKMart.Controls.RoundedButton btnKosongkan;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBarang;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn colSubtotal;
    }
}
