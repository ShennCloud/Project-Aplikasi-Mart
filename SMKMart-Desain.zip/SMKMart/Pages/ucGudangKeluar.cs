using System.Drawing;
using System.Windows.Forms;

namespace SMKMart.Pages
{
    public partial class ucGudangKeluar : UserControl
    {
        public ucGudangKeluar()
        {
            InitializeComponent();
            IsiContoh();
        }

        // DATA CONTOH supaya tampilan di Designer tidak kosong.
        // Hapus method ini (dan pemanggilannya) kalau sudah mengisi data sendiri.
        private void IsiContoh()
        {
            dgvRiwayat.Rows.Add("03/10/2026", "Mi instan", "20", "Kadaluarsa", "Sinta");
            dgvRiwayat.Rows.Add("02/10/2026", "Buku tulis", "4", "Rusak", "Sinta");
            dgvRiwayat.Rows.Add("01/10/2026", "Air mineral", "12", "Retur", "Sinta");
            dgvRiwayat.ClearSelection();
        }
    }
}
