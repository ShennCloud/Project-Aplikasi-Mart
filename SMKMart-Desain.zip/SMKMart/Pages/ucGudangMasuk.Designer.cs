namespace SMKMart.Pages
{
    partial class ucGudangMasuk
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblJudul = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.pnlTabs = new SMKMart.Controls.RoundedPanel();
            this.btnTabMasuk = new SMKMart.Controls.RoundedButton();
            this.btnTabKeluar = new SMKMart.Controls.RoundedButton();
            this.btnTabStok = new SMKMart.Controls.RoundedButton();
            this.pnlStat1 = new SMKMart.Controls.RoundedPanel();
            this.lblStat1Judul = new System.Windows.Forms.Label();
            this.lblStat1Nilai = new System.Windows.Forms.Label();
            this.pnlStat2 = new SMKMart.Controls.RoundedPanel();
            this.lblStat2Judul = new System.Windows.Forms.Label();
            this.lblStat2Nilai = new System.Windows.Forms.Label();
            this.pnlStat3 = new SMKMart.Controls.RoundedPanel();
            this.lblStat3Judul = new System.Windows.Forms.Label();
            this.lblStat3Nilai = new System.Windows.Forms.Label();
            this.pnlForm = new SMKMart.Controls.RoundedPanel();
            this.lblFormJudul = new System.Windows.Forms.Label();
            this.lblBarang = new System.Windows.Forms.Label();
            this.lblJumlah = new System.Windows.Forms.Label();
            this.lblPemasok = new System.Windows.Forms.Label();
            this.lblTanggal = new System.Windows.Forms.Label();
            this.pnlCboBarang = new SMKMart.Controls.RoundedPanel();
            this.cboBarang = new System.Windows.Forms.ComboBox();
            this.txtJumlah = new SMKMart.Controls.RoundedTextBox();
            this.txtPemasok = new SMKMart.Controls.RoundedTextBox();
            this.txtTanggal = new SMKMart.Controls.RoundedTextBox();
            this.btnBatal = new SMKMart.Controls.RoundedButton();
            this.btnSimpan = new SMKMart.Controls.RoundedButton();
            this.pnlRiwayat = new SMKMart.Controls.RoundedPanel();
            this.lblRiwayatJudul = new System.Windows.Forms.Label();
            this.dgvRiwayat = new SMKMart.Controls.DarkGrid();
            this.colTanggal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBarang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colJumlah = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colJenis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPetugas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRiwayat)).BeginInit();
            this.SuspendLayout();
            this.pnlTabs.SuspendLayout();
            this.pnlStat1.SuspendLayout();
            this.pnlStat2.SuspendLayout();
            this.pnlStat3.SuspendLayout();
            this.pnlForm.SuspendLayout();
            this.pnlCboBarang.SuspendLayout();
            this.pnlRiwayat.SuspendLayout();
            //
            // lblJudul
            //
            this.lblJudul.Location = new System.Drawing.Point(28, 20);
            this.lblJudul.AutoSize = true;
            this.lblJudul.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblJudul.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblJudul.Text = "Gudang";
            this.lblJudul.Name = "lblJudul";
            // lblSub
            //
            this.lblSub.Location = new System.Drawing.Point(30, 62);
            this.lblSub.AutoSize = true;
            this.lblSub.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSub.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSub.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSub.Text = "Catat barang masuk, barang keluar, dan pantau stok";
            this.lblSub.Name = "lblSub";
            // pnlTabs
            //
            this.pnlTabs.Location = new System.Drawing.Point(28, 92);
            this.pnlTabs.Size = new System.Drawing.Size(376, 52);
            this.pnlTabs.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlTabs.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTabs.Radius = 14;
            this.pnlTabs.Name = "pnlTabs";
            this.pnlTabs.Controls.Add(this.btnTabMasuk);
            this.pnlTabs.Controls.Add(this.btnTabKeluar);
            this.pnlTabs.Controls.Add(this.btnTabStok);
            // btnTabMasuk
            //
            this.btnTabMasuk.Location = new System.Drawing.Point(6, 6);
            this.btnTabMasuk.Size = new System.Drawing.Size(120, 40);
            this.btnTabMasuk.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnTabMasuk.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnTabMasuk.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabMasuk.Radius = 10;
            this.btnTabMasuk.UseVisualStyleBackColor = false;
            this.btnTabMasuk.Text = "Barang masuk";
            this.btnTabMasuk.Name = "btnTabMasuk";
            // btnTabKeluar
            //
            this.btnTabKeluar.Location = new System.Drawing.Point(132, 6);
            this.btnTabKeluar.Size = new System.Drawing.Size(124, 40);
            this.btnTabKeluar.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.btnTabKeluar.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnTabKeluar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabKeluar.Radius = 10;
            this.btnTabKeluar.UseVisualStyleBackColor = false;
            this.btnTabKeluar.Text = "Barang keluar";
            this.btnTabKeluar.Name = "btnTabKeluar";
            // btnTabStok
            //
            this.btnTabStok.Location = new System.Drawing.Point(262, 6);
            this.btnTabStok.Size = new System.Drawing.Size(108, 40);
            this.btnTabStok.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.btnTabStok.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnTabStok.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabStok.Radius = 10;
            this.btnTabStok.UseVisualStyleBackColor = false;
            this.btnTabStok.Text = "Stok barang";
            this.btnTabStok.Name = "btnTabStok";
            // pnlStat1
            //
            this.pnlStat1.Location = new System.Drawing.Point(28, 158);
            this.pnlStat1.Size = new System.Drawing.Size(296, 82);
            this.pnlStat1.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat1.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlStat1.Radius = 14;
            this.pnlStat1.Name = "pnlStat1";
            this.pnlStat1.Controls.Add(this.lblStat1Judul);
            this.pnlStat1.Controls.Add(this.lblStat1Nilai);
            // lblStat1Judul
            //
            this.lblStat1Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat1Judul.AutoSize = true;
            this.lblStat1Judul.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblStat1Judul.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat1Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat1Judul.Text = "Masuk hari ini";
            this.lblStat1Judul.Name = "lblStat1Judul";
            // lblStat1Nilai
            //
            this.lblStat1Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat1Nilai.AutoSize = true;
            this.lblStat1Nilai.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblStat1Nilai.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat1Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat1Nilai.Text = "120";
            this.lblStat1Nilai.Name = "lblStat1Nilai";
            // pnlStat2
            //
            this.pnlStat2.Location = new System.Drawing.Point(336, 158);
            this.pnlStat2.Size = new System.Drawing.Size(296, 82);
            this.pnlStat2.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat2.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStat2.Radius = 14;
            this.pnlStat2.Name = "pnlStat2";
            this.pnlStat2.Controls.Add(this.lblStat2Judul);
            this.pnlStat2.Controls.Add(this.lblStat2Nilai);
            // lblStat2Judul
            //
            this.lblStat2Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat2Judul.AutoSize = true;
            this.lblStat2Judul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Judul.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStat2Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat2Judul.Text = "Keluar hari ini";
            this.lblStat2Judul.Name = "lblStat2Judul";
            // lblStat2Nilai
            //
            this.lblStat2Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat2Nilai.AutoSize = true;
            this.lblStat2Nilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Nilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStat2Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat2Nilai.Text = "95";
            this.lblStat2Nilai.Name = "lblStat2Nilai";
            // pnlStat3
            //
            this.pnlStat3.Location = new System.Drawing.Point(644, 158);
            this.pnlStat3.Size = new System.Drawing.Size(296, 82);
            this.pnlStat3.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat3.FillColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlStat3.Radius = 14;
            this.pnlStat3.Name = "pnlStat3";
            this.pnlStat3.Controls.Add(this.lblStat3Judul);
            this.pnlStat3.Controls.Add(this.lblStat3Nilai);
            // lblStat3Judul
            //
            this.lblStat3Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat3Judul.AutoSize = true;
            this.lblStat3Judul.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat3Judul.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat3Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat3Judul.Text = "Stok minimum";
            this.lblStat3Judul.Name = "lblStat3Judul";
            // lblStat3Nilai
            //
            this.lblStat3Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat3Nilai.AutoSize = true;
            this.lblStat3Nilai.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat3Nilai.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat3Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat3Nilai.Text = "4 barang";
            this.lblStat3Nilai.Name = "lblStat3Nilai";
            // pnlForm
            //
            this.pnlForm.Location = new System.Drawing.Point(28, 254);
            this.pnlForm.Size = new System.Drawing.Size(914, 262);
            this.pnlForm.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlForm.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlForm.Radius = 14;
            this.pnlForm.Name = "pnlForm";
            this.pnlForm.Controls.Add(this.lblFormJudul);
            this.pnlForm.Controls.Add(this.lblBarang);
            this.pnlForm.Controls.Add(this.lblJumlah);
            this.pnlForm.Controls.Add(this.lblPemasok);
            this.pnlForm.Controls.Add(this.lblTanggal);
            this.pnlForm.Controls.Add(this.pnlCboBarang);
            this.pnlForm.Controls.Add(this.txtJumlah);
            this.pnlForm.Controls.Add(this.txtPemasok);
            this.pnlForm.Controls.Add(this.txtTanggal);
            this.pnlForm.Controls.Add(this.btnBatal);
            this.pnlForm.Controls.Add(this.btnSimpan);
            // lblFormJudul
            //
            this.lblFormJudul.Location = new System.Drawing.Point(18, 14);
            this.lblFormJudul.AutoSize = true;
            this.lblFormJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblFormJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblFormJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblFormJudul.Text = "Catat barang masuk";
            this.lblFormJudul.Name = "lblFormJudul";
            // lblBarang
            //
            this.lblBarang.Location = new System.Drawing.Point(20, 46);
            this.lblBarang.AutoSize = true;
            this.lblBarang.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblBarang.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblBarang.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblBarang.Text = "Barang";
            this.lblBarang.Name = "lblBarang";
            // lblJumlah
            //
            this.lblJumlah.Location = new System.Drawing.Point(312, 46);
            this.lblJumlah.AutoSize = true;
            this.lblJumlah.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblJumlah.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblJumlah.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblJumlah.Text = "Jumlah";
            this.lblJumlah.Name = "lblJumlah";
            // lblPemasok
            //
            this.lblPemasok.Location = new System.Drawing.Point(604, 46);
            this.lblPemasok.AutoSize = true;
            this.lblPemasok.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblPemasok.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblPemasok.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPemasok.Text = "Pemasok";
            this.lblPemasok.Name = "lblPemasok";
            // lblTanggal
            //
            this.lblTanggal.Location = new System.Drawing.Point(20, 132);
            this.lblTanggal.AutoSize = true;
            this.lblTanggal.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTanggal.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblTanggal.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblTanggal.Text = "Tanggal";
            this.lblTanggal.Name = "lblTanggal";
            // pnlCboBarang
            //
            this.pnlCboBarang.Location = new System.Drawing.Point(18, 68);
            this.pnlCboBarang.Size = new System.Drawing.Size(280, 46);
            this.pnlCboBarang.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlCboBarang.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlCboBarang.Radius = 12;
            this.pnlCboBarang.BorderColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlCboBarang.BorderSize = 1;
            this.pnlCboBarang.Name = "pnlCboBarang";
            this.pnlCboBarang.Controls.Add(this.cboBarang);
            // cboBarang
            //
            this.cboBarang.Location = new System.Drawing.Point(12, 8);
            this.cboBarang.Size = new System.Drawing.Size(256, 30);
            this.cboBarang.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.cboBarang.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.cboBarang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBarang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboBarang.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.cboBarang.FormattingEnabled = true;
            this.cboBarang.Name = "cboBarang";
            this.cboBarang.Items.AddRange(new object[] { "Beras 5 kg", "Mi instan", "Buku tulis", "Pulpen hitam" });
            this.cboBarang.SelectedIndex = 0;
            // txtJumlah
            //
            this.txtJumlah.Location = new System.Drawing.Point(310, 68);
            this.txtJumlah.Size = new System.Drawing.Size(280, 46);
            this.txtJumlah.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtJumlah.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtJumlah.PlaceholderText = "mis. 50";
            this.txtJumlah.Name = "txtJumlah";
            // txtPemasok
            //
            this.txtPemasok.Location = new System.Drawing.Point(602, 68);
            this.txtPemasok.Size = new System.Drawing.Size(294, 46);
            this.txtPemasok.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtPemasok.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtPemasok.PlaceholderText = "mis. UD Makmur";
            this.txtPemasok.Name = "txtPemasok";
            // txtTanggal
            //
            this.txtTanggal.Location = new System.Drawing.Point(18, 154);
            this.txtTanggal.Size = new System.Drawing.Size(280, 46);
            this.txtTanggal.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtTanggal.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtTanggal.Text = "03/10/2026";
            this.txtTanggal.Name = "txtTanggal";
            // btnBatal
            //
            this.btnBatal.Location = new System.Drawing.Point(586, 206);
            this.btnBatal.Size = new System.Drawing.Size(150, 46);
            this.btnBatal.BackColor = System.Drawing.Color.FromArgb(42, 58, 114);
            this.btnBatal.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnBatal.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnBatal.Radius = 12;
            this.btnBatal.UseVisualStyleBackColor = false;
            this.btnBatal.Text = "Batal";
            this.btnBatal.Name = "btnBatal";
            // btnSimpan
            //
            this.btnSimpan.Location = new System.Drawing.Point(746, 206);
            this.btnSimpan.Size = new System.Drawing.Size(150, 46);
            this.btnSimpan.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnSimpan.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnSimpan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSimpan.Radius = 12;
            this.btnSimpan.UseVisualStyleBackColor = false;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.Name = "btnSimpan";
            // pnlRiwayat
            //
            this.pnlRiwayat.Location = new System.Drawing.Point(28, 530);
            this.pnlRiwayat.Size = new System.Drawing.Size(914, 178);
            this.pnlRiwayat.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlRiwayat.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlRiwayat.Radius = 14;
            this.pnlRiwayat.Name = "pnlRiwayat";
            this.pnlRiwayat.Controls.Add(this.lblRiwayatJudul);
            this.pnlRiwayat.Controls.Add(this.dgvRiwayat);
            // lblRiwayatJudul
            //
            this.lblRiwayatJudul.Location = new System.Drawing.Point(18, 14);
            this.lblRiwayatJudul.AutoSize = true;
            this.lblRiwayatJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblRiwayatJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblRiwayatJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblRiwayatJudul.Text = "Riwayat aktivitas gudang";
            this.lblRiwayatJudul.Name = "lblRiwayatJudul";
            // dgvRiwayat
            //
            this.dgvRiwayat.Location = new System.Drawing.Point(12, 44);
            this.dgvRiwayat.Size = new System.Drawing.Size(890, 126);
            this.dgvRiwayat.BackgroundColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.dgvRiwayat.Name = "dgvRiwayat";
            this.colTanggal.HeaderText = "Tanggal";
            this.colTanggal.Name = "colTanggal";
            this.colTanggal.FillWeight = 18F;
            this.colTanggal.MinimumWidth = 6;
            this.colBarang.HeaderText = "Barang";
            this.colBarang.Name = "colBarang";
            this.colBarang.FillWeight = 30F;
            this.colBarang.MinimumWidth = 6;
            this.colJumlah.HeaderText = "Jumlah";
            this.colJumlah.Name = "colJumlah";
            this.colJumlah.FillWeight = 12F;
            this.colJumlah.MinimumWidth = 6;
            this.colJumlah.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colJumlah.HeaderCell.Style = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colJenis.HeaderText = "Jenis";
            this.colJenis.Name = "colJenis";
            this.colJenis.FillWeight = 18F;
            this.colJenis.MinimumWidth = 6;
            this.colPetugas.HeaderText = "Petugas";
            this.colPetugas.Name = "colPetugas";
            this.colPetugas.FillWeight = 22F;
            this.colPetugas.MinimumWidth = 6;
            this.dgvRiwayat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { this.colTanggal, this.colBarang, this.colJumlah, this.colJenis, this.colPetugas });
            //
            // ucGudangMasuk
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.Size = new System.Drawing.Size(970, 720);
            this.Name = "ucGudangMasuk";
            this.Controls.Add(this.lblJudul);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.pnlTabs);
            this.Controls.Add(this.pnlStat1);
            this.Controls.Add(this.pnlStat2);
            this.Controls.Add(this.pnlStat3);
            this.Controls.Add(this.pnlForm);
            this.Controls.Add(this.pnlRiwayat);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRiwayat)).EndInit();
            this.pnlTabs.ResumeLayout(false);
            this.pnlStat1.ResumeLayout(false);
            this.pnlStat2.ResumeLayout(false);
            this.pnlStat3.ResumeLayout(false);
            this.pnlForm.ResumeLayout(false);
            this.pnlCboBarang.ResumeLayout(false);
            this.pnlRiwayat.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label lblJudul;
        private System.Windows.Forms.Label lblSub;
        private SMKMart.Controls.RoundedPanel pnlTabs;
        private SMKMart.Controls.RoundedButton btnTabMasuk;
        private SMKMart.Controls.RoundedButton btnTabKeluar;
        private SMKMart.Controls.RoundedButton btnTabStok;
        private SMKMart.Controls.RoundedPanel pnlStat1;
        private System.Windows.Forms.Label lblStat1Judul;
        private System.Windows.Forms.Label lblStat1Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat2;
        private System.Windows.Forms.Label lblStat2Judul;
        private System.Windows.Forms.Label lblStat2Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat3;
        private System.Windows.Forms.Label lblStat3Judul;
        private System.Windows.Forms.Label lblStat3Nilai;
        private SMKMart.Controls.RoundedPanel pnlForm;
        private System.Windows.Forms.Label lblFormJudul;
        private System.Windows.Forms.Label lblBarang;
        private System.Windows.Forms.Label lblJumlah;
        private System.Windows.Forms.Label lblPemasok;
        private System.Windows.Forms.Label lblTanggal;
        private SMKMart.Controls.RoundedPanel pnlCboBarang;
        private System.Windows.Forms.ComboBox cboBarang;
        private SMKMart.Controls.RoundedTextBox txtJumlah;
        private SMKMart.Controls.RoundedTextBox txtPemasok;
        private SMKMart.Controls.RoundedTextBox txtTanggal;
        private SMKMart.Controls.RoundedButton btnBatal;
        private SMKMart.Controls.RoundedButton btnSimpan;
        private SMKMart.Controls.RoundedPanel pnlRiwayat;
        private System.Windows.Forms.Label lblRiwayatJudul;
        private SMKMart.Controls.DarkGrid dgvRiwayat;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTanggal;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBarang;
        private System.Windows.Forms.DataGridViewTextBoxColumn colJumlah;
        private System.Windows.Forms.DataGridViewTextBoxColumn colJenis;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPetugas;
    }
}
