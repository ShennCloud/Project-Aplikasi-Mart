using System.Drawing;
using System.Windows.Forms;

namespace SMKMart.Pages
{
    public partial class ucPenjualan : UserControl
    {
        public ucPenjualan()
        {
            InitializeComponent();
            IsiContoh();
        }

        // DATA CONTOH supaya tampilan di Designer tidak kosong.
        // Hapus method ini (dan pemanggilannya) kalau sudah mengisi data sendiri.
        private void IsiContoh()
        {
            dgvKeranjang.Rows.Add("Buku tulis", "2", "9.000");
            dgvKeranjang.Rows.Add("Pulpen hitam", "1", "3.500");
            dgvKeranjang.Rows.Add("Roti cokelat", "1", "6.500");
            dgvKeranjang.ClearSelection();
        }
    }
}
