namespace SMKMart.Pages
{
    partial class ucDataBarang
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblJudul = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.btnTambah = new SMKMart.Controls.RoundedButton();
            this.txtCari = new SMKMart.Controls.RoundedTextBox();
            this.pnlCboFilterKategori = new SMKMart.Controls.RoundedPanel();
            this.cboFilterKategori = new System.Windows.Forms.ComboBox();
            this.pnlTabel = new SMKMart.Controls.RoundedPanel();
            this.dgvBarang = new SMKMart.Controls.DarkGrid();
            this.pnlForm = new SMKMart.Controls.RoundedPanel();
            this.lblFormJudul = new System.Windows.Forms.Label();
            this.lblKode = new System.Windows.Forms.Label();
            this.lblNama = new System.Windows.Forms.Label();
            this.lblKategori = new System.Windows.Forms.Label();
            this.lblHarga = new System.Windows.Forms.Label();
            this.lblStok = new System.Windows.Forms.Label();
            this.lblStokMin = new System.Windows.Forms.Label();
            this.txtKode = new SMKMart.Controls.RoundedTextBox();
            this.txtNama = new SMKMart.Controls.RoundedTextBox();
            this.pnlCboKategori = new SMKMart.Controls.RoundedPanel();
            this.cboKategori = new System.Windows.Forms.ComboBox();
            this.txtHarga = new SMKMart.Controls.RoundedTextBox();
            this.txtStok = new SMKMart.Controls.RoundedTextBox();
            this.txtStokMin = new SMKMart.Controls.RoundedTextBox();
            this.btnBatal = new SMKMart.Controls.RoundedButton();
            this.btnSimpan = new SMKMart.Controls.RoundedButton();
            this.colKode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNama = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKategori = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colHarga = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStok = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colMin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEdit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.colHapus = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBarang)).BeginInit();
            this.SuspendLayout();
            this.pnlCboFilterKategori.SuspendLayout();
            this.pnlTabel.SuspendLayout();
            this.pnlForm.SuspendLayout();
            this.pnlCboKategori.SuspendLayout();
            //
            // lblJudul
            //
            this.lblJudul.Location = new System.Drawing.Point(28, 20);
            this.lblJudul.AutoSize = true;
            this.lblJudul.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblJudul.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblJudul.Text = "Data Barang";
            this.lblJudul.Name = "lblJudul";
            // lblSub
            //
            this.lblSub.Location = new System.Drawing.Point(30, 62);
            this.lblSub.AutoSize = true;
            this.lblSub.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSub.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSub.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSub.Text = "Kelola daftar barang, harga, dan stok minimum";
            this.lblSub.Name = "lblSub";
            // btnTambah
            //
            this.btnTambah.Location = new System.Drawing.Point(770, 22);
            this.btnTambah.Size = new System.Drawing.Size(172, 48);
            this.btnTambah.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnTambah.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnTambah.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTambah.Radius = 14;
            this.btnTambah.UseVisualStyleBackColor = false;
            this.btnTambah.Text = "+  Tambah barang";
            this.btnTambah.Name = "btnTambah";
            // txtCari
            //
            this.txtCari.Location = new System.Drawing.Point(28, 92);
            this.txtCari.Size = new System.Drawing.Size(740, 46);
            this.txtCari.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.txtCari.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtCari.PlaceholderText = "Cari kode atau nama barang";
            this.txtCari.Name = "txtCari";
            // pnlCboFilterKategori
            //
            this.pnlCboFilterKategori.Location = new System.Drawing.Point(780, 92);
            this.pnlCboFilterKategori.Size = new System.Drawing.Size(162, 46);
            this.pnlCboFilterKategori.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlCboFilterKategori.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlCboFilterKategori.Radius = 12;
            this.pnlCboFilterKategori.BorderColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlCboFilterKategori.BorderSize = 1;
            this.pnlCboFilterKategori.Name = "pnlCboFilterKategori";
            this.pnlCboFilterKategori.Controls.Add(this.cboFilterKategori);
            // cboFilterKategori
            //
            this.cboFilterKategori.Location = new System.Drawing.Point(12, 8);
            this.cboFilterKategori.Size = new System.Drawing.Size(138, 30);
            this.cboFilterKategori.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.cboFilterKategori.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.cboFilterKategori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboFilterKategori.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboFilterKategori.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.cboFilterKategori.FormattingEnabled = true;
            this.cboFilterKategori.Name = "cboFilterKategori";
            this.cboFilterKategori.Items.AddRange(new object[] { "Semua kategori", "ATK", "Makanan", "Minuman", "Sembako" });
            this.cboFilterKategori.SelectedIndex = 0;
            // pnlTabel
            //
            this.pnlTabel.Location = new System.Drawing.Point(28, 152);
            this.pnlTabel.Size = new System.Drawing.Size(914, 262);
            this.pnlTabel.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlTabel.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTabel.Radius = 14;
            this.pnlTabel.Name = "pnlTabel";
            this.pnlTabel.Controls.Add(this.dgvBarang);
            // dgvBarang
            //
            this.dgvBarang.Location = new System.Drawing.Point(12, 10);
            this.dgvBarang.Size = new System.Drawing.Size(890, 242);
            this.dgvBarang.BackgroundColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.dgvBarang.Name = "dgvBarang";
            this.colKode.HeaderText = "Kode";
            this.colKode.Name = "colKode";
            this.colKode.FillWeight = 12F;
            this.colKode.MinimumWidth = 6;
            this.colNama.HeaderText = "Nama";
            this.colNama.Name = "colNama";
            this.colNama.FillWeight = 24F;
            this.colNama.MinimumWidth = 6;
            this.colKategori.HeaderText = "Kategori";
            this.colKategori.Name = "colKategori";
            this.colKategori.FillWeight = 13F;
            this.colKategori.MinimumWidth = 6;
            this.colHarga.HeaderText = "Harga";
            this.colHarga.Name = "colHarga";
            this.colHarga.FillWeight = 12F;
            this.colHarga.MinimumWidth = 6;
            this.colHarga.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colHarga.HeaderCell.Style = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colStok.HeaderText = "Stok";
            this.colStok.Name = "colStok";
            this.colStok.FillWeight = 8F;
            this.colStok.MinimumWidth = 6;
            this.colStok.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colStok.HeaderCell.Style = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colMin.HeaderText = "Min";
            this.colMin.Name = "colMin";
            this.colMin.FillWeight = 8F;
            this.colMin.MinimumWidth = 6;
            this.colMin.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colMin.HeaderCell.Style = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colStatus.HeaderText = "Status";
            this.colStatus.Name = "colStatus";
            this.colStatus.FillWeight = 11F;
            this.colStatus.MinimumWidth = 6;
            this.colEdit.HeaderText = "Aksi";
            this.colEdit.Name = "colEdit";
            this.colEdit.FillWeight = 7F;
            this.colEdit.MinimumWidth = 6;
            this.colEdit.Text = "Edit";
            this.colEdit.UseColumnTextForButtonValue = true;
            this.colEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.colEdit.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter, BackColor = System.Drawing.Color.FromArgb(42, 58, 114), ForeColor = System.Drawing.Color.FromArgb(255, 255, 255), SelectionBackColor = System.Drawing.Color.FromArgb(42, 58, 114), SelectionForeColor = System.Drawing.Color.FromArgb(255, 255, 255) };
            this.colHapus.HeaderText = "";
            this.colHapus.Name = "colHapus";
            this.colHapus.FillWeight = 8F;
            this.colHapus.MinimumWidth = 6;
            this.colHapus.Text = "Hapus";
            this.colHapus.UseColumnTextForButtonValue = true;
            this.colHapus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.colHapus.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter, BackColor = System.Drawing.Color.FromArgb(42, 58, 114), ForeColor = System.Drawing.Color.FromArgb(255, 255, 255), SelectionBackColor = System.Drawing.Color.FromArgb(42, 58, 114), SelectionForeColor = System.Drawing.Color.FromArgb(255, 255, 255) };
            this.dgvBarang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { this.colKode, this.colNama, this.colKategori, this.colHarga, this.colStok, this.colMin, this.colStatus, this.colEdit, this.colHapus });
            // pnlForm
            //
            this.pnlForm.Location = new System.Drawing.Point(28, 428);
            this.pnlForm.Size = new System.Drawing.Size(914, 280);
            this.pnlForm.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlForm.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlForm.Radius = 14;
            this.pnlForm.Name = "pnlForm";
            this.pnlForm.Controls.Add(this.lblFormJudul);
            this.pnlForm.Controls.Add(this.lblKode);
            this.pnlForm.Controls.Add(this.lblNama);
            this.pnlForm.Controls.Add(this.lblKategori);
            this.pnlForm.Controls.Add(this.lblHarga);
            this.pnlForm.Controls.Add(this.lblStok);
            this.pnlForm.Controls.Add(this.lblStokMin);
            this.pnlForm.Controls.Add(this.txtKode);
            this.pnlForm.Controls.Add(this.txtNama);
            this.pnlForm.Controls.Add(this.pnlCboKategori);
            this.pnlForm.Controls.Add(this.txtHarga);
            this.pnlForm.Controls.Add(this.txtStok);
            this.pnlForm.Controls.Add(this.txtStokMin);
            this.pnlForm.Controls.Add(this.btnBatal);
            this.pnlForm.Controls.Add(this.btnSimpan);
            // lblFormJudul
            //
            this.lblFormJudul.Location = new System.Drawing.Point(18, 14);
            this.lblFormJudul.AutoSize = true;
            this.lblFormJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblFormJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblFormJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblFormJudul.Text = "Tambah barang baru";
            this.lblFormJudul.Name = "lblFormJudul";
            // lblKode
            //
            this.lblKode.Location = new System.Drawing.Point(20, 46);
            this.lblKode.AutoSize = true;
            this.lblKode.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblKode.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblKode.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblKode.Text = "Kode";
            this.lblKode.Name = "lblKode";
            // lblNama
            //
            this.lblNama.Location = new System.Drawing.Point(222, 46);
            this.lblNama.AutoSize = true;
            this.lblNama.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblNama.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblNama.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNama.Text = "Nama barang";
            this.lblNama.Name = "lblNama";
            // lblKategori
            //
            this.lblKategori.Location = new System.Drawing.Point(624, 46);
            this.lblKategori.AutoSize = true;
            this.lblKategori.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblKategori.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblKategori.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblKategori.Text = "Kategori";
            this.lblKategori.Name = "lblKategori";
            // lblHarga
            //
            this.lblHarga.Location = new System.Drawing.Point(20, 132);
            this.lblHarga.AutoSize = true;
            this.lblHarga.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHarga.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHarga.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHarga.Text = "Harga";
            this.lblHarga.Name = "lblHarga";
            // lblStok
            //
            this.lblStok.Location = new System.Drawing.Point(222, 132);
            this.lblStok.AutoSize = true;
            this.lblStok.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStok.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStok.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblStok.Text = "Stok";
            this.lblStok.Name = "lblStok";
            // lblStokMin
            //
            this.lblStokMin.Location = new System.Drawing.Point(424, 132);
            this.lblStokMin.AutoSize = true;
            this.lblStokMin.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokMin.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStokMin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblStokMin.Text = "Stok minimum";
            this.lblStokMin.Name = "lblStokMin";
            // txtKode
            //
            this.txtKode.Location = new System.Drawing.Point(18, 68);
            this.txtKode.Size = new System.Drawing.Size(190, 46);
            this.txtKode.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtKode.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtKode.ReadOnly = true;
            this.txtKode.Text = "BRG-005";
            this.txtKode.Name = "txtKode";
            // txtNama
            //
            this.txtNama.Location = new System.Drawing.Point(220, 68);
            this.txtNama.Size = new System.Drawing.Size(390, 46);
            this.txtNama.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtNama.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtNama.PlaceholderText = "mis. Penggaris";
            this.txtNama.Name = "txtNama";
            // pnlCboKategori
            //
            this.pnlCboKategori.Location = new System.Drawing.Point(622, 68);
            this.pnlCboKategori.Size = new System.Drawing.Size(274, 46);
            this.pnlCboKategori.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlCboKategori.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlCboKategori.Radius = 12;
            this.pnlCboKategori.BorderColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlCboKategori.BorderSize = 1;
            this.pnlCboKategori.Name = "pnlCboKategori";
            this.pnlCboKategori.Controls.Add(this.cboKategori);
            // cboKategori
            //
            this.cboKategori.Location = new System.Drawing.Point(12, 8);
            this.cboKategori.Size = new System.Drawing.Size(250, 30);
            this.cboKategori.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.cboKategori.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.cboKategori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboKategori.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboKategori.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.cboKategori.FormattingEnabled = true;
            this.cboKategori.Name = "cboKategori";
            this.cboKategori.Items.AddRange(new object[] { "ATK", "Makanan", "Minuman", "Sembako", "Lainnya" });
            this.cboKategori.SelectedIndex = 0;
            // txtHarga
            //
            this.txtHarga.Location = new System.Drawing.Point(18, 154);
            this.txtHarga.Size = new System.Drawing.Size(190, 46);
            this.txtHarga.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtHarga.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtHarga.PlaceholderText = "mis. 2500";
            this.txtHarga.Name = "txtHarga";
            // txtStok
            //
            this.txtStok.Location = new System.Drawing.Point(220, 154);
            this.txtStok.Size = new System.Drawing.Size(190, 46);
            this.txtStok.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtStok.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtStok.PlaceholderText = "mis. 20";
            this.txtStok.Name = "txtStok";
            // txtStokMin
            //
            this.txtStokMin.Location = new System.Drawing.Point(422, 154);
            this.txtStokMin.Size = new System.Drawing.Size(190, 46);
            this.txtStokMin.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtStokMin.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtStokMin.PlaceholderText = "mis. 10";
            this.txtStokMin.Name = "txtStokMin";
            // btnBatal
            //
            this.btnBatal.Location = new System.Drawing.Point(586, 216);
            this.btnBatal.Size = new System.Drawing.Size(150, 46);
            this.btnBatal.BackColor = System.Drawing.Color.FromArgb(42, 58, 114);
            this.btnBatal.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnBatal.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnBatal.Radius = 12;
            this.btnBatal.UseVisualStyleBackColor = false;
            this.btnBatal.Text = "Batal";
            this.btnBatal.Name = "btnBatal";
            // btnSimpan
            //
            this.btnSimpan.Location = new System.Drawing.Point(746, 216);
            this.btnSimpan.Size = new System.Drawing.Size(150, 46);
            this.btnSimpan.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnSimpan.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnSimpan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSimpan.Radius = 12;
            this.btnSimpan.UseVisualStyleBackColor = false;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.Name = "btnSimpan";
            //
            // ucDataBarang
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.Size = new System.Drawing.Size(970, 720);
            this.Name = "ucDataBarang";
            this.Controls.Add(this.lblJudul);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.btnTambah);
            this.Controls.Add(this.txtCari);
            this.Controls.Add(this.pnlCboFilterKategori);
            this.Controls.Add(this.pnlTabel);
            this.Controls.Add(this.pnlForm);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBarang)).EndInit();
            this.pnlCboFilterKategori.ResumeLayout(false);
            this.pnlTabel.ResumeLayout(false);
            this.pnlForm.ResumeLayout(false);
            this.pnlCboKategori.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label lblJudul;
        private System.Windows.Forms.Label lblSub;
        private SMKMart.Controls.RoundedButton btnTambah;
        private SMKMart.Controls.RoundedTextBox txtCari;
        private SMKMart.Controls.RoundedPanel pnlCboFilterKategori;
        private System.Windows.Forms.ComboBox cboFilterKategori;
        private SMKMart.Controls.RoundedPanel pnlTabel;
        private SMKMart.Controls.DarkGrid dgvBarang;
        private SMKMart.Controls.RoundedPanel pnlForm;
        private System.Windows.Forms.Label lblFormJudul;
        private System.Windows.Forms.Label lblKode;
        private System.Windows.Forms.Label lblNama;
        private System.Windows.Forms.Label lblKategori;
        private System.Windows.Forms.Label lblHarga;
        private System.Windows.Forms.Label lblStok;
        private System.Windows.Forms.Label lblStokMin;
        private SMKMart.Controls.RoundedTextBox txtKode;
        private SMKMart.Controls.RoundedTextBox txtNama;
        private SMKMart.Controls.RoundedPanel pnlCboKategori;
        private System.Windows.Forms.ComboBox cboKategori;
        private SMKMart.Controls.RoundedTextBox txtHarga;
        private SMKMart.Controls.RoundedTextBox txtStok;
        private SMKMart.Controls.RoundedTextBox txtStokMin;
        private SMKMart.Controls.RoundedButton btnBatal;
        private SMKMart.Controls.RoundedButton btnSimpan;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKode;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNama;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKategori;
        private System.Windows.Forms.DataGridViewTextBoxColumn colHarga;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStok;
        private System.Windows.Forms.DataGridViewTextBoxColumn colMin;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatus;
        private System.Windows.Forms.DataGridViewButtonColumn colEdit;
        private System.Windows.Forms.DataGridViewButtonColumn colHapus;
    }
}
