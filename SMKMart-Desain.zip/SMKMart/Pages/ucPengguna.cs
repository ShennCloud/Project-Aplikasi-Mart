using System.Windows.Forms;

namespace SMKMart.Pages
{
    public partial class ucPengguna : UserControl
    {
        public ucPengguna()
        {
            InitializeComponent();
        }
    }
}
