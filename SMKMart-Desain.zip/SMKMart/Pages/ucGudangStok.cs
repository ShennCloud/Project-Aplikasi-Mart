using System.Windows.Forms;

namespace SMKMart.Pages
{
    public partial class ucGudangStok : UserControl
    {
        public ucGudangStok()
        {
            InitializeComponent();
        }
    }
}
