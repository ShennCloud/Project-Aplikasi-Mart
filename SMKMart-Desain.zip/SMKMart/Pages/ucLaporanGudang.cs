using System.Windows.Forms;

namespace SMKMart.Pages
{
    public partial class ucLaporanGudang : UserControl
    {
        public ucLaporanGudang()
        {
            InitializeComponent();
        }
    }
}
