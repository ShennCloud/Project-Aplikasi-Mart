using System.Drawing;
using System.Windows.Forms;

namespace SMKMart.Pages
{
    public partial class ucDashboard : UserControl
    {
        public ucDashboard()
        {
            InitializeComponent();
            IsiContoh();
        }

        // DATA CONTOH supaya tampilan di Designer tidak kosong.
        // Hapus method ini (dan pemanggilannya) kalau sudah mengisi data sendiri.
        private void IsiContoh()
        {
            dgvTransaksi.Rows.Add("TRX-0038", "10:42", "Rina", "87.500");
            dgvTransaksi.Rows.Add("TRX-0037", "10:31", "Rina", "42.000");
            dgvTransaksi.Rows.Add("TRX-0036", "10:15", "Dimas", "125.000");
            dgvTransaksi.Rows.Add("TRX-0035", "09:58", "Rina", "36.500");
            dgvTransaksi.ClearSelection();
        }
    }
}
