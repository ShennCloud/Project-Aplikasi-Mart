using System.Drawing;
using System.Windows.Forms;

namespace SMKMart.Pages
{
    public partial class ucLaporanPenjualan : UserControl
    {
        public ucLaporanPenjualan()
        {
            InitializeComponent();
            IsiContoh();
        }

        // DATA CONTOH supaya tampilan di Designer tidak kosong.
        // Hapus method ini (dan pemanggilannya) kalau sudah mengisi data sendiri.
        private void IsiContoh()
        {
            dgvLaporan.Rows.Add("03/10/2026", "TRX-0038", "Rina", "6", "87.500");
            dgvLaporan.Rows.Add("03/10/2026", "TRX-0037", "Rina", "3", "42.000");
            dgvLaporan.Rows.Add("02/10/2026", "TRX-0036", "Dimas", "9", "125.000");
            dgvLaporan.ClearSelection();
        }
    }
}
