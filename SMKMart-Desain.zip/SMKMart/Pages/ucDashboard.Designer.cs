namespace SMKMart.Pages
{
    partial class ucDashboard
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblHalo = new System.Windows.Forms.Label();
            this.lblTanggal = new System.Windows.Forms.Label();
            this.lblAvatar = new SMKMart.Controls.RoundedLabel();
            this.pnlStat1 = new SMKMart.Controls.RoundedPanel();
            this.lblStat1Judul = new System.Windows.Forms.Label();
            this.lblStat1Nilai = new System.Windows.Forms.Label();
            this.pnlStat2 = new SMKMart.Controls.RoundedPanel();
            this.lblStat2Judul = new System.Windows.Forms.Label();
            this.lblStat2Nilai = new System.Windows.Forms.Label();
            this.pnlStat3 = new SMKMart.Controls.RoundedPanel();
            this.lblStat3Judul = new System.Windows.Forms.Label();
            this.lblStat3Nilai = new System.Windows.Forms.Label();
            this.pnlStat4 = new SMKMart.Controls.RoundedPanel();
            this.lblStat4Judul = new System.Windows.Forms.Label();
            this.lblStat4Nilai = new System.Windows.Forms.Label();
            this.pnlGrafik = new SMKMart.Controls.RoundedPanel();
            this.lblGrafikJudul = new System.Windows.Forms.Label();
            this.pnlBar1 = new SMKMart.Controls.RoundedPanel();
            this.lblHari1 = new System.Windows.Forms.Label();
            this.pnlBar2 = new SMKMart.Controls.RoundedPanel();
            this.lblHari2 = new System.Windows.Forms.Label();
            this.pnlBar3 = new SMKMart.Controls.RoundedPanel();
            this.lblHari3 = new System.Windows.Forms.Label();
            this.pnlBar4 = new SMKMart.Controls.RoundedPanel();
            this.lblHari4 = new System.Windows.Forms.Label();
            this.pnlBar5 = new SMKMart.Controls.RoundedPanel();
            this.lblHari5 = new System.Windows.Forms.Label();
            this.pnlBar6 = new SMKMart.Controls.RoundedPanel();
            this.lblHari6 = new System.Windows.Forms.Label();
            this.pnlBar7 = new SMKMart.Controls.RoundedPanel();
            this.lblHari7 = new System.Windows.Forms.Label();
            this.pnlStokMenipis = new SMKMart.Controls.RoundedPanel();
            this.lblStokJudul = new System.Windows.Forms.Label();
            this.lblStokNama1 = new System.Windows.Forms.Label();
            this.lblStokBadge1 = new SMKMart.Controls.RoundedLabel();
            this.pnlGarisStok1 = new SMKMart.Controls.RoundedPanel();
            this.lblStokNama2 = new System.Windows.Forms.Label();
            this.lblStokBadge2 = new SMKMart.Controls.RoundedLabel();
            this.pnlGarisStok2 = new SMKMart.Controls.RoundedPanel();
            this.lblStokNama3 = new System.Windows.Forms.Label();
            this.lblStokBadge3 = new SMKMart.Controls.RoundedLabel();
            this.pnlGarisStok3 = new SMKMart.Controls.RoundedPanel();
            this.lblStokNama4 = new System.Windows.Forms.Label();
            this.lblStokBadge4 = new SMKMart.Controls.RoundedLabel();
            this.pnlTransaksi = new SMKMart.Controls.RoundedPanel();
            this.lblTransaksiJudul = new System.Windows.Forms.Label();
            this.lnkLihatSemua = new System.Windows.Forms.LinkLabel();
            this.dgvTransaksi = new SMKMart.Controls.DarkGrid();
            this.pnlStruk = new SMKMart.Controls.RoundedPanel();
            this.lblStruk = new System.Windows.Forms.Label();
            this.colNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colJam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKasir = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransaksi)).BeginInit();
            this.SuspendLayout();
            this.pnlStat1.SuspendLayout();
            this.pnlStat2.SuspendLayout();
            this.pnlStat3.SuspendLayout();
            this.pnlStat4.SuspendLayout();
            this.pnlGrafik.SuspendLayout();
            this.pnlStokMenipis.SuspendLayout();
            this.pnlTransaksi.SuspendLayout();
            this.pnlStruk.SuspendLayout();
            //
            // lblHalo
            //
            this.lblHalo.Location = new System.Drawing.Point(28, 20);
            this.lblHalo.AutoSize = true;
            this.lblHalo.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblHalo.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblHalo.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblHalo.Text = "Halo, Admin";
            this.lblHalo.Name = "lblHalo";
            // lblTanggal
            //
            this.lblTanggal.Location = new System.Drawing.Point(30, 62);
            this.lblTanggal.AutoSize = true;
            this.lblTanggal.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblTanggal.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblTanggal.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTanggal.Text = "Jumat, 2 Oktober 2026";
            this.lblTanggal.Name = "lblTanggal";
            // lblAvatar
            //
            this.lblAvatar.Location = new System.Drawing.Point(896, 18);
            this.lblAvatar.Size = new System.Drawing.Size(44, 44);
            this.lblAvatar.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblAvatar.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblAvatar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblAvatar.Radius = 22;
            this.lblAvatar.Text = "A";
            this.lblAvatar.Name = "lblAvatar";
            // pnlStat1
            //
            this.pnlStat1.Location = new System.Drawing.Point(28, 100);
            this.pnlStat1.Size = new System.Drawing.Size(219, 92);
            this.pnlStat1.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat1.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlStat1.Radius = 14;
            this.pnlStat1.Name = "pnlStat1";
            this.pnlStat1.Controls.Add(this.lblStat1Judul);
            this.pnlStat1.Controls.Add(this.lblStat1Nilai);
            // lblStat1Judul
            //
            this.lblStat1Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat1Judul.AutoSize = true;
            this.lblStat1Judul.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblStat1Judul.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat1Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat1Judul.Text = "Penjualan hari ini";
            this.lblStat1Judul.Name = "lblStat1Judul";
            // lblStat1Nilai
            //
            this.lblStat1Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat1Nilai.AutoSize = true;
            this.lblStat1Nilai.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblStat1Nilai.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat1Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat1Nilai.Text = "Rp 2.450.000";
            this.lblStat1Nilai.Name = "lblStat1Nilai";
            // pnlStat2
            //
            this.pnlStat2.Location = new System.Drawing.Point(259, 100);
            this.pnlStat2.Size = new System.Drawing.Size(219, 92);
            this.pnlStat2.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat2.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStat2.Radius = 14;
            this.pnlStat2.Name = "pnlStat2";
            this.pnlStat2.Controls.Add(this.lblStat2Judul);
            this.pnlStat2.Controls.Add(this.lblStat2Nilai);
            // lblStat2Judul
            //
            this.lblStat2Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat2Judul.AutoSize = true;
            this.lblStat2Judul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Judul.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStat2Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat2Judul.Text = "Barang masuk";
            this.lblStat2Judul.Name = "lblStat2Judul";
            // lblStat2Nilai
            //
            this.lblStat2Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat2Nilai.AutoSize = true;
            this.lblStat2Nilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Nilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStat2Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat2Nilai.Text = "120";
            this.lblStat2Nilai.Name = "lblStat2Nilai";
            // pnlStat3
            //
            this.pnlStat3.Location = new System.Drawing.Point(490, 100);
            this.pnlStat3.Size = new System.Drawing.Size(219, 92);
            this.pnlStat3.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat3.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStat3.Radius = 14;
            this.pnlStat3.Name = "pnlStat3";
            this.pnlStat3.Controls.Add(this.lblStat3Judul);
            this.pnlStat3.Controls.Add(this.lblStat3Nilai);
            // lblStat3Judul
            //
            this.lblStat3Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat3Judul.AutoSize = true;
            this.lblStat3Judul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat3Judul.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStat3Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat3Judul.Text = "Barang keluar";
            this.lblStat3Judul.Name = "lblStat3Judul";
            // lblStat3Nilai
            //
            this.lblStat3Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat3Nilai.AutoSize = true;
            this.lblStat3Nilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat3Nilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStat3Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat3Nilai.Text = "95";
            this.lblStat3Nilai.Name = "lblStat3Nilai";
            // pnlStat4
            //
            this.pnlStat4.Location = new System.Drawing.Point(721, 100);
            this.pnlStat4.Size = new System.Drawing.Size(219, 92);
            this.pnlStat4.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat4.FillColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlStat4.Radius = 14;
            this.pnlStat4.Name = "pnlStat4";
            this.pnlStat4.Controls.Add(this.lblStat4Judul);
            this.pnlStat4.Controls.Add(this.lblStat4Nilai);
            // lblStat4Judul
            //
            this.lblStat4Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat4Judul.AutoSize = true;
            this.lblStat4Judul.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat4Judul.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat4Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat4Judul.Text = "Stok minimum";
            this.lblStat4Judul.Name = "lblStat4Judul";
            // lblStat4Nilai
            //
            this.lblStat4Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat4Nilai.AutoSize = true;
            this.lblStat4Nilai.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat4Nilai.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat4Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat4Nilai.Text = "4 barang";
            this.lblStat4Nilai.Name = "lblStat4Nilai";
            // pnlGrafik
            //
            this.pnlGrafik.Location = new System.Drawing.Point(28, 206);
            this.pnlGrafik.Size = new System.Drawing.Size(540, 256);
            this.pnlGrafik.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlGrafik.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGrafik.Radius = 14;
            this.pnlGrafik.Name = "pnlGrafik";
            this.pnlGrafik.Controls.Add(this.lblGrafikJudul);
            this.pnlGrafik.Controls.Add(this.pnlBar1);
            this.pnlGrafik.Controls.Add(this.lblHari1);
            this.pnlGrafik.Controls.Add(this.pnlBar2);
            this.pnlGrafik.Controls.Add(this.lblHari2);
            this.pnlGrafik.Controls.Add(this.pnlBar3);
            this.pnlGrafik.Controls.Add(this.lblHari3);
            this.pnlGrafik.Controls.Add(this.pnlBar4);
            this.pnlGrafik.Controls.Add(this.lblHari4);
            this.pnlGrafik.Controls.Add(this.pnlBar5);
            this.pnlGrafik.Controls.Add(this.lblHari5);
            this.pnlGrafik.Controls.Add(this.pnlBar6);
            this.pnlGrafik.Controls.Add(this.lblHari6);
            this.pnlGrafik.Controls.Add(this.pnlBar7);
            this.pnlGrafik.Controls.Add(this.lblHari7);
            // lblGrafikJudul
            //
            this.lblGrafikJudul.Location = new System.Drawing.Point(18, 14);
            this.lblGrafikJudul.AutoSize = true;
            this.lblGrafikJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblGrafikJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblGrafikJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblGrafikJudul.Text = "Penjualan 7 hari terakhir";
            this.lblGrafikJudul.Name = "lblGrafikJudul";
            // pnlBar1
            //
            this.pnlBar1.Location = new System.Drawing.Point(31, 130);
            this.pnlBar1.Size = new System.Drawing.Size(46, 86);
            this.pnlBar1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar1.FillColor = System.Drawing.Color.FromArgb(44, 62, 126);
            this.pnlBar1.Radius = 6;
            this.pnlBar1.Name = "pnlBar1";
            // lblHari1
            //
            this.lblHari1.Location = new System.Drawing.Point(18, 224);
            this.lblHari1.Size = new System.Drawing.Size(72, 18);
            this.lblHari1.AutoSize = false;
            this.lblHari1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari1.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHari1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHari1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari1.Text = "Sab";
            this.lblHari1.Name = "lblHari1";
            // pnlBar2
            //
            this.pnlBar2.Location = new System.Drawing.Point(103, 96);
            this.pnlBar2.Size = new System.Drawing.Size(46, 120);
            this.pnlBar2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar2.FillColor = System.Drawing.Color.FromArgb(44, 62, 126);
            this.pnlBar2.Radius = 6;
            this.pnlBar2.Name = "pnlBar2";
            // lblHari2
            //
            this.lblHari2.Location = new System.Drawing.Point(90, 224);
            this.lblHari2.Size = new System.Drawing.Size(72, 18);
            this.lblHari2.AutoSize = false;
            this.lblHari2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari2.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHari2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHari2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari2.Text = "Min";
            this.lblHari2.Name = "lblHari2";
            // pnlBar3
            //
            this.pnlBar3.Location = new System.Drawing.Point(175, 150);
            this.pnlBar3.Size = new System.Drawing.Size(46, 66);
            this.pnlBar3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar3.FillColor = System.Drawing.Color.FromArgb(44, 62, 126);
            this.pnlBar3.Radius = 6;
            this.pnlBar3.Name = "pnlBar3";
            // lblHari3
            //
            this.lblHari3.Location = new System.Drawing.Point(162, 224);
            this.lblHari3.Size = new System.Drawing.Size(72, 18);
            this.lblHari3.AutoSize = false;
            this.lblHari3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari3.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHari3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHari3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari3.Text = "Sen";
            this.lblHari3.Name = "lblHari3";
            // pnlBar4
            //
            this.pnlBar4.Location = new System.Drawing.Point(247, 114);
            this.pnlBar4.Size = new System.Drawing.Size(46, 102);
            this.pnlBar4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar4.FillColor = System.Drawing.Color.FromArgb(44, 62, 126);
            this.pnlBar4.Radius = 6;
            this.pnlBar4.Name = "pnlBar4";
            // lblHari4
            //
            this.lblHari4.Location = new System.Drawing.Point(234, 224);
            this.lblHari4.Size = new System.Drawing.Size(72, 18);
            this.lblHari4.AutoSize = false;
            this.lblHari4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari4.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHari4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHari4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari4.Text = "Sel";
            this.lblHari4.Name = "lblHari4";
            // pnlBar5
            //
            this.pnlBar5.Location = new System.Drawing.Point(319, 138);
            this.pnlBar5.Size = new System.Drawing.Size(46, 78);
            this.pnlBar5.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar5.FillColor = System.Drawing.Color.FromArgb(44, 62, 126);
            this.pnlBar5.Radius = 6;
            this.pnlBar5.Name = "pnlBar5";
            // lblHari5
            //
            this.lblHari5.Location = new System.Drawing.Point(306, 224);
            this.lblHari5.Size = new System.Drawing.Size(72, 18);
            this.lblHari5.AutoSize = false;
            this.lblHari5.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari5.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHari5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHari5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari5.Text = "Rab";
            this.lblHari5.Name = "lblHari5";
            // pnlBar6
            //
            this.pnlBar6.Location = new System.Drawing.Point(391, 84);
            this.pnlBar6.Size = new System.Drawing.Size(46, 132);
            this.pnlBar6.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar6.FillColor = System.Drawing.Color.FromArgb(44, 62, 126);
            this.pnlBar6.Radius = 6;
            this.pnlBar6.Name = "pnlBar6";
            // lblHari6
            //
            this.lblHari6.Location = new System.Drawing.Point(378, 224);
            this.lblHari6.Size = new System.Drawing.Size(72, 18);
            this.lblHari6.AutoSize = false;
            this.lblHari6.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari6.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHari6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHari6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari6.Text = "Kam";
            this.lblHari6.Name = "lblHari6";
            // pnlBar7
            //
            this.pnlBar7.Location = new System.Drawing.Point(463, 68);
            this.pnlBar7.Size = new System.Drawing.Size(46, 148);
            this.pnlBar7.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar7.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlBar7.Radius = 6;
            this.pnlBar7.Name = "pnlBar7";
            // lblHari7
            //
            this.lblHari7.Location = new System.Drawing.Point(450, 224);
            this.lblHari7.Size = new System.Drawing.Size(72, 18);
            this.lblHari7.AutoSize = false;
            this.lblHari7.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari7.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblHari7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblHari7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari7.Text = "Jum";
            this.lblHari7.Name = "lblHari7";
            // pnlStokMenipis
            //
            this.pnlStokMenipis.Location = new System.Drawing.Point(580, 206);
            this.pnlStokMenipis.Size = new System.Drawing.Size(362, 256);
            this.pnlStokMenipis.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStokMenipis.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStokMenipis.Radius = 14;
            this.pnlStokMenipis.Name = "pnlStokMenipis";
            this.pnlStokMenipis.Controls.Add(this.lblStokJudul);
            this.pnlStokMenipis.Controls.Add(this.lblStokNama1);
            this.pnlStokMenipis.Controls.Add(this.lblStokBadge1);
            this.pnlStokMenipis.Controls.Add(this.pnlGarisStok1);
            this.pnlStokMenipis.Controls.Add(this.lblStokNama2);
            this.pnlStokMenipis.Controls.Add(this.lblStokBadge2);
            this.pnlStokMenipis.Controls.Add(this.pnlGarisStok2);
            this.pnlStokMenipis.Controls.Add(this.lblStokNama3);
            this.pnlStokMenipis.Controls.Add(this.lblStokBadge3);
            this.pnlStokMenipis.Controls.Add(this.pnlGarisStok3);
            this.pnlStokMenipis.Controls.Add(this.lblStokNama4);
            this.pnlStokMenipis.Controls.Add(this.lblStokBadge4);
            // lblStokJudul
            //
            this.lblStokJudul.Location = new System.Drawing.Point(18, 14);
            this.lblStokJudul.AutoSize = true;
            this.lblStokJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblStokJudul.Text = "Stok hampir habis";
            this.lblStokJudul.Name = "lblStokJudul";
            // lblStokNama1
            //
            this.lblStokNama1.Location = new System.Drawing.Point(18, 54);
            this.lblStokNama1.AutoSize = true;
            this.lblStokNama1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNama1.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokNama1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblStokNama1.Text = "Beras 5 kg";
            this.lblStokNama1.Name = "lblStokNama1";
            // lblStokBadge1
            //
            this.lblStokBadge1.Location = new System.Drawing.Point(240, 51);
            this.lblStokBadge1.Size = new System.Drawing.Size(104, 26);
            this.lblStokBadge1.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStokBadge1.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStokBadge1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblStokBadge1.Radius = 8;
            this.lblStokBadge1.Text = "3 / min 10";
            this.lblStokBadge1.Name = "lblStokBadge1";
            // pnlGarisStok1
            //
            this.pnlGarisStok1.Location = new System.Drawing.Point(18, 88);
            this.pnlGarisStok1.Size = new System.Drawing.Size(326, 1);
            this.pnlGarisStok1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGarisStok1.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGarisStok1.Radius = 0;
            this.pnlGarisStok1.Name = "pnlGarisStok1";
            // lblStokNama2
            //
            this.lblStokNama2.Location = new System.Drawing.Point(18, 104);
            this.lblStokNama2.AutoSize = true;
            this.lblStokNama2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNama2.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokNama2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblStokNama2.Text = "Minyak goreng 1 L";
            this.lblStokNama2.Name = "lblStokNama2";
            // lblStokBadge2
            //
            this.lblStokBadge2.Location = new System.Drawing.Point(240, 101);
            this.lblStokBadge2.Size = new System.Drawing.Size(104, 26);
            this.lblStokBadge2.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStokBadge2.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStokBadge2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblStokBadge2.Radius = 8;
            this.lblStokBadge2.Text = "5 / min 12";
            this.lblStokBadge2.Name = "lblStokBadge2";
            // pnlGarisStok2
            //
            this.pnlGarisStok2.Location = new System.Drawing.Point(18, 138);
            this.pnlGarisStok2.Size = new System.Drawing.Size(326, 1);
            this.pnlGarisStok2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGarisStok2.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGarisStok2.Radius = 0;
            this.pnlGarisStok2.Name = "pnlGarisStok2";
            // lblStokNama3
            //
            this.lblStokNama3.Location = new System.Drawing.Point(18, 154);
            this.lblStokNama3.AutoSize = true;
            this.lblStokNama3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNama3.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokNama3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblStokNama3.Text = "Gula pasir 1 kg";
            this.lblStokNama3.Name = "lblStokNama3";
            // lblStokBadge3
            //
            this.lblStokBadge3.Location = new System.Drawing.Point(240, 151);
            this.lblStokBadge3.Size = new System.Drawing.Size(104, 26);
            this.lblStokBadge3.BackColor = System.Drawing.Color.FromArgb(44, 67, 150);
            this.lblStokBadge3.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokBadge3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblStokBadge3.Radius = 8;
            this.lblStokBadge3.Text = "8 / min 10";
            this.lblStokBadge3.Name = "lblStokBadge3";
            // pnlGarisStok3
            //
            this.pnlGarisStok3.Location = new System.Drawing.Point(18, 188);
            this.pnlGarisStok3.Size = new System.Drawing.Size(326, 1);
            this.pnlGarisStok3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGarisStok3.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGarisStok3.Radius = 0;
            this.pnlGarisStok3.Name = "pnlGarisStok3";
            // lblStokNama4
            //
            this.lblStokNama4.Location = new System.Drawing.Point(18, 204);
            this.lblStokNama4.AutoSize = true;
            this.lblStokNama4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNama4.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokNama4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblStokNama4.Text = "Mi instan";
            this.lblStokNama4.Name = "lblStokNama4";
            // lblStokBadge4
            //
            this.lblStokBadge4.Location = new System.Drawing.Point(240, 201);
            this.lblStokBadge4.Size = new System.Drawing.Size(104, 26);
            this.lblStokBadge4.BackColor = System.Drawing.Color.FromArgb(44, 67, 150);
            this.lblStokBadge4.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokBadge4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblStokBadge4.Radius = 8;
            this.lblStokBadge4.Text = "9 / min 15";
            this.lblStokBadge4.Name = "lblStokBadge4";
            // pnlTransaksi
            //
            this.pnlTransaksi.Location = new System.Drawing.Point(28, 476);
            this.pnlTransaksi.Size = new System.Drawing.Size(540, 232);
            this.pnlTransaksi.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlTransaksi.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTransaksi.Radius = 14;
            this.pnlTransaksi.Name = "pnlTransaksi";
            this.pnlTransaksi.Controls.Add(this.lblTransaksiJudul);
            this.pnlTransaksi.Controls.Add(this.lnkLihatSemua);
            this.pnlTransaksi.Controls.Add(this.dgvTransaksi);
            // lblTransaksiJudul
            //
            this.lblTransaksiJudul.Location = new System.Drawing.Point(18, 14);
            this.lblTransaksiJudul.AutoSize = true;
            this.lblTransaksiJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTransaksiJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblTransaksiJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTransaksiJudul.Text = "Transaksi terbaru";
            this.lblTransaksiJudul.Name = "lblTransaksiJudul";
            // lnkLihatSemua
            //
            this.lnkLihatSemua.Location = new System.Drawing.Point(436, 18);
            this.lnkLihatSemua.AutoSize = true;
            this.lnkLihatSemua.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lnkLihatSemua.ActiveLinkColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lnkLihatSemua.LinkColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lnkLihatSemua.VisitedLinkColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lnkLihatSemua.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnkLihatSemua.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lnkLihatSemua.Text = "Lihat semua";
            this.lnkLihatSemua.Name = "lnkLihatSemua";
            // dgvTransaksi
            //
            this.dgvTransaksi.Location = new System.Drawing.Point(14, 50);
            this.dgvTransaksi.Size = new System.Drawing.Size(512, 168);
            this.dgvTransaksi.BackgroundColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.dgvTransaksi.Name = "dgvTransaksi";
            this.colNo.HeaderText = "No.";
            this.colNo.Name = "colNo";
            this.colNo.FillWeight = 30F;
            this.colNo.MinimumWidth = 6;
            this.colJam.HeaderText = "Jam";
            this.colJam.Name = "colJam";
            this.colJam.FillWeight = 20F;
            this.colJam.MinimumWidth = 6;
            this.colKasir.HeaderText = "Kasir";
            this.colKasir.Name = "colKasir";
            this.colKasir.FillWeight = 22F;
            this.colKasir.MinimumWidth = 6;
            this.colTotal.HeaderText = "Total";
            this.colTotal.Name = "colTotal";
            this.colTotal.FillWeight = 28F;
            this.colTotal.MinimumWidth = 6;
            this.colTotal.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colTotal.HeaderCell.Style = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.dgvTransaksi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { this.colNo, this.colJam, this.colKasir, this.colTotal });
            // pnlStruk
            //
            this.pnlStruk.Location = new System.Drawing.Point(620, 490);
            this.pnlStruk.Size = new System.Drawing.Size(262, 196);
            this.pnlStruk.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStruk.FillColor = System.Drawing.Color.FromArgb(251, 247, 236);
            this.pnlStruk.Radius = 4;
            this.pnlStruk.Name = "pnlStruk";
            this.pnlStruk.Controls.Add(this.lblStruk);
            // lblStruk
            //
            this.lblStruk.Location = new System.Drawing.Point(16, 16);
            this.lblStruk.AutoSize = true;
            this.lblStruk.BackColor = System.Drawing.Color.FromArgb(251, 247, 236);
            this.lblStruk.ForeColor = System.Drawing.Color.FromArgb(34, 34, 34);
            this.lblStruk.Font = new System.Drawing.Font("Courier New", 9F);
            this.lblStruk.Text = "          SMKMART           \r\n       Struk terakhir       \r\n----------------------------\r\n2 Buku tulis           9.000\r\n1 Pulpen hitam         3.500\r\n1 Roti cokelat         6.500\r\n----------------------------\r\nTotal                 19.000";
            this.lblStruk.Name = "lblStruk";
            //
            // ucDashboard
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.Size = new System.Drawing.Size(970, 720);
            this.Name = "ucDashboard";
            this.Controls.Add(this.lblHalo);
            this.Controls.Add(this.lblTanggal);
            this.Controls.Add(this.lblAvatar);
            this.Controls.Add(this.pnlStat1);
            this.Controls.Add(this.pnlStat2);
            this.Controls.Add(this.pnlStat3);
            this.Controls.Add(this.pnlStat4);
            this.Controls.Add(this.pnlGrafik);
            this.Controls.Add(this.pnlStokMenipis);
            this.Controls.Add(this.pnlTransaksi);
            this.Controls.Add(this.pnlStruk);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTransaksi)).EndInit();
            this.pnlStat1.ResumeLayout(false);
            this.pnlStat2.ResumeLayout(false);
            this.pnlStat3.ResumeLayout(false);
            this.pnlStat4.ResumeLayout(false);
            this.pnlGrafik.ResumeLayout(false);
            this.pnlStokMenipis.ResumeLayout(false);
            this.pnlTransaksi.ResumeLayout(false);
            this.pnlStruk.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label lblHalo;
        private System.Windows.Forms.Label lblTanggal;
        private SMKMart.Controls.RoundedLabel lblAvatar;
        private SMKMart.Controls.RoundedPanel pnlStat1;
        private System.Windows.Forms.Label lblStat1Judul;
        private System.Windows.Forms.Label lblStat1Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat2;
        private System.Windows.Forms.Label lblStat2Judul;
        private System.Windows.Forms.Label lblStat2Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat3;
        private System.Windows.Forms.Label lblStat3Judul;
        private System.Windows.Forms.Label lblStat3Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat4;
        private System.Windows.Forms.Label lblStat4Judul;
        private System.Windows.Forms.Label lblStat4Nilai;
        private SMKMart.Controls.RoundedPanel pnlGrafik;
        private System.Windows.Forms.Label lblGrafikJudul;
        private SMKMart.Controls.RoundedPanel pnlBar1;
        private System.Windows.Forms.Label lblHari1;
        private SMKMart.Controls.RoundedPanel pnlBar2;
        private System.Windows.Forms.Label lblHari2;
        private SMKMart.Controls.RoundedPanel pnlBar3;
        private System.Windows.Forms.Label lblHari3;
        private SMKMart.Controls.RoundedPanel pnlBar4;
        private System.Windows.Forms.Label lblHari4;
        private SMKMart.Controls.RoundedPanel pnlBar5;
        private System.Windows.Forms.Label lblHari5;
        private SMKMart.Controls.RoundedPanel pnlBar6;
        private System.Windows.Forms.Label lblHari6;
        private SMKMart.Controls.RoundedPanel pnlBar7;
        private System.Windows.Forms.Label lblHari7;
        private SMKMart.Controls.RoundedPanel pnlStokMenipis;
        private System.Windows.Forms.Label lblStokJudul;
        private System.Windows.Forms.Label lblStokNama1;
        private SMKMart.Controls.RoundedLabel lblStokBadge1;
        private SMKMart.Controls.RoundedPanel pnlGarisStok1;
        private System.Windows.Forms.Label lblStokNama2;
        private SMKMart.Controls.RoundedLabel lblStokBadge2;
        private SMKMart.Controls.RoundedPanel pnlGarisStok2;
        private System.Windows.Forms.Label lblStokNama3;
        private SMKMart.Controls.RoundedLabel lblStokBadge3;
        private SMKMart.Controls.RoundedPanel pnlGarisStok3;
        private System.Windows.Forms.Label lblStokNama4;
        private SMKMart.Controls.RoundedLabel lblStokBadge4;
        private SMKMart.Controls.RoundedPanel pnlTransaksi;
        private System.Windows.Forms.Label lblTransaksiJudul;
        private System.Windows.Forms.LinkLabel lnkLihatSemua;
        private SMKMart.Controls.DarkGrid dgvTransaksi;
        private SMKMart.Controls.RoundedPanel pnlStruk;
        private System.Windows.Forms.Label lblStruk;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colJam;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKasir;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTotal;
    }
}
