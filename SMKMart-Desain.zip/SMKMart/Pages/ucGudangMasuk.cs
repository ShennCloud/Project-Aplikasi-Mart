using System.Drawing;
using System.Windows.Forms;

namespace SMKMart.Pages
{
    public partial class ucGudangMasuk : UserControl
    {
        public ucGudangMasuk()
        {
            InitializeComponent();
            IsiContoh();
        }

        // DATA CONTOH supaya tampilan di Designer tidak kosong.
        // Hapus method ini (dan pemanggilannya) kalau sudah mengisi data sendiri.
        private void IsiContoh()
        {
            dgvRiwayat.Rows.Add("03/10/2026", "Beras 5 kg", "50", "Masuk", "Sinta");
            dgvRiwayat.Rows.Add("03/10/2026", "Mi instan", "20", "Keluar", "Sinta");
            dgvRiwayat.Rows.Add("02/10/2026", "Buku tulis", "100", "Masuk", "Sinta");
            dgvRiwayat.ClearSelection();
        }
    }
}
