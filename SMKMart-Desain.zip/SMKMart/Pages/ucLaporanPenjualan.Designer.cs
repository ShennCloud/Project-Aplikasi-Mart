namespace SMKMart.Pages
{
    partial class ucLaporanPenjualan
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblJudul = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.btnCetak = new SMKMart.Controls.RoundedButton();
            this.btnSimpan = new SMKMart.Controls.RoundedButton();
            this.pnlTabs = new SMKMart.Controls.RoundedPanel();
            this.btnTabPenjualan = new SMKMart.Controls.RoundedButton();
            this.btnTabGudang = new SMKMart.Controls.RoundedButton();
            this.lblDari = new System.Windows.Forms.Label();
            this.txtDari = new SMKMart.Controls.RoundedTextBox();
            this.lblSampai = new System.Windows.Forms.Label();
            this.txtSampai = new SMKMart.Controls.RoundedTextBox();
            this.btnTampilkan = new SMKMart.Controls.RoundedButton();
            this.pnlStat1 = new SMKMart.Controls.RoundedPanel();
            this.lblStat1Judul = new System.Windows.Forms.Label();
            this.lblStat1Nilai = new System.Windows.Forms.Label();
            this.pnlStat2 = new SMKMart.Controls.RoundedPanel();
            this.lblStat2Judul = new System.Windows.Forms.Label();
            this.lblStat2Nilai = new System.Windows.Forms.Label();
            this.pnlStat3 = new SMKMart.Controls.RoundedPanel();
            this.lblStat3Judul = new System.Windows.Forms.Label();
            this.lblStat3Nilai = new System.Windows.Forms.Label();
            this.pnlStat4 = new SMKMart.Controls.RoundedPanel();
            this.lblStat4Judul = new System.Windows.Forms.Label();
            this.lblStat4Nilai = new System.Windows.Forms.Label();
            this.pnlGrafik = new SMKMart.Controls.RoundedPanel();
            this.lblGrafikJudul = new System.Windows.Forms.Label();
            this.pnlBar1 = new SMKMart.Controls.RoundedPanel();
            this.lblHari1 = new System.Windows.Forms.Label();
            this.pnlBar2 = new SMKMart.Controls.RoundedPanel();
            this.lblHari2 = new System.Windows.Forms.Label();
            this.pnlBar3 = new SMKMart.Controls.RoundedPanel();
            this.lblHari3 = new System.Windows.Forms.Label();
            this.pnlBar4 = new SMKMart.Controls.RoundedPanel();
            this.lblHari4 = new System.Windows.Forms.Label();
            this.pnlBar5 = new SMKMart.Controls.RoundedPanel();
            this.lblHari5 = new System.Windows.Forms.Label();
            this.pnlTerlaris = new SMKMart.Controls.RoundedPanel();
            this.lblTerlarisJudul = new System.Windows.Forms.Label();
            this.lblTerlaris1 = new System.Windows.Forms.Label();
            this.lblTerjual1 = new System.Windows.Forms.Label();
            this.pnlTerlaris1Track = new SMKMart.Controls.RoundedPanel();
            this.pnlTerlaris1Isi = new SMKMart.Controls.RoundedPanel();
            this.lblTerlaris2 = new System.Windows.Forms.Label();
            this.lblTerjual2 = new System.Windows.Forms.Label();
            this.pnlTerlaris2Track = new SMKMart.Controls.RoundedPanel();
            this.pnlTerlaris2Isi = new SMKMart.Controls.RoundedPanel();
            this.lblTerlaris3 = new System.Windows.Forms.Label();
            this.lblTerjual3 = new System.Windows.Forms.Label();
            this.pnlTerlaris3Track = new SMKMart.Controls.RoundedPanel();
            this.pnlTerlaris3Isi = new SMKMart.Controls.RoundedPanel();
            this.pnlTabel = new SMKMart.Controls.RoundedPanel();
            this.dgvLaporan = new SMKMart.Controls.DarkGrid();
            this.pnlGarisTotal = new SMKMart.Controls.RoundedPanel();
            this.lblTotalCaption = new System.Windows.Forms.Label();
            this.lblTotalNilai = new System.Windows.Forms.Label();
            this.colTanggal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colNoTrx = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colKasir = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLaporan)).BeginInit();
            this.SuspendLayout();
            this.pnlTabs.SuspendLayout();
            this.pnlStat1.SuspendLayout();
            this.pnlStat2.SuspendLayout();
            this.pnlStat3.SuspendLayout();
            this.pnlStat4.SuspendLayout();
            this.pnlGrafik.SuspendLayout();
            this.pnlTerlaris.SuspendLayout();
            this.pnlTerlaris1Track.SuspendLayout();
            this.pnlTerlaris2Track.SuspendLayout();
            this.pnlTerlaris3Track.SuspendLayout();
            this.pnlTabel.SuspendLayout();
            //
            // lblJudul
            //
            this.lblJudul.Location = new System.Drawing.Point(28, 20);
            this.lblJudul.AutoSize = true;
            this.lblJudul.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblJudul.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblJudul.Text = "Laporan";
            this.lblJudul.Name = "lblJudul";
            // lblSub
            //
            this.lblSub.Location = new System.Drawing.Point(30, 62);
            this.lblSub.AutoSize = true;
            this.lblSub.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSub.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSub.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSub.Text = "Laporan penjualan";
            this.lblSub.Name = "lblSub";
            // btnCetak
            //
            this.btnCetak.Location = new System.Drawing.Point(680, 22);
            this.btnCetak.Size = new System.Drawing.Size(116, 46);
            this.btnCetak.BackColor = System.Drawing.Color.FromArgb(42, 58, 114);
            this.btnCetak.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnCetak.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnCetak.Radius = 12;
            this.btnCetak.UseVisualStyleBackColor = false;
            this.btnCetak.Text = "Cetak";
            this.btnCetak.Name = "btnCetak";
            // btnSimpan
            //
            this.btnSimpan.Location = new System.Drawing.Point(806, 22);
            this.btnSimpan.Size = new System.Drawing.Size(136, 46);
            this.btnSimpan.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnSimpan.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnSimpan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSimpan.Radius = 12;
            this.btnSimpan.UseVisualStyleBackColor = false;
            this.btnSimpan.Text = "Simpan .txt";
            this.btnSimpan.Name = "btnSimpan";
            // pnlTabs
            //
            this.pnlTabs.Location = new System.Drawing.Point(28, 92);
            this.pnlTabs.Size = new System.Drawing.Size(402, 52);
            this.pnlTabs.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlTabs.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTabs.Radius = 14;
            this.pnlTabs.Name = "pnlTabs";
            this.pnlTabs.Controls.Add(this.btnTabPenjualan);
            this.pnlTabs.Controls.Add(this.btnTabGudang);
            // btnTabPenjualan
            //
            this.btnTabPenjualan.Location = new System.Drawing.Point(6, 6);
            this.btnTabPenjualan.Size = new System.Drawing.Size(168, 40);
            this.btnTabPenjualan.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnTabPenjualan.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnTabPenjualan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabPenjualan.Radius = 10;
            this.btnTabPenjualan.UseVisualStyleBackColor = false;
            this.btnTabPenjualan.Text = "Laporan penjualan";
            this.btnTabPenjualan.Name = "btnTabPenjualan";
            // btnTabGudang
            //
            this.btnTabGudang.Location = new System.Drawing.Point(180, 6);
            this.btnTabGudang.Size = new System.Drawing.Size(216, 40);
            this.btnTabGudang.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.btnTabGudang.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnTabGudang.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabGudang.Radius = 10;
            this.btnTabGudang.UseVisualStyleBackColor = false;
            this.btnTabGudang.Text = "Stok dan aktivitas gudang";
            this.btnTabGudang.Name = "btnTabGudang";
            // lblDari
            //
            this.lblDari.Location = new System.Drawing.Point(30, 158);
            this.lblDari.AutoSize = true;
            this.lblDari.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblDari.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblDari.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblDari.Text = "Dari tanggal";
            this.lblDari.Name = "lblDari";
            // txtDari
            //
            this.txtDari.Location = new System.Drawing.Point(28, 178);
            this.txtDari.Size = new System.Drawing.Size(230, 46);
            this.txtDari.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.txtDari.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtDari.Text = "01/10/2026";
            this.txtDari.Name = "txtDari";
            // lblSampai
            //
            this.lblSampai.Location = new System.Drawing.Point(272, 158);
            this.lblSampai.AutoSize = true;
            this.lblSampai.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSampai.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSampai.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblSampai.Text = "Sampai tanggal";
            this.lblSampai.Name = "lblSampai";
            // txtSampai
            //
            this.txtSampai.Location = new System.Drawing.Point(270, 178);
            this.txtSampai.Size = new System.Drawing.Size(230, 46);
            this.txtSampai.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.txtSampai.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtSampai.Text = "03/10/2026";
            this.txtSampai.Name = "txtSampai";
            // btnTampilkan
            //
            this.btnTampilkan.Location = new System.Drawing.Point(512, 178);
            this.btnTampilkan.Size = new System.Drawing.Size(150, 46);
            this.btnTampilkan.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.btnTampilkan.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnTampilkan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTampilkan.Radius = 12;
            this.btnTampilkan.UseVisualStyleBackColor = false;
            this.btnTampilkan.Text = "Tampilkan";
            this.btnTampilkan.Name = "btnTampilkan";
            // pnlStat1
            //
            this.pnlStat1.Location = new System.Drawing.Point(28, 240);
            this.pnlStat1.Size = new System.Drawing.Size(219, 82);
            this.pnlStat1.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat1.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlStat1.Radius = 14;
            this.pnlStat1.Name = "pnlStat1";
            this.pnlStat1.Controls.Add(this.lblStat1Judul);
            this.pnlStat1.Controls.Add(this.lblStat1Nilai);
            // lblStat1Judul
            //
            this.lblStat1Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat1Judul.AutoSize = true;
            this.lblStat1Judul.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblStat1Judul.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat1Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat1Judul.Text = "Total penjualan";
            this.lblStat1Judul.Name = "lblStat1Judul";
            // lblStat1Nilai
            //
            this.lblStat1Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat1Nilai.AutoSize = true;
            this.lblStat1Nilai.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblStat1Nilai.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat1Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat1Nilai.Text = "Rp 6.870.000";
            this.lblStat1Nilai.Name = "lblStat1Nilai";
            // pnlStat2
            //
            this.pnlStat2.Location = new System.Drawing.Point(259, 240);
            this.pnlStat2.Size = new System.Drawing.Size(219, 82);
            this.pnlStat2.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat2.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStat2.Radius = 14;
            this.pnlStat2.Name = "pnlStat2";
            this.pnlStat2.Controls.Add(this.lblStat2Judul);
            this.pnlStat2.Controls.Add(this.lblStat2Nilai);
            // lblStat2Judul
            //
            this.lblStat2Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat2Judul.AutoSize = true;
            this.lblStat2Judul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Judul.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStat2Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat2Judul.Text = "Jumlah transaksi";
            this.lblStat2Judul.Name = "lblStat2Judul";
            // lblStat2Nilai
            //
            this.lblStat2Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat2Nilai.AutoSize = true;
            this.lblStat2Nilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Nilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStat2Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat2Nilai.Text = "112";
            this.lblStat2Nilai.Name = "lblStat2Nilai";
            // pnlStat3
            //
            this.pnlStat3.Location = new System.Drawing.Point(490, 240);
            this.pnlStat3.Size = new System.Drawing.Size(219, 82);
            this.pnlStat3.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat3.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStat3.Radius = 14;
            this.pnlStat3.Name = "pnlStat3";
            this.pnlStat3.Controls.Add(this.lblStat3Judul);
            this.pnlStat3.Controls.Add(this.lblStat3Nilai);
            // lblStat3Judul
            //
            this.lblStat3Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat3Judul.AutoSize = true;
            this.lblStat3Judul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat3Judul.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStat3Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat3Judul.Text = "Barang terjual";
            this.lblStat3Judul.Name = "lblStat3Judul";
            // lblStat3Nilai
            //
            this.lblStat3Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat3Nilai.AutoSize = true;
            this.lblStat3Nilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat3Nilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStat3Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat3Nilai.Text = "341";
            this.lblStat3Nilai.Name = "lblStat3Nilai";
            // pnlStat4
            //
            this.pnlStat4.Location = new System.Drawing.Point(721, 240);
            this.pnlStat4.Size = new System.Drawing.Size(219, 82);
            this.pnlStat4.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat4.FillColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlStat4.Radius = 14;
            this.pnlStat4.Name = "pnlStat4";
            this.pnlStat4.Controls.Add(this.lblStat4Judul);
            this.pnlStat4.Controls.Add(this.lblStat4Nilai);
            // lblStat4Judul
            //
            this.lblStat4Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat4Judul.AutoSize = true;
            this.lblStat4Judul.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat4Judul.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat4Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat4Judul.Text = "Rata-rata transaksi";
            this.lblStat4Judul.Name = "lblStat4Judul";
            // lblStat4Nilai
            //
            this.lblStat4Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat4Nilai.AutoSize = true;
            this.lblStat4Nilai.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat4Nilai.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat4Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat4Nilai.Text = "Rp 61.340";
            this.lblStat4Nilai.Name = "lblStat4Nilai";
            // pnlGrafik
            //
            this.pnlGrafik.Location = new System.Drawing.Point(28, 336);
            this.pnlGrafik.Size = new System.Drawing.Size(450, 180);
            this.pnlGrafik.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlGrafik.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGrafik.Radius = 14;
            this.pnlGrafik.Name = "pnlGrafik";
            this.pnlGrafik.Controls.Add(this.lblGrafikJudul);
            this.pnlGrafik.Controls.Add(this.pnlBar1);
            this.pnlGrafik.Controls.Add(this.lblHari1);
            this.pnlGrafik.Controls.Add(this.pnlBar2);
            this.pnlGrafik.Controls.Add(this.lblHari2);
            this.pnlGrafik.Controls.Add(this.pnlBar3);
            this.pnlGrafik.Controls.Add(this.lblHari3);
            this.pnlGrafik.Controls.Add(this.pnlBar4);
            this.pnlGrafik.Controls.Add(this.lblHari4);
            this.pnlGrafik.Controls.Add(this.pnlBar5);
            this.pnlGrafik.Controls.Add(this.lblHari5);
            // lblGrafikJudul
            //
            this.lblGrafikJudul.Location = new System.Drawing.Point(18, 14);
            this.lblGrafikJudul.AutoSize = true;
            this.lblGrafikJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblGrafikJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblGrafikJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblGrafikJudul.Text = "Penjualan per hari";
            this.lblGrafikJudul.Name = "lblGrafikJudul";
            // pnlBar1
            //
            this.pnlBar1.Location = new System.Drawing.Point(34, 88);
            this.pnlBar1.Size = new System.Drawing.Size(50, 52);
            this.pnlBar1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar1.FillColor = System.Drawing.Color.FromArgb(44, 62, 126);
            this.pnlBar1.Radius = 6;
            this.pnlBar1.Name = "pnlBar1";
            // lblHari1
            //
            this.lblHari1.Location = new System.Drawing.Point(18, 148);
            this.lblHari1.Size = new System.Drawing.Size(82, 18);
            this.lblHari1.AutoSize = false;
            this.lblHari1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari1.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHari1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHari1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari1.Text = "29/9";
            this.lblHari1.Name = "lblHari1";
            // pnlBar2
            //
            this.pnlBar2.Location = new System.Drawing.Point(117, 62);
            this.pnlBar2.Size = new System.Drawing.Size(50, 78);
            this.pnlBar2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar2.FillColor = System.Drawing.Color.FromArgb(44, 62, 126);
            this.pnlBar2.Radius = 6;
            this.pnlBar2.Name = "pnlBar2";
            // lblHari2
            //
            this.lblHari2.Location = new System.Drawing.Point(100, 148);
            this.lblHari2.Size = new System.Drawing.Size(82, 18);
            this.lblHari2.AutoSize = false;
            this.lblHari2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari2.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHari2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHari2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari2.Text = "30/9";
            this.lblHari2.Name = "lblHari2";
            // pnlBar3
            //
            this.pnlBar3.Location = new System.Drawing.Point(200, 96);
            this.pnlBar3.Size = new System.Drawing.Size(50, 44);
            this.pnlBar3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar3.FillColor = System.Drawing.Color.FromArgb(44, 62, 126);
            this.pnlBar3.Radius = 6;
            this.pnlBar3.Name = "pnlBar3";
            // lblHari3
            //
            this.lblHari3.Location = new System.Drawing.Point(183, 148);
            this.lblHari3.Size = new System.Drawing.Size(82, 18);
            this.lblHari3.AutoSize = false;
            this.lblHari3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari3.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHari3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHari3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari3.Text = "1/10";
            this.lblHari3.Name = "lblHari3";
            // pnlBar4
            //
            this.pnlBar4.Location = new System.Drawing.Point(282, 48);
            this.pnlBar4.Size = new System.Drawing.Size(50, 92);
            this.pnlBar4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar4.FillColor = System.Drawing.Color.FromArgb(44, 62, 126);
            this.pnlBar4.Radius = 6;
            this.pnlBar4.Name = "pnlBar4";
            // lblHari4
            //
            this.lblHari4.Location = new System.Drawing.Point(266, 148);
            this.lblHari4.Size = new System.Drawing.Size(82, 18);
            this.lblHari4.AutoSize = false;
            this.lblHari4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari4.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHari4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHari4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari4.Text = "2/10";
            this.lblHari4.Name = "lblHari4";
            // pnlBar5
            //
            this.pnlBar5.Location = new System.Drawing.Point(365, 42);
            this.pnlBar5.Size = new System.Drawing.Size(50, 98);
            this.pnlBar5.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlBar5.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlBar5.Radius = 6;
            this.pnlBar5.Name = "pnlBar5";
            // lblHari5
            //
            this.lblHari5.Location = new System.Drawing.Point(349, 148);
            this.lblHari5.Size = new System.Drawing.Size(82, 18);
            this.lblHari5.AutoSize = false;
            this.lblHari5.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHari5.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblHari5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblHari5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblHari5.Text = "3/10";
            this.lblHari5.Name = "lblHari5";
            // pnlTerlaris
            //
            this.pnlTerlaris.Location = new System.Drawing.Point(490, 336);
            this.pnlTerlaris.Size = new System.Drawing.Size(452, 180);
            this.pnlTerlaris.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlTerlaris.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTerlaris.Radius = 14;
            this.pnlTerlaris.Name = "pnlTerlaris";
            this.pnlTerlaris.Controls.Add(this.lblTerlarisJudul);
            this.pnlTerlaris.Controls.Add(this.lblTerlaris1);
            this.pnlTerlaris.Controls.Add(this.lblTerjual1);
            this.pnlTerlaris.Controls.Add(this.pnlTerlaris1Track);
            this.pnlTerlaris.Controls.Add(this.lblTerlaris2);
            this.pnlTerlaris.Controls.Add(this.lblTerjual2);
            this.pnlTerlaris.Controls.Add(this.pnlTerlaris2Track);
            this.pnlTerlaris.Controls.Add(this.lblTerlaris3);
            this.pnlTerlaris.Controls.Add(this.lblTerjual3);
            this.pnlTerlaris.Controls.Add(this.pnlTerlaris3Track);
            // lblTerlarisJudul
            //
            this.lblTerlarisJudul.Location = new System.Drawing.Point(18, 14);
            this.lblTerlarisJudul.AutoSize = true;
            this.lblTerlarisJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTerlarisJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblTerlarisJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTerlarisJudul.Text = "Barang terlaris";
            this.lblTerlarisJudul.Name = "lblTerlarisJudul";
            // lblTerlaris1
            //
            this.lblTerlaris1.Location = new System.Drawing.Point(18, 48);
            this.lblTerlaris1.AutoSize = true;
            this.lblTerlaris1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTerlaris1.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblTerlaris1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTerlaris1.Text = "1. Air mineral";
            this.lblTerlaris1.Name = "lblTerlaris1";
            // lblTerjual1
            //
            this.lblTerjual1.Location = new System.Drawing.Point(250, 48);
            this.lblTerjual1.Size = new System.Drawing.Size(184, 20);
            this.lblTerjual1.AutoSize = false;
            this.lblTerjual1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTerjual1.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblTerjual1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTerjual1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblTerjual1.Text = "96 terjual";
            this.lblTerjual1.Name = "lblTerjual1";
            // pnlTerlaris1Track
            //
            this.pnlTerlaris1Track.Location = new System.Drawing.Point(18, 74);
            this.pnlTerlaris1Track.Size = new System.Drawing.Size(416, 8);
            this.pnlTerlaris1Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTerlaris1Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlTerlaris1Track.Radius = 4;
            this.pnlTerlaris1Track.Name = "pnlTerlaris1Track";
            this.pnlTerlaris1Track.Controls.Add(this.pnlTerlaris1Isi);
            // pnlTerlaris1Isi
            //
            this.pnlTerlaris1Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlTerlaris1Isi.Size = new System.Drawing.Size(416, 8);
            this.pnlTerlaris1Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlTerlaris1Isi.FillColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlTerlaris1Isi.Radius = 4;
            this.pnlTerlaris1Isi.Name = "pnlTerlaris1Isi";
            // lblTerlaris2
            //
            this.lblTerlaris2.Location = new System.Drawing.Point(18, 90);
            this.lblTerlaris2.AutoSize = true;
            this.lblTerlaris2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTerlaris2.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblTerlaris2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTerlaris2.Text = "2. Pulpen hitam";
            this.lblTerlaris2.Name = "lblTerlaris2";
            // lblTerjual2
            //
            this.lblTerjual2.Location = new System.Drawing.Point(250, 90);
            this.lblTerjual2.Size = new System.Drawing.Size(184, 20);
            this.lblTerjual2.AutoSize = false;
            this.lblTerjual2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTerjual2.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblTerjual2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTerjual2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblTerjual2.Text = "74 terjual";
            this.lblTerjual2.Name = "lblTerjual2";
            // pnlTerlaris2Track
            //
            this.pnlTerlaris2Track.Location = new System.Drawing.Point(18, 116);
            this.pnlTerlaris2Track.Size = new System.Drawing.Size(416, 8);
            this.pnlTerlaris2Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTerlaris2Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlTerlaris2Track.Radius = 4;
            this.pnlTerlaris2Track.Name = "pnlTerlaris2Track";
            this.pnlTerlaris2Track.Controls.Add(this.pnlTerlaris2Isi);
            // pnlTerlaris2Isi
            //
            this.pnlTerlaris2Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlTerlaris2Isi.Size = new System.Drawing.Size(320, 8);
            this.pnlTerlaris2Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlTerlaris2Isi.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlTerlaris2Isi.Radius = 4;
            this.pnlTerlaris2Isi.Name = "pnlTerlaris2Isi";
            // lblTerlaris3
            //
            this.lblTerlaris3.Location = new System.Drawing.Point(18, 132);
            this.lblTerlaris3.AutoSize = true;
            this.lblTerlaris3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTerlaris3.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblTerlaris3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTerlaris3.Text = "3. Buku tulis";
            this.lblTerlaris3.Name = "lblTerlaris3";
            // lblTerjual3
            //
            this.lblTerjual3.Location = new System.Drawing.Point(250, 132);
            this.lblTerjual3.Size = new System.Drawing.Size(184, 20);
            this.lblTerjual3.AutoSize = false;
            this.lblTerjual3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTerjual3.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblTerjual3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTerjual3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblTerjual3.Text = "61 terjual";
            this.lblTerjual3.Name = "lblTerjual3";
            // pnlTerlaris3Track
            //
            this.pnlTerlaris3Track.Location = new System.Drawing.Point(18, 158);
            this.pnlTerlaris3Track.Size = new System.Drawing.Size(416, 8);
            this.pnlTerlaris3Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTerlaris3Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlTerlaris3Track.Radius = 4;
            this.pnlTerlaris3Track.Name = "pnlTerlaris3Track";
            this.pnlTerlaris3Track.Controls.Add(this.pnlTerlaris3Isi);
            // pnlTerlaris3Isi
            //
            this.pnlTerlaris3Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlTerlaris3Isi.Size = new System.Drawing.Size(266, 8);
            this.pnlTerlaris3Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlTerlaris3Isi.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlTerlaris3Isi.Radius = 4;
            this.pnlTerlaris3Isi.Name = "pnlTerlaris3Isi";
            // pnlTabel
            //
            this.pnlTabel.Location = new System.Drawing.Point(28, 530);
            this.pnlTabel.Size = new System.Drawing.Size(914, 178);
            this.pnlTabel.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlTabel.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTabel.Radius = 14;
            this.pnlTabel.Name = "pnlTabel";
            this.pnlTabel.Controls.Add(this.dgvLaporan);
            this.pnlTabel.Controls.Add(this.pnlGarisTotal);
            this.pnlTabel.Controls.Add(this.lblTotalCaption);
            this.pnlTabel.Controls.Add(this.lblTotalNilai);
            // dgvLaporan
            //
            this.dgvLaporan.Location = new System.Drawing.Point(12, 8);
            this.dgvLaporan.Size = new System.Drawing.Size(890, 132);
            this.dgvLaporan.BackgroundColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.dgvLaporan.Name = "dgvLaporan";
            this.colTanggal.HeaderText = "Tanggal";
            this.colTanggal.Name = "colTanggal";
            this.colTanggal.FillWeight = 20F;
            this.colTanggal.MinimumWidth = 6;
            this.colNoTrx.HeaderText = "No. transaksi";
            this.colNoTrx.Name = "colNoTrx";
            this.colNoTrx.FillWeight = 24F;
            this.colNoTrx.MinimumWidth = 6;
            this.colKasir.HeaderText = "Kasir";
            this.colKasir.Name = "colKasir";
            this.colKasir.FillWeight = 22F;
            this.colKasir.MinimumWidth = 6;
            this.colItem.HeaderText = "Item";
            this.colItem.Name = "colItem";
            this.colItem.FillWeight = 12F;
            this.colItem.MinimumWidth = 6;
            this.colItem.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colItem.HeaderCell.Style = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colTotal.HeaderText = "Total";
            this.colTotal.Name = "colTotal";
            this.colTotal.FillWeight = 22F;
            this.colTotal.MinimumWidth = 6;
            this.colTotal.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colTotal.HeaderCell.Style = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.dgvLaporan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { this.colTanggal, this.colNoTrx, this.colKasir, this.colItem, this.colTotal });
            // pnlGarisTotal
            //
            this.pnlGarisTotal.Location = new System.Drawing.Point(18, 146);
            this.pnlGarisTotal.Size = new System.Drawing.Size(878, 1);
            this.pnlGarisTotal.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGarisTotal.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGarisTotal.Radius = 0;
            this.pnlGarisTotal.Name = "pnlGarisTotal";
            // lblTotalCaption
            //
            this.lblTotalCaption.Location = new System.Drawing.Point(18, 152);
            this.lblTotalCaption.AutoSize = true;
            this.lblTotalCaption.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTotalCaption.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblTotalCaption.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblTotalCaption.Text = "Total periode";
            this.lblTotalCaption.Name = "lblTotalCaption";
            // lblTotalNilai
            //
            this.lblTotalNilai.Location = new System.Drawing.Point(700, 152);
            this.lblTotalNilai.Size = new System.Drawing.Size(196, 22);
            this.lblTotalNilai.AutoSize = false;
            this.lblTotalNilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTotalNilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblTotalNilai.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblTotalNilai.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblTotalNilai.Text = "Rp 6.870.000";
            this.lblTotalNilai.Name = "lblTotalNilai";
            //
            // ucLaporanPenjualan
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.Size = new System.Drawing.Size(970, 720);
            this.Name = "ucLaporanPenjualan";
            this.Controls.Add(this.lblJudul);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.btnCetak);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.pnlTabs);
            this.Controls.Add(this.lblDari);
            this.Controls.Add(this.txtDari);
            this.Controls.Add(this.lblSampai);
            this.Controls.Add(this.txtSampai);
            this.Controls.Add(this.btnTampilkan);
            this.Controls.Add(this.pnlStat1);
            this.Controls.Add(this.pnlStat2);
            this.Controls.Add(this.pnlStat3);
            this.Controls.Add(this.pnlStat4);
            this.Controls.Add(this.pnlGrafik);
            this.Controls.Add(this.pnlTerlaris);
            this.Controls.Add(this.pnlTabel);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLaporan)).EndInit();
            this.pnlTabs.ResumeLayout(false);
            this.pnlStat1.ResumeLayout(false);
            this.pnlStat2.ResumeLayout(false);
            this.pnlStat3.ResumeLayout(false);
            this.pnlStat4.ResumeLayout(false);
            this.pnlGrafik.ResumeLayout(false);
            this.pnlTerlaris.ResumeLayout(false);
            this.pnlTerlaris1Track.ResumeLayout(false);
            this.pnlTerlaris2Track.ResumeLayout(false);
            this.pnlTerlaris3Track.ResumeLayout(false);
            this.pnlTabel.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label lblJudul;
        private System.Windows.Forms.Label lblSub;
        private SMKMart.Controls.RoundedButton btnCetak;
        private SMKMart.Controls.RoundedButton btnSimpan;
        private SMKMart.Controls.RoundedPanel pnlTabs;
        private SMKMart.Controls.RoundedButton btnTabPenjualan;
        private SMKMart.Controls.RoundedButton btnTabGudang;
        private System.Windows.Forms.Label lblDari;
        private SMKMart.Controls.RoundedTextBox txtDari;
        private System.Windows.Forms.Label lblSampai;
        private SMKMart.Controls.RoundedTextBox txtSampai;
        private SMKMart.Controls.RoundedButton btnTampilkan;
        private SMKMart.Controls.RoundedPanel pnlStat1;
        private System.Windows.Forms.Label lblStat1Judul;
        private System.Windows.Forms.Label lblStat1Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat2;
        private System.Windows.Forms.Label lblStat2Judul;
        private System.Windows.Forms.Label lblStat2Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat3;
        private System.Windows.Forms.Label lblStat3Judul;
        private System.Windows.Forms.Label lblStat3Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat4;
        private System.Windows.Forms.Label lblStat4Judul;
        private System.Windows.Forms.Label lblStat4Nilai;
        private SMKMart.Controls.RoundedPanel pnlGrafik;
        private System.Windows.Forms.Label lblGrafikJudul;
        private SMKMart.Controls.RoundedPanel pnlBar1;
        private System.Windows.Forms.Label lblHari1;
        private SMKMart.Controls.RoundedPanel pnlBar2;
        private System.Windows.Forms.Label lblHari2;
        private SMKMart.Controls.RoundedPanel pnlBar3;
        private System.Windows.Forms.Label lblHari3;
        private SMKMart.Controls.RoundedPanel pnlBar4;
        private System.Windows.Forms.Label lblHari4;
        private SMKMart.Controls.RoundedPanel pnlBar5;
        private System.Windows.Forms.Label lblHari5;
        private SMKMart.Controls.RoundedPanel pnlTerlaris;
        private System.Windows.Forms.Label lblTerlarisJudul;
        private System.Windows.Forms.Label lblTerlaris1;
        private System.Windows.Forms.Label lblTerjual1;
        private SMKMart.Controls.RoundedPanel pnlTerlaris1Track;
        private SMKMart.Controls.RoundedPanel pnlTerlaris1Isi;
        private System.Windows.Forms.Label lblTerlaris2;
        private System.Windows.Forms.Label lblTerjual2;
        private SMKMart.Controls.RoundedPanel pnlTerlaris2Track;
        private SMKMart.Controls.RoundedPanel pnlTerlaris2Isi;
        private System.Windows.Forms.Label lblTerlaris3;
        private System.Windows.Forms.Label lblTerjual3;
        private SMKMart.Controls.RoundedPanel pnlTerlaris3Track;
        private SMKMart.Controls.RoundedPanel pnlTerlaris3Isi;
        private SMKMart.Controls.RoundedPanel pnlTabel;
        private SMKMart.Controls.DarkGrid dgvLaporan;
        private SMKMart.Controls.RoundedPanel pnlGarisTotal;
        private System.Windows.Forms.Label lblTotalCaption;
        private System.Windows.Forms.Label lblTotalNilai;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTanggal;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNoTrx;
        private System.Windows.Forms.DataGridViewTextBoxColumn colKasir;
        private System.Windows.Forms.DataGridViewTextBoxColumn colItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTotal;
    }
}
