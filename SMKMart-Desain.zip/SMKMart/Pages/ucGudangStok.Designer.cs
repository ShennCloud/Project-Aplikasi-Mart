namespace SMKMart.Pages
{
    partial class ucGudangStok
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblJudul = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.pnlTabs = new SMKMart.Controls.RoundedPanel();
            this.btnTabMasuk = new SMKMart.Controls.RoundedButton();
            this.btnTabKeluar = new SMKMart.Controls.RoundedButton();
            this.btnTabStok = new SMKMart.Controls.RoundedButton();
            this.pnlStat1 = new SMKMart.Controls.RoundedPanel();
            this.lblStat1Judul = new System.Windows.Forms.Label();
            this.lblStat1Nilai = new System.Windows.Forms.Label();
            this.pnlStat2 = new SMKMart.Controls.RoundedPanel();
            this.lblStat2Judul = new System.Windows.Forms.Label();
            this.lblStat2Nilai = new System.Windows.Forms.Label();
            this.pnlStat3 = new SMKMart.Controls.RoundedPanel();
            this.lblStat3Judul = new System.Windows.Forms.Label();
            this.lblStat3Nilai = new System.Windows.Forms.Label();
            this.txtCari = new SMKMart.Controls.RoundedTextBox();
            this.pnlCboStatus = new SMKMart.Controls.RoundedPanel();
            this.cboStatus = new System.Windows.Forms.ComboBox();
            this.pnlTabel = new SMKMart.Controls.RoundedPanel();
            this.lblHBarang = new System.Windows.Forms.Label();
            this.lblHStok = new System.Windows.Forms.Label();
            this.lblHMin = new System.Windows.Forms.Label();
            this.lblHLevel = new System.Windows.Forms.Label();
            this.lblHStatus = new System.Windows.Forms.Label();
            this.pnlGarisHeader = new SMKMart.Controls.RoundedPanel();
            this.lblNama1 = new System.Windows.Forms.Label();
            this.lblStok1 = new System.Windows.Forms.Label();
            this.lblMin1 = new System.Windows.Forms.Label();
            this.pnlLevel1Track = new SMKMart.Controls.RoundedPanel();
            this.pnlLevel1Isi = new SMKMart.Controls.RoundedPanel();
            this.lblStatus1 = new SMKMart.Controls.RoundedLabel();
            this.pnlGaris1 = new SMKMart.Controls.RoundedPanel();
            this.lblNama2 = new System.Windows.Forms.Label();
            this.lblStok2 = new System.Windows.Forms.Label();
            this.lblMin2 = new System.Windows.Forms.Label();
            this.pnlLevel2Track = new SMKMart.Controls.RoundedPanel();
            this.pnlLevel2Isi = new SMKMart.Controls.RoundedPanel();
            this.lblStatus2 = new SMKMart.Controls.RoundedLabel();
            this.pnlGaris2 = new SMKMart.Controls.RoundedPanel();
            this.lblNama3 = new System.Windows.Forms.Label();
            this.lblStok3 = new System.Windows.Forms.Label();
            this.lblMin3 = new System.Windows.Forms.Label();
            this.pnlLevel3Track = new SMKMart.Controls.RoundedPanel();
            this.pnlLevel3Isi = new SMKMart.Controls.RoundedPanel();
            this.lblStatus3 = new SMKMart.Controls.RoundedLabel();
            this.pnlGaris3 = new SMKMart.Controls.RoundedPanel();
            this.lblNama4 = new System.Windows.Forms.Label();
            this.lblStok4 = new System.Windows.Forms.Label();
            this.lblMin4 = new System.Windows.Forms.Label();
            this.pnlLevel4Track = new SMKMart.Controls.RoundedPanel();
            this.pnlLevel4Isi = new SMKMart.Controls.RoundedPanel();
            this.lblStatus4 = new SMKMart.Controls.RoundedLabel();
            this.pnlGaris4 = new SMKMart.Controls.RoundedPanel();
            this.lblNama5 = new System.Windows.Forms.Label();
            this.lblStok5 = new System.Windows.Forms.Label();
            this.lblMin5 = new System.Windows.Forms.Label();
            this.pnlLevel5Track = new SMKMart.Controls.RoundedPanel();
            this.pnlLevel5Isi = new SMKMart.Controls.RoundedPanel();
            this.lblStatus5 = new SMKMart.Controls.RoundedLabel();
            this.SuspendLayout();
            this.pnlTabs.SuspendLayout();
            this.pnlStat1.SuspendLayout();
            this.pnlStat2.SuspendLayout();
            this.pnlStat3.SuspendLayout();
            this.pnlCboStatus.SuspendLayout();
            this.pnlTabel.SuspendLayout();
            this.pnlLevel1Track.SuspendLayout();
            this.pnlLevel2Track.SuspendLayout();
            this.pnlLevel3Track.SuspendLayout();
            this.pnlLevel4Track.SuspendLayout();
            this.pnlLevel5Track.SuspendLayout();
            //
            // lblJudul
            //
            this.lblJudul.Location = new System.Drawing.Point(28, 20);
            this.lblJudul.AutoSize = true;
            this.lblJudul.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblJudul.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblJudul.Text = "Gudang";
            this.lblJudul.Name = "lblJudul";
            // lblSub
            //
            this.lblSub.Location = new System.Drawing.Point(30, 62);
            this.lblSub.AutoSize = true;
            this.lblSub.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSub.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSub.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSub.Text = "Catat barang masuk, barang keluar, dan pantau stok";
            this.lblSub.Name = "lblSub";
            // pnlTabs
            //
            this.pnlTabs.Location = new System.Drawing.Point(28, 92);
            this.pnlTabs.Size = new System.Drawing.Size(376, 52);
            this.pnlTabs.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlTabs.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTabs.Radius = 14;
            this.pnlTabs.Name = "pnlTabs";
            this.pnlTabs.Controls.Add(this.btnTabMasuk);
            this.pnlTabs.Controls.Add(this.btnTabKeluar);
            this.pnlTabs.Controls.Add(this.btnTabStok);
            // btnTabMasuk
            //
            this.btnTabMasuk.Location = new System.Drawing.Point(6, 6);
            this.btnTabMasuk.Size = new System.Drawing.Size(120, 40);
            this.btnTabMasuk.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.btnTabMasuk.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnTabMasuk.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabMasuk.Radius = 10;
            this.btnTabMasuk.UseVisualStyleBackColor = false;
            this.btnTabMasuk.Text = "Barang masuk";
            this.btnTabMasuk.Name = "btnTabMasuk";
            // btnTabKeluar
            //
            this.btnTabKeluar.Location = new System.Drawing.Point(132, 6);
            this.btnTabKeluar.Size = new System.Drawing.Size(124, 40);
            this.btnTabKeluar.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.btnTabKeluar.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnTabKeluar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabKeluar.Radius = 10;
            this.btnTabKeluar.UseVisualStyleBackColor = false;
            this.btnTabKeluar.Text = "Barang keluar";
            this.btnTabKeluar.Name = "btnTabKeluar";
            // btnTabStok
            //
            this.btnTabStok.Location = new System.Drawing.Point(262, 6);
            this.btnTabStok.Size = new System.Drawing.Size(108, 40);
            this.btnTabStok.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnTabStok.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnTabStok.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabStok.Radius = 10;
            this.btnTabStok.UseVisualStyleBackColor = false;
            this.btnTabStok.Text = "Stok barang";
            this.btnTabStok.Name = "btnTabStok";
            // pnlStat1
            //
            this.pnlStat1.Location = new System.Drawing.Point(28, 158);
            this.pnlStat1.Size = new System.Drawing.Size(296, 82);
            this.pnlStat1.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat1.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStat1.Radius = 14;
            this.pnlStat1.Name = "pnlStat1";
            this.pnlStat1.Controls.Add(this.lblStat1Judul);
            this.pnlStat1.Controls.Add(this.lblStat1Nilai);
            // lblStat1Judul
            //
            this.lblStat1Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat1Judul.AutoSize = true;
            this.lblStat1Judul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat1Judul.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStat1Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat1Judul.Text = "Jenis barang";
            this.lblStat1Judul.Name = "lblStat1Judul";
            // lblStat1Nilai
            //
            this.lblStat1Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat1Nilai.AutoSize = true;
            this.lblStat1Nilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat1Nilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStat1Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat1Nilai.Text = "48";
            this.lblStat1Nilai.Name = "lblStat1Nilai";
            // pnlStat2
            //
            this.pnlStat2.Location = new System.Drawing.Point(336, 158);
            this.pnlStat2.Size = new System.Drawing.Size(296, 82);
            this.pnlStat2.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat2.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStat2.Radius = 14;
            this.pnlStat2.Name = "pnlStat2";
            this.pnlStat2.Controls.Add(this.lblStat2Judul);
            this.pnlStat2.Controls.Add(this.lblStat2Nilai);
            // lblStat2Judul
            //
            this.lblStat2Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat2Judul.AutoSize = true;
            this.lblStat2Judul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Judul.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStat2Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat2Judul.Text = "Total stok";
            this.lblStat2Judul.Name = "lblStat2Judul";
            // lblStat2Nilai
            //
            this.lblStat2Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat2Nilai.AutoSize = true;
            this.lblStat2Nilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Nilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStat2Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat2Nilai.Text = "1.236";
            this.lblStat2Nilai.Name = "lblStat2Nilai";
            // pnlStat3
            //
            this.pnlStat3.Location = new System.Drawing.Point(644, 158);
            this.pnlStat3.Size = new System.Drawing.Size(296, 82);
            this.pnlStat3.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat3.FillColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlStat3.Radius = 14;
            this.pnlStat3.Name = "pnlStat3";
            this.pnlStat3.Controls.Add(this.lblStat3Judul);
            this.pnlStat3.Controls.Add(this.lblStat3Nilai);
            // lblStat3Judul
            //
            this.lblStat3Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat3Judul.AutoSize = true;
            this.lblStat3Judul.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat3Judul.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat3Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat3Judul.Text = "Perlu restok";
            this.lblStat3Judul.Name = "lblStat3Judul";
            // lblStat3Nilai
            //
            this.lblStat3Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat3Nilai.AutoSize = true;
            this.lblStat3Nilai.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat3Nilai.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat3Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat3Nilai.Text = "4 barang";
            this.lblStat3Nilai.Name = "lblStat3Nilai";
            // txtCari
            //
            this.txtCari.Location = new System.Drawing.Point(28, 254);
            this.txtCari.Size = new System.Drawing.Size(740, 46);
            this.txtCari.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.txtCari.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtCari.PlaceholderText = "Cari barang";
            this.txtCari.Name = "txtCari";
            // pnlCboStatus
            //
            this.pnlCboStatus.Location = new System.Drawing.Point(780, 254);
            this.pnlCboStatus.Size = new System.Drawing.Size(162, 46);
            this.pnlCboStatus.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlCboStatus.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlCboStatus.Radius = 12;
            this.pnlCboStatus.BorderColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlCboStatus.BorderSize = 1;
            this.pnlCboStatus.Name = "pnlCboStatus";
            this.pnlCboStatus.Controls.Add(this.cboStatus);
            // cboStatus
            //
            this.cboStatus.Location = new System.Drawing.Point(12, 8);
            this.cboStatus.Size = new System.Drawing.Size(138, 30);
            this.cboStatus.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.cboStatus.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.cboStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboStatus.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.cboStatus.FormattingEnabled = true;
            this.cboStatus.Name = "cboStatus";
            this.cboStatus.Items.AddRange(new object[] { "Semua status", "Aman", "Menipis" });
            this.cboStatus.SelectedIndex = 0;
            // pnlTabel
            //
            this.pnlTabel.Location = new System.Drawing.Point(28, 314);
            this.pnlTabel.Size = new System.Drawing.Size(914, 394);
            this.pnlTabel.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlTabel.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTabel.Radius = 14;
            this.pnlTabel.Name = "pnlTabel";
            this.pnlTabel.Controls.Add(this.lblHBarang);
            this.pnlTabel.Controls.Add(this.lblHStok);
            this.pnlTabel.Controls.Add(this.lblHMin);
            this.pnlTabel.Controls.Add(this.lblHLevel);
            this.pnlTabel.Controls.Add(this.lblHStatus);
            this.pnlTabel.Controls.Add(this.pnlGarisHeader);
            this.pnlTabel.Controls.Add(this.lblNama1);
            this.pnlTabel.Controls.Add(this.lblStok1);
            this.pnlTabel.Controls.Add(this.lblMin1);
            this.pnlTabel.Controls.Add(this.pnlLevel1Track);
            this.pnlTabel.Controls.Add(this.lblStatus1);
            this.pnlTabel.Controls.Add(this.pnlGaris1);
            this.pnlTabel.Controls.Add(this.lblNama2);
            this.pnlTabel.Controls.Add(this.lblStok2);
            this.pnlTabel.Controls.Add(this.lblMin2);
            this.pnlTabel.Controls.Add(this.pnlLevel2Track);
            this.pnlTabel.Controls.Add(this.lblStatus2);
            this.pnlTabel.Controls.Add(this.pnlGaris2);
            this.pnlTabel.Controls.Add(this.lblNama3);
            this.pnlTabel.Controls.Add(this.lblStok3);
            this.pnlTabel.Controls.Add(this.lblMin3);
            this.pnlTabel.Controls.Add(this.pnlLevel3Track);
            this.pnlTabel.Controls.Add(this.lblStatus3);
            this.pnlTabel.Controls.Add(this.pnlGaris3);
            this.pnlTabel.Controls.Add(this.lblNama4);
            this.pnlTabel.Controls.Add(this.lblStok4);
            this.pnlTabel.Controls.Add(this.lblMin4);
            this.pnlTabel.Controls.Add(this.pnlLevel4Track);
            this.pnlTabel.Controls.Add(this.lblStatus4);
            this.pnlTabel.Controls.Add(this.pnlGaris4);
            this.pnlTabel.Controls.Add(this.lblNama5);
            this.pnlTabel.Controls.Add(this.lblStok5);
            this.pnlTabel.Controls.Add(this.lblMin5);
            this.pnlTabel.Controls.Add(this.pnlLevel5Track);
            this.pnlTabel.Controls.Add(this.lblStatus5);
            // lblHBarang
            //
            this.lblHBarang.Location = new System.Drawing.Point(22, 18);
            this.lblHBarang.AutoSize = true;
            this.lblHBarang.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHBarang.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHBarang.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHBarang.Text = "Barang";
            this.lblHBarang.Name = "lblHBarang";
            // lblHStok
            //
            this.lblHStok.Location = new System.Drawing.Point(240, 18);
            this.lblHStok.Size = new System.Drawing.Size(80, 18);
            this.lblHStok.AutoSize = false;
            this.lblHStok.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHStok.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHStok.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHStok.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblHStok.Text = "Stok";
            this.lblHStok.Name = "lblHStok";
            // lblHMin
            //
            this.lblHMin.Location = new System.Drawing.Point(330, 18);
            this.lblHMin.Size = new System.Drawing.Size(70, 18);
            this.lblHMin.AutoSize = false;
            this.lblHMin.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHMin.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHMin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHMin.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblHMin.Text = "Min";
            this.lblHMin.Name = "lblHMin";
            // lblHLevel
            //
            this.lblHLevel.Location = new System.Drawing.Point(440, 18);
            this.lblHLevel.AutoSize = true;
            this.lblHLevel.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHLevel.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHLevel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHLevel.Text = "Level stok";
            this.lblHLevel.Name = "lblHLevel";
            // lblHStatus
            //
            this.lblHStatus.Location = new System.Drawing.Point(780, 18);
            this.lblHStatus.AutoSize = true;
            this.lblHStatus.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblHStatus.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblHStatus.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHStatus.Text = "Status";
            this.lblHStatus.Name = "lblHStatus";
            // pnlGarisHeader
            //
            this.pnlGarisHeader.Location = new System.Drawing.Point(18, 46);
            this.pnlGarisHeader.Size = new System.Drawing.Size(878, 1);
            this.pnlGarisHeader.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGarisHeader.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGarisHeader.Radius = 0;
            this.pnlGarisHeader.Name = "pnlGarisHeader";
            // lblNama1
            //
            this.lblNama1.Location = new System.Drawing.Point(22, 60);
            this.lblNama1.AutoSize = true;
            this.lblNama1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblNama1.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblNama1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblNama1.Text = "Buku tulis";
            this.lblNama1.Name = "lblNama1";
            // lblStok1
            //
            this.lblStok1.Location = new System.Drawing.Point(240, 60);
            this.lblStok1.Size = new System.Drawing.Size(80, 22);
            this.lblStok1.AutoSize = false;
            this.lblStok1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStok1.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStok1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblStok1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblStok1.Text = "42";
            this.lblStok1.Name = "lblStok1";
            // lblMin1
            //
            this.lblMin1.Location = new System.Drawing.Point(330, 60);
            this.lblMin1.Size = new System.Drawing.Size(70, 22);
            this.lblMin1.AutoSize = false;
            this.lblMin1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblMin1.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblMin1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblMin1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblMin1.Text = "10";
            this.lblMin1.Name = "lblMin1";
            // pnlLevel1Track
            //
            this.pnlLevel1Track.Location = new System.Drawing.Point(440, 68);
            this.pnlLevel1Track.Size = new System.Drawing.Size(300, 8);
            this.pnlLevel1Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlLevel1Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlLevel1Track.Radius = 4;
            this.pnlLevel1Track.Name = "pnlLevel1Track";
            this.pnlLevel1Track.Controls.Add(this.pnlLevel1Isi);
            // pnlLevel1Isi
            //
            this.pnlLevel1Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlLevel1Isi.Size = new System.Drawing.Size(245, 8);
            this.pnlLevel1Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlLevel1Isi.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlLevel1Isi.Radius = 4;
            this.pnlLevel1Isi.Name = "pnlLevel1Isi";
            // lblStatus1
            //
            this.lblStatus1.Location = new System.Drawing.Point(780, 58);
            this.lblStatus1.Size = new System.Drawing.Size(100, 26);
            this.lblStatus1.BackColor = System.Drawing.Color.FromArgb(44, 67, 150);
            this.lblStatus1.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStatus1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblStatus1.Radius = 8;
            this.lblStatus1.Text = "Aman";
            this.lblStatus1.Name = "lblStatus1";
            // pnlGaris1
            //
            this.pnlGaris1.Location = new System.Drawing.Point(18, 100);
            this.pnlGaris1.Size = new System.Drawing.Size(878, 1);
            this.pnlGaris1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGaris1.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGaris1.Radius = 0;
            this.pnlGaris1.Name = "pnlGaris1";
            // lblNama2
            //
            this.lblNama2.Location = new System.Drawing.Point(22, 120);
            this.lblNama2.AutoSize = true;
            this.lblNama2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblNama2.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblNama2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblNama2.Text = "Pulpen hitam";
            this.lblNama2.Name = "lblNama2";
            // lblStok2
            //
            this.lblStok2.Location = new System.Drawing.Point(240, 120);
            this.lblStok2.Size = new System.Drawing.Size(80, 22);
            this.lblStok2.AutoSize = false;
            this.lblStok2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStok2.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStok2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblStok2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblStok2.Text = "60";
            this.lblStok2.Name = "lblStok2";
            // lblMin2
            //
            this.lblMin2.Location = new System.Drawing.Point(330, 120);
            this.lblMin2.Size = new System.Drawing.Size(70, 22);
            this.lblMin2.AutoSize = false;
            this.lblMin2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblMin2.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblMin2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblMin2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblMin2.Text = "15";
            this.lblMin2.Name = "lblMin2";
            // pnlLevel2Track
            //
            this.pnlLevel2Track.Location = new System.Drawing.Point(440, 128);
            this.pnlLevel2Track.Size = new System.Drawing.Size(300, 8);
            this.pnlLevel2Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlLevel2Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlLevel2Track.Radius = 4;
            this.pnlLevel2Track.Name = "pnlLevel2Track";
            this.pnlLevel2Track.Controls.Add(this.pnlLevel2Isi);
            // pnlLevel2Isi
            //
            this.pnlLevel2Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlLevel2Isi.Size = new System.Drawing.Size(300, 8);
            this.pnlLevel2Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlLevel2Isi.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlLevel2Isi.Radius = 4;
            this.pnlLevel2Isi.Name = "pnlLevel2Isi";
            // lblStatus2
            //
            this.lblStatus2.Location = new System.Drawing.Point(780, 118);
            this.lblStatus2.Size = new System.Drawing.Size(100, 26);
            this.lblStatus2.BackColor = System.Drawing.Color.FromArgb(44, 67, 150);
            this.lblStatus2.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStatus2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblStatus2.Radius = 8;
            this.lblStatus2.Text = "Aman";
            this.lblStatus2.Name = "lblStatus2";
            // pnlGaris2
            //
            this.pnlGaris2.Location = new System.Drawing.Point(18, 160);
            this.pnlGaris2.Size = new System.Drawing.Size(878, 1);
            this.pnlGaris2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGaris2.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGaris2.Radius = 0;
            this.pnlGaris2.Name = "pnlGaris2";
            // lblNama3
            //
            this.lblNama3.Location = new System.Drawing.Point(22, 180);
            this.lblNama3.AutoSize = true;
            this.lblNama3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblNama3.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblNama3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblNama3.Text = "Mi instan";
            this.lblNama3.Name = "lblNama3";
            // lblStok3
            //
            this.lblStok3.Location = new System.Drawing.Point(240, 180);
            this.lblStok3.Size = new System.Drawing.Size(80, 22);
            this.lblStok3.AutoSize = false;
            this.lblStok3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStok3.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStok3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblStok3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblStok3.Text = "9";
            this.lblStok3.Name = "lblStok3";
            // lblMin3
            //
            this.lblMin3.Location = new System.Drawing.Point(330, 180);
            this.lblMin3.Size = new System.Drawing.Size(70, 22);
            this.lblMin3.AutoSize = false;
            this.lblMin3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblMin3.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblMin3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblMin3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblMin3.Text = "15";
            this.lblMin3.Name = "lblMin3";
            // pnlLevel3Track
            //
            this.pnlLevel3Track.Location = new System.Drawing.Point(440, 188);
            this.pnlLevel3Track.Size = new System.Drawing.Size(300, 8);
            this.pnlLevel3Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlLevel3Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlLevel3Track.Radius = 4;
            this.pnlLevel3Track.Name = "pnlLevel3Track";
            this.pnlLevel3Track.Controls.Add(this.pnlLevel3Isi);
            // pnlLevel3Isi
            //
            this.pnlLevel3Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlLevel3Isi.Size = new System.Drawing.Size(90, 8);
            this.pnlLevel3Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlLevel3Isi.FillColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlLevel3Isi.Radius = 4;
            this.pnlLevel3Isi.Name = "pnlLevel3Isi";
            // lblStatus3
            //
            this.lblStatus3.Location = new System.Drawing.Point(780, 178);
            this.lblStatus3.Size = new System.Drawing.Size(100, 26);
            this.lblStatus3.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStatus3.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStatus3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblStatus3.Radius = 8;
            this.lblStatus3.Text = "Menipis";
            this.lblStatus3.Name = "lblStatus3";
            // pnlGaris3
            //
            this.pnlGaris3.Location = new System.Drawing.Point(18, 220);
            this.pnlGaris3.Size = new System.Drawing.Size(878, 1);
            this.pnlGaris3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGaris3.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGaris3.Radius = 0;
            this.pnlGaris3.Name = "pnlGaris3";
            // lblNama4
            //
            this.lblNama4.Location = new System.Drawing.Point(22, 240);
            this.lblNama4.AutoSize = true;
            this.lblNama4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblNama4.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblNama4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblNama4.Text = "Beras 5 kg";
            this.lblNama4.Name = "lblNama4";
            // lblStok4
            //
            this.lblStok4.Location = new System.Drawing.Point(240, 240);
            this.lblStok4.Size = new System.Drawing.Size(80, 22);
            this.lblStok4.AutoSize = false;
            this.lblStok4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStok4.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStok4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblStok4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblStok4.Text = "3";
            this.lblStok4.Name = "lblStok4";
            // lblMin4
            //
            this.lblMin4.Location = new System.Drawing.Point(330, 240);
            this.lblMin4.Size = new System.Drawing.Size(70, 22);
            this.lblMin4.AutoSize = false;
            this.lblMin4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblMin4.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblMin4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblMin4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblMin4.Text = "10";
            this.lblMin4.Name = "lblMin4";
            // pnlLevel4Track
            //
            this.pnlLevel4Track.Location = new System.Drawing.Point(440, 248);
            this.pnlLevel4Track.Size = new System.Drawing.Size(300, 8);
            this.pnlLevel4Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlLevel4Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlLevel4Track.Radius = 4;
            this.pnlLevel4Track.Name = "pnlLevel4Track";
            this.pnlLevel4Track.Controls.Add(this.pnlLevel4Isi);
            // pnlLevel4Isi
            //
            this.pnlLevel4Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlLevel4Isi.Size = new System.Drawing.Size(36, 8);
            this.pnlLevel4Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlLevel4Isi.FillColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlLevel4Isi.Radius = 4;
            this.pnlLevel4Isi.Name = "pnlLevel4Isi";
            // lblStatus4
            //
            this.lblStatus4.Location = new System.Drawing.Point(780, 238);
            this.lblStatus4.Size = new System.Drawing.Size(100, 26);
            this.lblStatus4.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStatus4.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStatus4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblStatus4.Radius = 8;
            this.lblStatus4.Text = "Menipis";
            this.lblStatus4.Name = "lblStatus4";
            // pnlGaris4
            //
            this.pnlGaris4.Location = new System.Drawing.Point(18, 280);
            this.pnlGaris4.Size = new System.Drawing.Size(878, 1);
            this.pnlGaris4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGaris4.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGaris4.Radius = 0;
            this.pnlGaris4.Name = "pnlGaris4";
            // lblNama5
            //
            this.lblNama5.Location = new System.Drawing.Point(22, 300);
            this.lblNama5.AutoSize = true;
            this.lblNama5.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblNama5.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblNama5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblNama5.Text = "Air mineral";
            this.lblNama5.Name = "lblNama5";
            // lblStok5
            //
            this.lblStok5.Location = new System.Drawing.Point(240, 300);
            this.lblStok5.Size = new System.Drawing.Size(80, 22);
            this.lblStok5.AutoSize = false;
            this.lblStok5.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStok5.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStok5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblStok5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblStok5.Text = "75";
            this.lblStok5.Name = "lblStok5";
            // lblMin5
            //
            this.lblMin5.Location = new System.Drawing.Point(330, 300);
            this.lblMin5.Size = new System.Drawing.Size(70, 22);
            this.lblMin5.AutoSize = false;
            this.lblMin5.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblMin5.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblMin5.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblMin5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblMin5.Text = "20";
            this.lblMin5.Name = "lblMin5";
            // pnlLevel5Track
            //
            this.pnlLevel5Track.Location = new System.Drawing.Point(440, 308);
            this.pnlLevel5Track.Size = new System.Drawing.Size(300, 8);
            this.pnlLevel5Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlLevel5Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlLevel5Track.Radius = 4;
            this.pnlLevel5Track.Name = "pnlLevel5Track";
            this.pnlLevel5Track.Controls.Add(this.pnlLevel5Isi);
            // pnlLevel5Isi
            //
            this.pnlLevel5Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlLevel5Isi.Size = new System.Drawing.Size(300, 8);
            this.pnlLevel5Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlLevel5Isi.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlLevel5Isi.Radius = 4;
            this.pnlLevel5Isi.Name = "pnlLevel5Isi";
            // lblStatus5
            //
            this.lblStatus5.Location = new System.Drawing.Point(780, 298);
            this.lblStatus5.Size = new System.Drawing.Size(100, 26);
            this.lblStatus5.BackColor = System.Drawing.Color.FromArgb(44, 67, 150);
            this.lblStatus5.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStatus5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblStatus5.Radius = 8;
            this.lblStatus5.Text = "Aman";
            this.lblStatus5.Name = "lblStatus5";
            //
            // ucGudangStok
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.Size = new System.Drawing.Size(970, 720);
            this.Name = "ucGudangStok";
            this.Controls.Add(this.lblJudul);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.pnlTabs);
            this.Controls.Add(this.pnlStat1);
            this.Controls.Add(this.pnlStat2);
            this.Controls.Add(this.pnlStat3);
            this.Controls.Add(this.txtCari);
            this.Controls.Add(this.pnlCboStatus);
            this.Controls.Add(this.pnlTabel);
            this.pnlTabs.ResumeLayout(false);
            this.pnlStat1.ResumeLayout(false);
            this.pnlStat2.ResumeLayout(false);
            this.pnlStat3.ResumeLayout(false);
            this.pnlCboStatus.ResumeLayout(false);
            this.pnlTabel.ResumeLayout(false);
            this.pnlLevel1Track.ResumeLayout(false);
            this.pnlLevel2Track.ResumeLayout(false);
            this.pnlLevel3Track.ResumeLayout(false);
            this.pnlLevel4Track.ResumeLayout(false);
            this.pnlLevel5Track.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label lblJudul;
        private System.Windows.Forms.Label lblSub;
        private SMKMart.Controls.RoundedPanel pnlTabs;
        private SMKMart.Controls.RoundedButton btnTabMasuk;
        private SMKMart.Controls.RoundedButton btnTabKeluar;
        private SMKMart.Controls.RoundedButton btnTabStok;
        private SMKMart.Controls.RoundedPanel pnlStat1;
        private System.Windows.Forms.Label lblStat1Judul;
        private System.Windows.Forms.Label lblStat1Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat2;
        private System.Windows.Forms.Label lblStat2Judul;
        private System.Windows.Forms.Label lblStat2Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat3;
        private System.Windows.Forms.Label lblStat3Judul;
        private System.Windows.Forms.Label lblStat3Nilai;
        private SMKMart.Controls.RoundedTextBox txtCari;
        private SMKMart.Controls.RoundedPanel pnlCboStatus;
        private System.Windows.Forms.ComboBox cboStatus;
        private SMKMart.Controls.RoundedPanel pnlTabel;
        private System.Windows.Forms.Label lblHBarang;
        private System.Windows.Forms.Label lblHStok;
        private System.Windows.Forms.Label lblHMin;
        private System.Windows.Forms.Label lblHLevel;
        private System.Windows.Forms.Label lblHStatus;
        private SMKMart.Controls.RoundedPanel pnlGarisHeader;
        private System.Windows.Forms.Label lblNama1;
        private System.Windows.Forms.Label lblStok1;
        private System.Windows.Forms.Label lblMin1;
        private SMKMart.Controls.RoundedPanel pnlLevel1Track;
        private SMKMart.Controls.RoundedPanel pnlLevel1Isi;
        private SMKMart.Controls.RoundedLabel lblStatus1;
        private SMKMart.Controls.RoundedPanel pnlGaris1;
        private System.Windows.Forms.Label lblNama2;
        private System.Windows.Forms.Label lblStok2;
        private System.Windows.Forms.Label lblMin2;
        private SMKMart.Controls.RoundedPanel pnlLevel2Track;
        private SMKMart.Controls.RoundedPanel pnlLevel2Isi;
        private SMKMart.Controls.RoundedLabel lblStatus2;
        private SMKMart.Controls.RoundedPanel pnlGaris2;
        private System.Windows.Forms.Label lblNama3;
        private System.Windows.Forms.Label lblStok3;
        private System.Windows.Forms.Label lblMin3;
        private SMKMart.Controls.RoundedPanel pnlLevel3Track;
        private SMKMart.Controls.RoundedPanel pnlLevel3Isi;
        private SMKMart.Controls.RoundedLabel lblStatus3;
        private SMKMart.Controls.RoundedPanel pnlGaris3;
        private System.Windows.Forms.Label lblNama4;
        private System.Windows.Forms.Label lblStok4;
        private System.Windows.Forms.Label lblMin4;
        private SMKMart.Controls.RoundedPanel pnlLevel4Track;
        private SMKMart.Controls.RoundedPanel pnlLevel4Isi;
        private SMKMart.Controls.RoundedLabel lblStatus4;
        private SMKMart.Controls.RoundedPanel pnlGaris4;
        private System.Windows.Forms.Label lblNama5;
        private System.Windows.Forms.Label lblStok5;
        private System.Windows.Forms.Label lblMin5;
        private SMKMart.Controls.RoundedPanel pnlLevel5Track;
        private SMKMart.Controls.RoundedPanel pnlLevel5Isi;
        private SMKMart.Controls.RoundedLabel lblStatus5;
    }
}
