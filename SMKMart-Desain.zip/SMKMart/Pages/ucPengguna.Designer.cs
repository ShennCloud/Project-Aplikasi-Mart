namespace SMKMart.Pages
{
    partial class ucPengguna
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblJudul = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.btnTambah = new SMKMart.Controls.RoundedButton();
            this.pnlStat1 = new SMKMart.Controls.RoundedPanel();
            this.lblStat1Judul = new System.Windows.Forms.Label();
            this.lblStat1Nilai = new System.Windows.Forms.Label();
            this.pnlStat2 = new SMKMart.Controls.RoundedPanel();
            this.lblStat2Judul = new System.Windows.Forms.Label();
            this.lblStat2Nilai = new System.Windows.Forms.Label();
            this.pnlStat3 = new SMKMart.Controls.RoundedPanel();
            this.lblStat3Judul = new System.Windows.Forms.Label();
            this.lblStat3Nilai = new System.Windows.Forms.Label();
            this.pnlStat4 = new SMKMart.Controls.RoundedPanel();
            this.lblStat4Judul = new System.Windows.Forms.Label();
            this.lblStat4Nilai = new System.Windows.Forms.Label();
            this.pnlDaftar = new SMKMart.Controls.RoundedPanel();
            this.lblAvatar1 = new SMKMart.Controls.RoundedLabel();
            this.lblNama1 = new System.Windows.Forms.Label();
            this.lblUser1 = new System.Windows.Forms.Label();
            this.lblPeran1 = new SMKMart.Controls.RoundedLabel();
            this.pnlGaris1 = new SMKMart.Controls.RoundedPanel();
            this.lblAvatar2 = new SMKMart.Controls.RoundedLabel();
            this.lblNama2 = new System.Windows.Forms.Label();
            this.lblUser2 = new System.Windows.Forms.Label();
            this.lblPeran2 = new SMKMart.Controls.RoundedLabel();
            this.pnlGaris2 = new SMKMart.Controls.RoundedPanel();
            this.lblAvatar3 = new SMKMart.Controls.RoundedLabel();
            this.lblNama3 = new System.Windows.Forms.Label();
            this.lblUser3 = new System.Windows.Forms.Label();
            this.lblPeran3 = new SMKMart.Controls.RoundedLabel();
            this.pnlGaris3 = new SMKMart.Controls.RoundedPanel();
            this.lblAvatar4 = new SMKMart.Controls.RoundedLabel();
            this.lblNama4 = new System.Windows.Forms.Label();
            this.lblUser4 = new System.Windows.Forms.Label();
            this.lblPeran4 = new SMKMart.Controls.RoundedLabel();
            this.btnToggle = new SMKMart.Controls.RoundedButton();
            this.btnHapus = new SMKMart.Controls.RoundedButton();
            this.pnlForm = new SMKMart.Controls.RoundedPanel();
            this.lblFormJudul = new System.Windows.Forms.Label();
            this.lblNamaLengkap = new System.Windows.Forms.Label();
            this.txtNama = new SMKMart.Controls.RoundedTextBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.txtUsername = new SMKMart.Controls.RoundedTextBox();
            this.lblSandi = new System.Windows.Forms.Label();
            this.txtSandi = new SMKMart.Controls.RoundedTextBox();
            this.lblPeran = new System.Windows.Forms.Label();
            this.pnlCboPeran = new SMKMart.Controls.RoundedPanel();
            this.cboPeran = new System.Windows.Forms.ComboBox();
            this.btnBatal = new SMKMart.Controls.RoundedButton();
            this.btnSimpan = new SMKMart.Controls.RoundedButton();
            this.SuspendLayout();
            this.pnlStat1.SuspendLayout();
            this.pnlStat2.SuspendLayout();
            this.pnlStat3.SuspendLayout();
            this.pnlStat4.SuspendLayout();
            this.pnlDaftar.SuspendLayout();
            this.pnlForm.SuspendLayout();
            this.pnlCboPeran.SuspendLayout();
            //
            // lblJudul
            //
            this.lblJudul.Location = new System.Drawing.Point(28, 20);
            this.lblJudul.AutoSize = true;
            this.lblJudul.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblJudul.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblJudul.Text = "Pengguna";
            this.lblJudul.Name = "lblJudul";
            // lblSub
            //
            this.lblSub.Location = new System.Drawing.Point(30, 62);
            this.lblSub.AutoSize = true;
            this.lblSub.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSub.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSub.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSub.Text = "Kelola admin, kasir, dan petugas gudang";
            this.lblSub.Name = "lblSub";
            // btnTambah
            //
            this.btnTambah.Location = new System.Drawing.Point(760, 22);
            this.btnTambah.Size = new System.Drawing.Size(182, 48);
            this.btnTambah.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnTambah.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnTambah.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTambah.Radius = 14;
            this.btnTambah.UseVisualStyleBackColor = false;
            this.btnTambah.Text = "+  Tambah pengguna";
            this.btnTambah.Name = "btnTambah";
            // pnlStat1
            //
            this.pnlStat1.Location = new System.Drawing.Point(28, 92);
            this.pnlStat1.Size = new System.Drawing.Size(219, 82);
            this.pnlStat1.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat1.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlStat1.Radius = 14;
            this.pnlStat1.Name = "pnlStat1";
            this.pnlStat1.Controls.Add(this.lblStat1Judul);
            this.pnlStat1.Controls.Add(this.lblStat1Nilai);
            // lblStat1Judul
            //
            this.lblStat1Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat1Judul.AutoSize = true;
            this.lblStat1Judul.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblStat1Judul.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat1Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat1Judul.Text = "Total pengguna";
            this.lblStat1Judul.Name = "lblStat1Judul";
            // lblStat1Nilai
            //
            this.lblStat1Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat1Nilai.AutoSize = true;
            this.lblStat1Nilai.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblStat1Nilai.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat1Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat1Nilai.Text = "4";
            this.lblStat1Nilai.Name = "lblStat1Nilai";
            // pnlStat2
            //
            this.pnlStat2.Location = new System.Drawing.Point(259, 92);
            this.pnlStat2.Size = new System.Drawing.Size(219, 82);
            this.pnlStat2.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat2.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStat2.Radius = 14;
            this.pnlStat2.Name = "pnlStat2";
            this.pnlStat2.Controls.Add(this.lblStat2Judul);
            this.pnlStat2.Controls.Add(this.lblStat2Nilai);
            // lblStat2Judul
            //
            this.lblStat2Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat2Judul.AutoSize = true;
            this.lblStat2Judul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Judul.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStat2Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat2Judul.Text = "Admin";
            this.lblStat2Judul.Name = "lblStat2Judul";
            // lblStat2Nilai
            //
            this.lblStat2Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat2Nilai.AutoSize = true;
            this.lblStat2Nilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Nilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStat2Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat2Nilai.Text = "1";
            this.lblStat2Nilai.Name = "lblStat2Nilai";
            // pnlStat3
            //
            this.pnlStat3.Location = new System.Drawing.Point(490, 92);
            this.pnlStat3.Size = new System.Drawing.Size(219, 82);
            this.pnlStat3.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat3.FillColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlStat3.Radius = 14;
            this.pnlStat3.Name = "pnlStat3";
            this.pnlStat3.Controls.Add(this.lblStat3Judul);
            this.pnlStat3.Controls.Add(this.lblStat3Nilai);
            // lblStat3Judul
            //
            this.lblStat3Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat3Judul.AutoSize = true;
            this.lblStat3Judul.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat3Judul.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat3Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat3Judul.Text = "Kasir";
            this.lblStat3Judul.Name = "lblStat3Judul";
            // lblStat3Nilai
            //
            this.lblStat3Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat3Nilai.AutoSize = true;
            this.lblStat3Nilai.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat3Nilai.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat3Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat3Nilai.Text = "2";
            this.lblStat3Nilai.Name = "lblStat3Nilai";
            // pnlStat4
            //
            this.pnlStat4.Location = new System.Drawing.Point(721, 92);
            this.pnlStat4.Size = new System.Drawing.Size(219, 82);
            this.pnlStat4.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat4.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStat4.Radius = 14;
            this.pnlStat4.Name = "pnlStat4";
            this.pnlStat4.Controls.Add(this.lblStat4Judul);
            this.pnlStat4.Controls.Add(this.lblStat4Nilai);
            // lblStat4Judul
            //
            this.lblStat4Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat4Judul.AutoSize = true;
            this.lblStat4Judul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat4Judul.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStat4Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat4Judul.Text = "Gudang";
            this.lblStat4Judul.Name = "lblStat4Judul";
            // lblStat4Nilai
            //
            this.lblStat4Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat4Nilai.AutoSize = true;
            this.lblStat4Nilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat4Nilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStat4Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat4Nilai.Text = "1";
            this.lblStat4Nilai.Name = "lblStat4Nilai";
            // pnlDaftar
            //
            this.pnlDaftar.Location = new System.Drawing.Point(28, 190);
            this.pnlDaftar.Size = new System.Drawing.Size(448, 372);
            this.pnlDaftar.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlDaftar.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlDaftar.Radius = 14;
            this.pnlDaftar.Name = "pnlDaftar";
            this.pnlDaftar.Controls.Add(this.lblAvatar1);
            this.pnlDaftar.Controls.Add(this.lblNama1);
            this.pnlDaftar.Controls.Add(this.lblUser1);
            this.pnlDaftar.Controls.Add(this.lblPeran1);
            this.pnlDaftar.Controls.Add(this.pnlGaris1);
            this.pnlDaftar.Controls.Add(this.lblAvatar2);
            this.pnlDaftar.Controls.Add(this.lblNama2);
            this.pnlDaftar.Controls.Add(this.lblUser2);
            this.pnlDaftar.Controls.Add(this.lblPeran2);
            this.pnlDaftar.Controls.Add(this.pnlGaris2);
            this.pnlDaftar.Controls.Add(this.lblAvatar3);
            this.pnlDaftar.Controls.Add(this.lblNama3);
            this.pnlDaftar.Controls.Add(this.lblUser3);
            this.pnlDaftar.Controls.Add(this.lblPeran3);
            this.pnlDaftar.Controls.Add(this.pnlGaris3);
            this.pnlDaftar.Controls.Add(this.lblAvatar4);
            this.pnlDaftar.Controls.Add(this.lblNama4);
            this.pnlDaftar.Controls.Add(this.lblUser4);
            this.pnlDaftar.Controls.Add(this.lblPeran4);
            this.pnlDaftar.Controls.Add(this.btnToggle);
            this.pnlDaftar.Controls.Add(this.btnHapus);
            // lblAvatar1
            //
            this.lblAvatar1.Location = new System.Drawing.Point(18, 16);
            this.lblAvatar1.Size = new System.Drawing.Size(44, 44);
            this.lblAvatar1.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblAvatar1.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblAvatar1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblAvatar1.Radius = 22;
            this.lblAvatar1.Text = "G";
            this.lblAvatar1.Name = "lblAvatar1";
            // lblNama1
            //
            this.lblNama1.Location = new System.Drawing.Point(76, 18);
            this.lblNama1.AutoSize = true;
            this.lblNama1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblNama1.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblNama1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblNama1.Text = "Ganendra";
            this.lblNama1.Name = "lblNama1";
            // lblUser1
            //
            this.lblUser1.Location = new System.Drawing.Point(76, 42);
            this.lblUser1.AutoSize = true;
            this.lblUser1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblUser1.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblUser1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblUser1.Text = "admin01";
            this.lblUser1.Name = "lblUser1";
            // lblPeran1
            //
            this.lblPeran1.Location = new System.Drawing.Point(354, 25);
            this.lblPeran1.Size = new System.Drawing.Size(76, 26);
            this.lblPeran1.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblPeran1.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblPeran1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblPeran1.Radius = 8;
            this.lblPeran1.Text = "Admin";
            this.lblPeran1.Name = "lblPeran1";
            // pnlGaris1
            //
            this.pnlGaris1.Location = new System.Drawing.Point(18, 72);
            this.pnlGaris1.Size = new System.Drawing.Size(412, 1);
            this.pnlGaris1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGaris1.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGaris1.Radius = 0;
            this.pnlGaris1.Name = "pnlGaris1";
            // lblAvatar2
            //
            this.lblAvatar2.Location = new System.Drawing.Point(18, 88);
            this.lblAvatar2.Size = new System.Drawing.Size(44, 44);
            this.lblAvatar2.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblAvatar2.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblAvatar2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblAvatar2.Radius = 22;
            this.lblAvatar2.Text = "R";
            this.lblAvatar2.Name = "lblAvatar2";
            // lblNama2
            //
            this.lblNama2.Location = new System.Drawing.Point(76, 90);
            this.lblNama2.AutoSize = true;
            this.lblNama2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblNama2.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblNama2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblNama2.Text = "Rina Putri";
            this.lblNama2.Name = "lblNama2";
            // lblUser2
            //
            this.lblUser2.Location = new System.Drawing.Point(76, 114);
            this.lblUser2.AutoSize = true;
            this.lblUser2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblUser2.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblUser2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblUser2.Text = "rina";
            this.lblUser2.Name = "lblUser2";
            // lblPeran2
            //
            this.lblPeran2.Location = new System.Drawing.Point(354, 97);
            this.lblPeran2.Size = new System.Drawing.Size(76, 26);
            this.lblPeran2.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblPeran2.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblPeran2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblPeran2.Radius = 8;
            this.lblPeran2.Text = "Kasir";
            this.lblPeran2.Name = "lblPeran2";
            // pnlGaris2
            //
            this.pnlGaris2.Location = new System.Drawing.Point(18, 144);
            this.pnlGaris2.Size = new System.Drawing.Size(412, 1);
            this.pnlGaris2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGaris2.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGaris2.Radius = 0;
            this.pnlGaris2.Name = "pnlGaris2";
            // lblAvatar3
            //
            this.lblAvatar3.Location = new System.Drawing.Point(18, 160);
            this.lblAvatar3.Size = new System.Drawing.Size(44, 44);
            this.lblAvatar3.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblAvatar3.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblAvatar3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblAvatar3.Radius = 22;
            this.lblAvatar3.Text = "D";
            this.lblAvatar3.Name = "lblAvatar3";
            // lblNama3
            //
            this.lblNama3.Location = new System.Drawing.Point(76, 162);
            this.lblNama3.AutoSize = true;
            this.lblNama3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblNama3.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblNama3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblNama3.Text = "Dimas";
            this.lblNama3.Name = "lblNama3";
            // lblUser3
            //
            this.lblUser3.Location = new System.Drawing.Point(76, 186);
            this.lblUser3.AutoSize = true;
            this.lblUser3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblUser3.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblUser3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblUser3.Text = "dimas";
            this.lblUser3.Name = "lblUser3";
            // lblPeran3
            //
            this.lblPeran3.Location = new System.Drawing.Point(354, 169);
            this.lblPeran3.Size = new System.Drawing.Size(76, 26);
            this.lblPeran3.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblPeran3.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblPeran3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblPeran3.Radius = 8;
            this.lblPeran3.Text = "Kasir";
            this.lblPeran3.Name = "lblPeran3";
            // pnlGaris3
            //
            this.pnlGaris3.Location = new System.Drawing.Point(18, 216);
            this.pnlGaris3.Size = new System.Drawing.Size(412, 1);
            this.pnlGaris3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGaris3.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGaris3.Radius = 0;
            this.pnlGaris3.Name = "pnlGaris3";
            // lblAvatar4
            //
            this.lblAvatar4.Location = new System.Drawing.Point(18, 232);
            this.lblAvatar4.Size = new System.Drawing.Size(44, 44);
            this.lblAvatar4.BackColor = System.Drawing.Color.FromArgb(44, 67, 150);
            this.lblAvatar4.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblAvatar4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblAvatar4.Radius = 22;
            this.lblAvatar4.Text = "S";
            this.lblAvatar4.Name = "lblAvatar4";
            // lblNama4
            //
            this.lblNama4.Location = new System.Drawing.Point(76, 234);
            this.lblNama4.AutoSize = true;
            this.lblNama4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblNama4.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblNama4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblNama4.Text = "Sinta";
            this.lblNama4.Name = "lblNama4";
            // lblUser4
            //
            this.lblUser4.Location = new System.Drawing.Point(76, 258);
            this.lblUser4.AutoSize = true;
            this.lblUser4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblUser4.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblUser4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblUser4.Text = "gudang01 · nonaktif";
            this.lblUser4.Name = "lblUser4";
            // lblPeran4
            //
            this.lblPeran4.Location = new System.Drawing.Point(346, 241);
            this.lblPeran4.Size = new System.Drawing.Size(84, 26);
            this.lblPeran4.BackColor = System.Drawing.Color.FromArgb(44, 67, 150);
            this.lblPeran4.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblPeran4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblPeran4.Radius = 8;
            this.lblPeran4.Text = "Gudang";
            this.lblPeran4.Name = "lblPeran4";
            // btnToggle
            //
            this.btnToggle.Location = new System.Drawing.Point(18, 316);
            this.btnToggle.Size = new System.Drawing.Size(200, 44);
            this.btnToggle.BackColor = System.Drawing.Color.FromArgb(42, 58, 114);
            this.btnToggle.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnToggle.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnToggle.Radius = 12;
            this.btnToggle.UseVisualStyleBackColor = false;
            this.btnToggle.Text = "Aktif / nonaktif";
            this.btnToggle.Name = "btnToggle";
            // btnHapus
            //
            this.btnHapus.Location = new System.Drawing.Point(230, 316);
            this.btnHapus.Size = new System.Drawing.Size(200, 44);
            this.btnHapus.BackColor = System.Drawing.Color.FromArgb(42, 58, 114);
            this.btnHapus.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnHapus.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnHapus.Radius = 12;
            this.btnHapus.UseVisualStyleBackColor = false;
            this.btnHapus.Text = "Hapus";
            this.btnHapus.Name = "btnHapus";
            // pnlForm
            //
            this.pnlForm.Location = new System.Drawing.Point(492, 190);
            this.pnlForm.Size = new System.Drawing.Size(450, 444);
            this.pnlForm.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlForm.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlForm.Radius = 14;
            this.pnlForm.Name = "pnlForm";
            this.pnlForm.Controls.Add(this.lblFormJudul);
            this.pnlForm.Controls.Add(this.lblNamaLengkap);
            this.pnlForm.Controls.Add(this.txtNama);
            this.pnlForm.Controls.Add(this.lblUsername);
            this.pnlForm.Controls.Add(this.txtUsername);
            this.pnlForm.Controls.Add(this.lblSandi);
            this.pnlForm.Controls.Add(this.txtSandi);
            this.pnlForm.Controls.Add(this.lblPeran);
            this.pnlForm.Controls.Add(this.pnlCboPeran);
            this.pnlForm.Controls.Add(this.btnBatal);
            this.pnlForm.Controls.Add(this.btnSimpan);
            // lblFormJudul
            //
            this.lblFormJudul.Location = new System.Drawing.Point(18, 14);
            this.lblFormJudul.AutoSize = true;
            this.lblFormJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblFormJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblFormJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblFormJudul.Text = "Tambah pengguna baru";
            this.lblFormJudul.Name = "lblFormJudul";
            // lblNamaLengkap
            //
            this.lblNamaLengkap.Location = new System.Drawing.Point(20, 50);
            this.lblNamaLengkap.AutoSize = true;
            this.lblNamaLengkap.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblNamaLengkap.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblNamaLengkap.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNamaLengkap.Text = "Nama lengkap";
            this.lblNamaLengkap.Name = "lblNamaLengkap";
            // txtNama
            //
            this.txtNama.Location = new System.Drawing.Point(18, 72);
            this.txtNama.Size = new System.Drawing.Size(414, 46);
            this.txtNama.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtNama.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtNama.PlaceholderText = "mis. Budi Santoso";
            this.txtNama.Name = "txtNama";
            // lblUsername
            //
            this.lblUsername.Location = new System.Drawing.Point(20, 128);
            this.lblUsername.AutoSize = true;
            this.lblUsername.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblUsername.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblUsername.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblUsername.Text = "Username";
            this.lblUsername.Name = "lblUsername";
            // txtUsername
            //
            this.txtUsername.Location = new System.Drawing.Point(18, 150);
            this.txtUsername.Size = new System.Drawing.Size(414, 46);
            this.txtUsername.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtUsername.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtUsername.PlaceholderText = "mis. budi01";
            this.txtUsername.Name = "txtUsername";
            // lblSandi
            //
            this.lblSandi.Location = new System.Drawing.Point(20, 206);
            this.lblSandi.AutoSize = true;
            this.lblSandi.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblSandi.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSandi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblSandi.Text = "Kata sandi";
            this.lblSandi.Name = "lblSandi";
            // txtSandi
            //
            this.txtSandi.Location = new System.Drawing.Point(18, 228);
            this.txtSandi.Size = new System.Drawing.Size(414, 46);
            this.txtSandi.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtSandi.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtSandi.UseSystemPasswordChar = true;
            this.txtSandi.Text = "password";
            this.txtSandi.Name = "txtSandi";
            // lblPeran
            //
            this.lblPeran.Location = new System.Drawing.Point(20, 284);
            this.lblPeran.AutoSize = true;
            this.lblPeran.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblPeran.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblPeran.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPeran.Text = "Peran";
            this.lblPeran.Name = "lblPeran";
            // pnlCboPeran
            //
            this.pnlCboPeran.Location = new System.Drawing.Point(18, 306);
            this.pnlCboPeran.Size = new System.Drawing.Size(414, 46);
            this.pnlCboPeran.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlCboPeran.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlCboPeran.Radius = 12;
            this.pnlCboPeran.BorderColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlCboPeran.BorderSize = 1;
            this.pnlCboPeran.Name = "pnlCboPeran";
            this.pnlCboPeran.Controls.Add(this.cboPeran);
            // cboPeran
            //
            this.cboPeran.Location = new System.Drawing.Point(12, 8);
            this.cboPeran.Size = new System.Drawing.Size(390, 30);
            this.cboPeran.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.cboPeran.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.cboPeran.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPeran.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboPeran.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.cboPeran.FormattingEnabled = true;
            this.cboPeran.Name = "cboPeran";
            this.cboPeran.Items.AddRange(new object[] { "Kasir", "Admin", "Gudang" });
            this.cboPeran.SelectedIndex = 0;
            // btnBatal
            //
            this.btnBatal.Location = new System.Drawing.Point(18, 376);
            this.btnBatal.Size = new System.Drawing.Size(200, 48);
            this.btnBatal.BackColor = System.Drawing.Color.FromArgb(42, 58, 114);
            this.btnBatal.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnBatal.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnBatal.Radius = 12;
            this.btnBatal.UseVisualStyleBackColor = false;
            this.btnBatal.Text = "Batal";
            this.btnBatal.Name = "btnBatal";
            // btnSimpan
            //
            this.btnSimpan.Location = new System.Drawing.Point(232, 376);
            this.btnSimpan.Size = new System.Drawing.Size(200, 48);
            this.btnSimpan.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnSimpan.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnSimpan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSimpan.Radius = 12;
            this.btnSimpan.UseVisualStyleBackColor = false;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.Name = "btnSimpan";
            //
            // ucPengguna
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.Size = new System.Drawing.Size(970, 720);
            this.Name = "ucPengguna";
            this.Controls.Add(this.lblJudul);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.btnTambah);
            this.Controls.Add(this.pnlStat1);
            this.Controls.Add(this.pnlStat2);
            this.Controls.Add(this.pnlStat3);
            this.Controls.Add(this.pnlStat4);
            this.Controls.Add(this.pnlDaftar);
            this.Controls.Add(this.pnlForm);
            this.pnlStat1.ResumeLayout(false);
            this.pnlStat2.ResumeLayout(false);
            this.pnlStat3.ResumeLayout(false);
            this.pnlStat4.ResumeLayout(false);
            this.pnlDaftar.ResumeLayout(false);
            this.pnlForm.ResumeLayout(false);
            this.pnlCboPeran.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label lblJudul;
        private System.Windows.Forms.Label lblSub;
        private SMKMart.Controls.RoundedButton btnTambah;
        private SMKMart.Controls.RoundedPanel pnlStat1;
        private System.Windows.Forms.Label lblStat1Judul;
        private System.Windows.Forms.Label lblStat1Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat2;
        private System.Windows.Forms.Label lblStat2Judul;
        private System.Windows.Forms.Label lblStat2Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat3;
        private System.Windows.Forms.Label lblStat3Judul;
        private System.Windows.Forms.Label lblStat3Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat4;
        private System.Windows.Forms.Label lblStat4Judul;
        private System.Windows.Forms.Label lblStat4Nilai;
        private SMKMart.Controls.RoundedPanel pnlDaftar;
        private SMKMart.Controls.RoundedLabel lblAvatar1;
        private System.Windows.Forms.Label lblNama1;
        private System.Windows.Forms.Label lblUser1;
        private SMKMart.Controls.RoundedLabel lblPeran1;
        private SMKMart.Controls.RoundedPanel pnlGaris1;
        private SMKMart.Controls.RoundedLabel lblAvatar2;
        private System.Windows.Forms.Label lblNama2;
        private System.Windows.Forms.Label lblUser2;
        private SMKMart.Controls.RoundedLabel lblPeran2;
        private SMKMart.Controls.RoundedPanel pnlGaris2;
        private SMKMart.Controls.RoundedLabel lblAvatar3;
        private System.Windows.Forms.Label lblNama3;
        private System.Windows.Forms.Label lblUser3;
        private SMKMart.Controls.RoundedLabel lblPeran3;
        private SMKMart.Controls.RoundedPanel pnlGaris3;
        private SMKMart.Controls.RoundedLabel lblAvatar4;
        private System.Windows.Forms.Label lblNama4;
        private System.Windows.Forms.Label lblUser4;
        private SMKMart.Controls.RoundedLabel lblPeran4;
        private SMKMart.Controls.RoundedButton btnToggle;
        private SMKMart.Controls.RoundedButton btnHapus;
        private SMKMart.Controls.RoundedPanel pnlForm;
        private System.Windows.Forms.Label lblFormJudul;
        private System.Windows.Forms.Label lblNamaLengkap;
        private SMKMart.Controls.RoundedTextBox txtNama;
        private System.Windows.Forms.Label lblUsername;
        private SMKMart.Controls.RoundedTextBox txtUsername;
        private System.Windows.Forms.Label lblSandi;
        private SMKMart.Controls.RoundedTextBox txtSandi;
        private System.Windows.Forms.Label lblPeran;
        private SMKMart.Controls.RoundedPanel pnlCboPeran;
        private System.Windows.Forms.ComboBox cboPeran;
        private SMKMart.Controls.RoundedButton btnBatal;
        private SMKMart.Controls.RoundedButton btnSimpan;
    }
}
