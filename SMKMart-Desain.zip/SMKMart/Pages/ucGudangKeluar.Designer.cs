namespace SMKMart.Pages
{
    partial class ucGudangKeluar
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblJudul = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.pnlTabs = new SMKMart.Controls.RoundedPanel();
            this.btnTabMasuk = new SMKMart.Controls.RoundedButton();
            this.btnTabKeluar = new SMKMart.Controls.RoundedButton();
            this.btnTabStok = new SMKMart.Controls.RoundedButton();
            this.pnlForm = new SMKMart.Controls.RoundedPanel();
            this.lblFormJudul = new System.Windows.Forms.Label();
            this.lblBarang = new System.Windows.Forms.Label();
            this.lblJumlah = new System.Windows.Forms.Label();
            this.lblAlasan = new System.Windows.Forms.Label();
            this.lblTanggal = new System.Windows.Forms.Label();
            this.pnlCboBarang = new SMKMart.Controls.RoundedPanel();
            this.cboBarang = new System.Windows.Forms.ComboBox();
            this.txtJumlah = new SMKMart.Controls.RoundedTextBox();
            this.pnlCboAlasan = new SMKMart.Controls.RoundedPanel();
            this.cboAlasan = new System.Windows.Forms.ComboBox();
            this.txtTanggal = new SMKMart.Controls.RoundedTextBox();
            this.pnlInfoStok = new SMKMart.Controls.RoundedPanel();
            this.lblInfoStok = new System.Windows.Forms.Label();
            this.btnBatal = new SMKMart.Controls.RoundedButton();
            this.btnSimpan = new SMKMart.Controls.RoundedButton();
            this.pnlRiwayat = new SMKMart.Controls.RoundedPanel();
            this.lblRiwayatJudul = new System.Windows.Forms.Label();
            this.dgvRiwayat = new SMKMart.Controls.DarkGrid();
            this.colTanggal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBarang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colJumlah = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colAlasan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPetugas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRiwayat)).BeginInit();
            this.SuspendLayout();
            this.pnlTabs.SuspendLayout();
            this.pnlForm.SuspendLayout();
            this.pnlCboBarang.SuspendLayout();
            this.pnlCboAlasan.SuspendLayout();
            this.pnlInfoStok.SuspendLayout();
            this.pnlRiwayat.SuspendLayout();
            //
            // lblJudul
            //
            this.lblJudul.Location = new System.Drawing.Point(28, 20);
            this.lblJudul.AutoSize = true;
            this.lblJudul.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblJudul.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblJudul.Text = "Gudang";
            this.lblJudul.Name = "lblJudul";
            // lblSub
            //
            this.lblSub.Location = new System.Drawing.Point(30, 62);
            this.lblSub.AutoSize = true;
            this.lblSub.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSub.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSub.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSub.Text = "Catat barang masuk, barang keluar, dan pantau stok";
            this.lblSub.Name = "lblSub";
            // pnlTabs
            //
            this.pnlTabs.Location = new System.Drawing.Point(28, 92);
            this.pnlTabs.Size = new System.Drawing.Size(376, 52);
            this.pnlTabs.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlTabs.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTabs.Radius = 14;
            this.pnlTabs.Name = "pnlTabs";
            this.pnlTabs.Controls.Add(this.btnTabMasuk);
            this.pnlTabs.Controls.Add(this.btnTabKeluar);
            this.pnlTabs.Controls.Add(this.btnTabStok);
            // btnTabMasuk
            //
            this.btnTabMasuk.Location = new System.Drawing.Point(6, 6);
            this.btnTabMasuk.Size = new System.Drawing.Size(120, 40);
            this.btnTabMasuk.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.btnTabMasuk.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnTabMasuk.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabMasuk.Radius = 10;
            this.btnTabMasuk.UseVisualStyleBackColor = false;
            this.btnTabMasuk.Text = "Barang masuk";
            this.btnTabMasuk.Name = "btnTabMasuk";
            // btnTabKeluar
            //
            this.btnTabKeluar.Location = new System.Drawing.Point(132, 6);
            this.btnTabKeluar.Size = new System.Drawing.Size(124, 40);
            this.btnTabKeluar.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.btnTabKeluar.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnTabKeluar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabKeluar.Radius = 10;
            this.btnTabKeluar.UseVisualStyleBackColor = false;
            this.btnTabKeluar.Text = "Barang keluar";
            this.btnTabKeluar.Name = "btnTabKeluar";
            // btnTabStok
            //
            this.btnTabStok.Location = new System.Drawing.Point(262, 6);
            this.btnTabStok.Size = new System.Drawing.Size(108, 40);
            this.btnTabStok.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.btnTabStok.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnTabStok.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabStok.Radius = 10;
            this.btnTabStok.UseVisualStyleBackColor = false;
            this.btnTabStok.Text = "Stok barang";
            this.btnTabStok.Name = "btnTabStok";
            // pnlForm
            //
            this.pnlForm.Location = new System.Drawing.Point(28, 158);
            this.pnlForm.Size = new System.Drawing.Size(914, 322);
            this.pnlForm.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlForm.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlForm.Radius = 14;
            this.pnlForm.Name = "pnlForm";
            this.pnlForm.Controls.Add(this.lblFormJudul);
            this.pnlForm.Controls.Add(this.lblBarang);
            this.pnlForm.Controls.Add(this.lblJumlah);
            this.pnlForm.Controls.Add(this.lblAlasan);
            this.pnlForm.Controls.Add(this.lblTanggal);
            this.pnlForm.Controls.Add(this.pnlCboBarang);
            this.pnlForm.Controls.Add(this.txtJumlah);
            this.pnlForm.Controls.Add(this.pnlCboAlasan);
            this.pnlForm.Controls.Add(this.txtTanggal);
            this.pnlForm.Controls.Add(this.pnlInfoStok);
            this.pnlForm.Controls.Add(this.btnBatal);
            this.pnlForm.Controls.Add(this.btnSimpan);
            // lblFormJudul
            //
            this.lblFormJudul.Location = new System.Drawing.Point(18, 14);
            this.lblFormJudul.AutoSize = true;
            this.lblFormJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblFormJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblFormJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblFormJudul.Text = "Catat barang keluar";
            this.lblFormJudul.Name = "lblFormJudul";
            // lblBarang
            //
            this.lblBarang.Location = new System.Drawing.Point(20, 46);
            this.lblBarang.AutoSize = true;
            this.lblBarang.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblBarang.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblBarang.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblBarang.Text = "Barang";
            this.lblBarang.Name = "lblBarang";
            // lblJumlah
            //
            this.lblJumlah.Location = new System.Drawing.Point(312, 46);
            this.lblJumlah.AutoSize = true;
            this.lblJumlah.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblJumlah.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblJumlah.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblJumlah.Text = "Jumlah";
            this.lblJumlah.Name = "lblJumlah";
            // lblAlasan
            //
            this.lblAlasan.Location = new System.Drawing.Point(604, 46);
            this.lblAlasan.AutoSize = true;
            this.lblAlasan.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblAlasan.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblAlasan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblAlasan.Text = "Alasan";
            this.lblAlasan.Name = "lblAlasan";
            // lblTanggal
            //
            this.lblTanggal.Location = new System.Drawing.Point(20, 132);
            this.lblTanggal.AutoSize = true;
            this.lblTanggal.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblTanggal.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblTanggal.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblTanggal.Text = "Tanggal";
            this.lblTanggal.Name = "lblTanggal";
            // pnlCboBarang
            //
            this.pnlCboBarang.Location = new System.Drawing.Point(18, 68);
            this.pnlCboBarang.Size = new System.Drawing.Size(280, 46);
            this.pnlCboBarang.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlCboBarang.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlCboBarang.Radius = 12;
            this.pnlCboBarang.BorderColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlCboBarang.BorderSize = 1;
            this.pnlCboBarang.Name = "pnlCboBarang";
            this.pnlCboBarang.Controls.Add(this.cboBarang);
            // cboBarang
            //
            this.cboBarang.Location = new System.Drawing.Point(12, 8);
            this.cboBarang.Size = new System.Drawing.Size(256, 30);
            this.cboBarang.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.cboBarang.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.cboBarang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBarang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboBarang.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.cboBarang.FormattingEnabled = true;
            this.cboBarang.Name = "cboBarang";
            this.cboBarang.Items.AddRange(new object[] { "Mi instan", "Beras 5 kg", "Buku tulis", "Air mineral" });
            this.cboBarang.SelectedIndex = 0;
            // txtJumlah
            //
            this.txtJumlah.Location = new System.Drawing.Point(310, 68);
            this.txtJumlah.Size = new System.Drawing.Size(280, 46);
            this.txtJumlah.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtJumlah.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtJumlah.PlaceholderText = "mis. 5";
            this.txtJumlah.Name = "txtJumlah";
            // pnlCboAlasan
            //
            this.pnlCboAlasan.Location = new System.Drawing.Point(602, 68);
            this.pnlCboAlasan.Size = new System.Drawing.Size(294, 46);
            this.pnlCboAlasan.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlCboAlasan.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlCboAlasan.Radius = 12;
            this.pnlCboAlasan.BorderColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlCboAlasan.BorderSize = 1;
            this.pnlCboAlasan.Name = "pnlCboAlasan";
            this.pnlCboAlasan.Controls.Add(this.cboAlasan);
            // cboAlasan
            //
            this.cboAlasan.Location = new System.Drawing.Point(12, 8);
            this.cboAlasan.Size = new System.Drawing.Size(270, 30);
            this.cboAlasan.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.cboAlasan.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.cboAlasan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAlasan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboAlasan.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.cboAlasan.FormattingEnabled = true;
            this.cboAlasan.Name = "cboAlasan";
            this.cboAlasan.Items.AddRange(new object[] { "Kadaluarsa", "Rusak", "Retur", "Lainnya" });
            this.cboAlasan.SelectedIndex = 0;
            // txtTanggal
            //
            this.txtTanggal.Location = new System.Drawing.Point(18, 154);
            this.txtTanggal.Size = new System.Drawing.Size(280, 46);
            this.txtTanggal.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtTanggal.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.txtTanggal.Text = "03/10/2026";
            this.txtTanggal.Name = "txtTanggal";
            // pnlInfoStok
            //
            this.pnlInfoStok.Location = new System.Drawing.Point(18, 214);
            this.pnlInfoStok.Size = new System.Drawing.Size(878, 42);
            this.pnlInfoStok.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlInfoStok.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlInfoStok.Radius = 10;
            this.pnlInfoStok.Name = "pnlInfoStok";
            this.pnlInfoStok.Controls.Add(this.lblInfoStok);
            // lblInfoStok
            //
            this.lblInfoStok.Location = new System.Drawing.Point(16, 11);
            this.lblInfoStok.AutoSize = true;
            this.lblInfoStok.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.lblInfoStok.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblInfoStok.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblInfoStok.Text = "Stok tersedia: 9. Jumlah keluar tidak boleh melebihi stok.";
            this.lblInfoStok.Name = "lblInfoStok";
            // btnBatal
            //
            this.btnBatal.Location = new System.Drawing.Point(586, 266);
            this.btnBatal.Size = new System.Drawing.Size(150, 46);
            this.btnBatal.BackColor = System.Drawing.Color.FromArgb(42, 58, 114);
            this.btnBatal.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnBatal.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnBatal.Radius = 12;
            this.btnBatal.UseVisualStyleBackColor = false;
            this.btnBatal.Text = "Batal";
            this.btnBatal.Name = "btnBatal";
            // btnSimpan
            //
            this.btnSimpan.Location = new System.Drawing.Point(746, 266);
            this.btnSimpan.Size = new System.Drawing.Size(150, 46);
            this.btnSimpan.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.btnSimpan.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnSimpan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSimpan.Radius = 12;
            this.btnSimpan.UseVisualStyleBackColor = false;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.Name = "btnSimpan";
            // pnlRiwayat
            //
            this.pnlRiwayat.Location = new System.Drawing.Point(28, 494);
            this.pnlRiwayat.Size = new System.Drawing.Size(914, 214);
            this.pnlRiwayat.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlRiwayat.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlRiwayat.Radius = 14;
            this.pnlRiwayat.Name = "pnlRiwayat";
            this.pnlRiwayat.Controls.Add(this.lblRiwayatJudul);
            this.pnlRiwayat.Controls.Add(this.dgvRiwayat);
            // lblRiwayatJudul
            //
            this.lblRiwayatJudul.Location = new System.Drawing.Point(18, 14);
            this.lblRiwayatJudul.AutoSize = true;
            this.lblRiwayatJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblRiwayatJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblRiwayatJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblRiwayatJudul.Text = "Riwayat barang keluar";
            this.lblRiwayatJudul.Name = "lblRiwayatJudul";
            // dgvRiwayat
            //
            this.dgvRiwayat.Location = new System.Drawing.Point(12, 44);
            this.dgvRiwayat.Size = new System.Drawing.Size(890, 160);
            this.dgvRiwayat.BackgroundColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.dgvRiwayat.Name = "dgvRiwayat";
            this.colTanggal.HeaderText = "Tanggal";
            this.colTanggal.Name = "colTanggal";
            this.colTanggal.FillWeight = 18F;
            this.colTanggal.MinimumWidth = 6;
            this.colBarang.HeaderText = "Barang";
            this.colBarang.Name = "colBarang";
            this.colBarang.FillWeight = 30F;
            this.colBarang.MinimumWidth = 6;
            this.colJumlah.HeaderText = "Jumlah";
            this.colJumlah.Name = "colJumlah";
            this.colJumlah.FillWeight = 12F;
            this.colJumlah.MinimumWidth = 6;
            this.colJumlah.DefaultCellStyle = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colJumlah.HeaderCell.Style = new System.Windows.Forms.DataGridViewCellStyle { Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight };
            this.colAlasan.HeaderText = "Alasan";
            this.colAlasan.Name = "colAlasan";
            this.colAlasan.FillWeight = 18F;
            this.colAlasan.MinimumWidth = 6;
            this.colPetugas.HeaderText = "Petugas";
            this.colPetugas.Name = "colPetugas";
            this.colPetugas.FillWeight = 22F;
            this.colPetugas.MinimumWidth = 6;
            this.dgvRiwayat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { this.colTanggal, this.colBarang, this.colJumlah, this.colAlasan, this.colPetugas });
            //
            // ucGudangKeluar
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.Size = new System.Drawing.Size(970, 720);
            this.Name = "ucGudangKeluar";
            this.Controls.Add(this.lblJudul);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.pnlTabs);
            this.Controls.Add(this.pnlForm);
            this.Controls.Add(this.pnlRiwayat);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRiwayat)).EndInit();
            this.pnlTabs.ResumeLayout(false);
            this.pnlForm.ResumeLayout(false);
            this.pnlCboBarang.ResumeLayout(false);
            this.pnlCboAlasan.ResumeLayout(false);
            this.pnlInfoStok.ResumeLayout(false);
            this.pnlRiwayat.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label lblJudul;
        private System.Windows.Forms.Label lblSub;
        private SMKMart.Controls.RoundedPanel pnlTabs;
        private SMKMart.Controls.RoundedButton btnTabMasuk;
        private SMKMart.Controls.RoundedButton btnTabKeluar;
        private SMKMart.Controls.RoundedButton btnTabStok;
        private SMKMart.Controls.RoundedPanel pnlForm;
        private System.Windows.Forms.Label lblFormJudul;
        private System.Windows.Forms.Label lblBarang;
        private System.Windows.Forms.Label lblJumlah;
        private System.Windows.Forms.Label lblAlasan;
        private System.Windows.Forms.Label lblTanggal;
        private SMKMart.Controls.RoundedPanel pnlCboBarang;
        private System.Windows.Forms.ComboBox cboBarang;
        private SMKMart.Controls.RoundedTextBox txtJumlah;
        private SMKMart.Controls.RoundedPanel pnlCboAlasan;
        private System.Windows.Forms.ComboBox cboAlasan;
        private SMKMart.Controls.RoundedTextBox txtTanggal;
        private SMKMart.Controls.RoundedPanel pnlInfoStok;
        private System.Windows.Forms.Label lblInfoStok;
        private SMKMart.Controls.RoundedButton btnBatal;
        private SMKMart.Controls.RoundedButton btnSimpan;
        private SMKMart.Controls.RoundedPanel pnlRiwayat;
        private System.Windows.Forms.Label lblRiwayatJudul;
        private SMKMart.Controls.DarkGrid dgvRiwayat;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTanggal;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBarang;
        private System.Windows.Forms.DataGridViewTextBoxColumn colJumlah;
        private System.Windows.Forms.DataGridViewTextBoxColumn colAlasan;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPetugas;
    }
}
