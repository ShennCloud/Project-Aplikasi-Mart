namespace SMKMart.Pages
{
    partial class ucLaporanGudang
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblJudul = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.btnCetak = new SMKMart.Controls.RoundedButton();
            this.btnSimpan = new SMKMart.Controls.RoundedButton();
            this.pnlTabs = new SMKMart.Controls.RoundedPanel();
            this.btnTabPenjualan = new SMKMart.Controls.RoundedButton();
            this.btnTabGudang = new SMKMart.Controls.RoundedButton();
            this.lblDari = new System.Windows.Forms.Label();
            this.txtDari = new SMKMart.Controls.RoundedTextBox();
            this.lblSampai = new System.Windows.Forms.Label();
            this.txtSampai = new SMKMart.Controls.RoundedTextBox();
            this.btnTampilkan = new SMKMart.Controls.RoundedButton();
            this.pnlStat1 = new SMKMart.Controls.RoundedPanel();
            this.lblStat1Judul = new System.Windows.Forms.Label();
            this.lblStat1Nilai = new System.Windows.Forms.Label();
            this.pnlStat2 = new SMKMart.Controls.RoundedPanel();
            this.lblStat2Judul = new System.Windows.Forms.Label();
            this.lblStat2Nilai = new System.Windows.Forms.Label();
            this.pnlStat3 = new SMKMart.Controls.RoundedPanel();
            this.lblStat3Judul = new System.Windows.Forms.Label();
            this.lblStat3Nilai = new System.Windows.Forms.Label();
            this.pnlStat4 = new SMKMart.Controls.RoundedPanel();
            this.lblStat4Judul = new System.Windows.Forms.Label();
            this.lblStat4Nilai = new System.Windows.Forms.Label();
            this.pnlStokPerBarang = new SMKMart.Controls.RoundedPanel();
            this.lblStokJudul = new System.Windows.Forms.Label();
            this.lblStokNama1 = new System.Windows.Forms.Label();
            this.lblStokNilai1 = new System.Windows.Forms.Label();
            this.pnlStok1Track = new SMKMart.Controls.RoundedPanel();
            this.pnlStok1Isi = new SMKMart.Controls.RoundedPanel();
            this.lblStokNama2 = new System.Windows.Forms.Label();
            this.lblStokNilai2 = new System.Windows.Forms.Label();
            this.pnlStok2Track = new SMKMart.Controls.RoundedPanel();
            this.pnlStok2Isi = new SMKMart.Controls.RoundedPanel();
            this.lblStokNama3 = new System.Windows.Forms.Label();
            this.lblStokNilai3 = new System.Windows.Forms.Label();
            this.pnlStok3Track = new SMKMart.Controls.RoundedPanel();
            this.pnlStok3Isi = new SMKMart.Controls.RoundedPanel();
            this.lblStokNama4 = new System.Windows.Forms.Label();
            this.lblStokNilai4 = new System.Windows.Forms.Label();
            this.pnlStok4Track = new SMKMart.Controls.RoundedPanel();
            this.pnlStok4Isi = new SMKMart.Controls.RoundedPanel();
            this.pnlAktivitas = new SMKMart.Controls.RoundedPanel();
            this.lblAktivitasJudul = new System.Windows.Forms.Label();
            this.lblAktJenis1 = new SMKMart.Controls.RoundedLabel();
            this.lblAktBarang1 = new System.Windows.Forms.Label();
            this.lblAktTgl1 = new System.Windows.Forms.Label();
            this.pnlGarisAkt1 = new SMKMart.Controls.RoundedPanel();
            this.lblAktJenis2 = new SMKMart.Controls.RoundedLabel();
            this.lblAktBarang2 = new System.Windows.Forms.Label();
            this.lblAktTgl2 = new System.Windows.Forms.Label();
            this.pnlGarisAkt2 = new SMKMart.Controls.RoundedPanel();
            this.lblAktJenis3 = new SMKMart.Controls.RoundedLabel();
            this.lblAktBarang3 = new System.Windows.Forms.Label();
            this.lblAktTgl3 = new System.Windows.Forms.Label();
            this.pnlGarisAkt3 = new SMKMart.Controls.RoundedPanel();
            this.lblAktJenis4 = new SMKMart.Controls.RoundedLabel();
            this.lblAktBarang4 = new System.Windows.Forms.Label();
            this.lblAktTgl4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            this.pnlTabs.SuspendLayout();
            this.pnlStat1.SuspendLayout();
            this.pnlStat2.SuspendLayout();
            this.pnlStat3.SuspendLayout();
            this.pnlStat4.SuspendLayout();
            this.pnlStokPerBarang.SuspendLayout();
            this.pnlStok1Track.SuspendLayout();
            this.pnlStok2Track.SuspendLayout();
            this.pnlStok3Track.SuspendLayout();
            this.pnlStok4Track.SuspendLayout();
            this.pnlAktivitas.SuspendLayout();
            //
            // lblJudul
            //
            this.lblJudul.Location = new System.Drawing.Point(28, 20);
            this.lblJudul.AutoSize = true;
            this.lblJudul.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblJudul.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblJudul.Text = "Laporan";
            this.lblJudul.Name = "lblJudul";
            // lblSub
            //
            this.lblSub.Location = new System.Drawing.Point(30, 62);
            this.lblSub.AutoSize = true;
            this.lblSub.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSub.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSub.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSub.Text = "Stok dan aktivitas gudang";
            this.lblSub.Name = "lblSub";
            // btnCetak
            //
            this.btnCetak.Location = new System.Drawing.Point(680, 22);
            this.btnCetak.Size = new System.Drawing.Size(116, 46);
            this.btnCetak.BackColor = System.Drawing.Color.FromArgb(42, 58, 114);
            this.btnCetak.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnCetak.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnCetak.Radius = 12;
            this.btnCetak.UseVisualStyleBackColor = false;
            this.btnCetak.Text = "Cetak";
            this.btnCetak.Name = "btnCetak";
            // btnSimpan
            //
            this.btnSimpan.Location = new System.Drawing.Point(806, 22);
            this.btnSimpan.Size = new System.Drawing.Size(136, 46);
            this.btnSimpan.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.btnSimpan.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnSimpan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSimpan.Radius = 12;
            this.btnSimpan.UseVisualStyleBackColor = false;
            this.btnSimpan.Text = "Simpan .txt";
            this.btnSimpan.Name = "btnSimpan";
            // pnlTabs
            //
            this.pnlTabs.Location = new System.Drawing.Point(28, 92);
            this.pnlTabs.Size = new System.Drawing.Size(402, 52);
            this.pnlTabs.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlTabs.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlTabs.Radius = 14;
            this.pnlTabs.Name = "pnlTabs";
            this.pnlTabs.Controls.Add(this.btnTabPenjualan);
            this.pnlTabs.Controls.Add(this.btnTabGudang);
            // btnTabPenjualan
            //
            this.btnTabPenjualan.Location = new System.Drawing.Point(6, 6);
            this.btnTabPenjualan.Size = new System.Drawing.Size(168, 40);
            this.btnTabPenjualan.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.btnTabPenjualan.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.btnTabPenjualan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabPenjualan.Radius = 10;
            this.btnTabPenjualan.UseVisualStyleBackColor = false;
            this.btnTabPenjualan.Text = "Laporan penjualan";
            this.btnTabPenjualan.Name = "btnTabPenjualan";
            // btnTabGudang
            //
            this.btnTabGudang.Location = new System.Drawing.Point(180, 6);
            this.btnTabGudang.Size = new System.Drawing.Size(216, 40);
            this.btnTabGudang.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.btnTabGudang.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnTabGudang.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTabGudang.Radius = 10;
            this.btnTabGudang.UseVisualStyleBackColor = false;
            this.btnTabGudang.Text = "Stok dan aktivitas gudang";
            this.btnTabGudang.Name = "btnTabGudang";
            // lblDari
            //
            this.lblDari.Location = new System.Drawing.Point(30, 158);
            this.lblDari.AutoSize = true;
            this.lblDari.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblDari.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblDari.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblDari.Text = "Dari tanggal";
            this.lblDari.Name = "lblDari";
            // txtDari
            //
            this.txtDari.Location = new System.Drawing.Point(28, 178);
            this.txtDari.Size = new System.Drawing.Size(230, 46);
            this.txtDari.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.txtDari.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtDari.Text = "01/10/2026";
            this.txtDari.Name = "txtDari";
            // lblSampai
            //
            this.lblSampai.Location = new System.Drawing.Point(272, 158);
            this.lblSampai.AutoSize = true;
            this.lblSampai.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblSampai.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblSampai.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblSampai.Text = "Sampai tanggal";
            this.lblSampai.Name = "lblSampai";
            // txtSampai
            //
            this.txtSampai.Location = new System.Drawing.Point(270, 178);
            this.txtSampai.Size = new System.Drawing.Size(230, 46);
            this.txtSampai.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.txtSampai.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.txtSampai.Text = "03/10/2026";
            this.txtSampai.Name = "txtSampai";
            // btnTampilkan
            //
            this.btnTampilkan.Location = new System.Drawing.Point(512, 178);
            this.btnTampilkan.Size = new System.Drawing.Size(150, 46);
            this.btnTampilkan.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.btnTampilkan.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.btnTampilkan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnTampilkan.Radius = 12;
            this.btnTampilkan.UseVisualStyleBackColor = false;
            this.btnTampilkan.Text = "Tampilkan";
            this.btnTampilkan.Name = "btnTampilkan";
            // pnlStat1
            //
            this.pnlStat1.Location = new System.Drawing.Point(28, 240);
            this.pnlStat1.Size = new System.Drawing.Size(219, 82);
            this.pnlStat1.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat1.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlStat1.Radius = 14;
            this.pnlStat1.Name = "pnlStat1";
            this.pnlStat1.Controls.Add(this.lblStat1Judul);
            this.pnlStat1.Controls.Add(this.lblStat1Nilai);
            // lblStat1Judul
            //
            this.lblStat1Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat1Judul.AutoSize = true;
            this.lblStat1Judul.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblStat1Judul.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat1Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat1Judul.Text = "Total stok";
            this.lblStat1Judul.Name = "lblStat1Judul";
            // lblStat1Nilai
            //
            this.lblStat1Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat1Nilai.AutoSize = true;
            this.lblStat1Nilai.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblStat1Nilai.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat1Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat1Nilai.Text = "1.236";
            this.lblStat1Nilai.Name = "lblStat1Nilai";
            // pnlStat2
            //
            this.pnlStat2.Location = new System.Drawing.Point(259, 240);
            this.pnlStat2.Size = new System.Drawing.Size(219, 82);
            this.pnlStat2.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat2.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStat2.Radius = 14;
            this.pnlStat2.Name = "pnlStat2";
            this.pnlStat2.Controls.Add(this.lblStat2Judul);
            this.pnlStat2.Controls.Add(this.lblStat2Nilai);
            // lblStat2Judul
            //
            this.lblStat2Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat2Judul.AutoSize = true;
            this.lblStat2Judul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Judul.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStat2Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat2Judul.Text = "Masuk periode ini";
            this.lblStat2Judul.Name = "lblStat2Judul";
            // lblStat2Nilai
            //
            this.lblStat2Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat2Nilai.AutoSize = true;
            this.lblStat2Nilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat2Nilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStat2Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat2Nilai.Text = "320";
            this.lblStat2Nilai.Name = "lblStat2Nilai";
            // pnlStat3
            //
            this.pnlStat3.Location = new System.Drawing.Point(490, 240);
            this.pnlStat3.Size = new System.Drawing.Size(219, 82);
            this.pnlStat3.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat3.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStat3.Radius = 14;
            this.pnlStat3.Name = "pnlStat3";
            this.pnlStat3.Controls.Add(this.lblStat3Judul);
            this.pnlStat3.Controls.Add(this.lblStat3Nilai);
            // lblStat3Judul
            //
            this.lblStat3Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat3Judul.AutoSize = true;
            this.lblStat3Judul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat3Judul.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStat3Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat3Judul.Text = "Keluar periode ini";
            this.lblStat3Judul.Name = "lblStat3Judul";
            // lblStat3Nilai
            //
            this.lblStat3Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat3Nilai.AutoSize = true;
            this.lblStat3Nilai.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStat3Nilai.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStat3Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat3Nilai.Text = "274";
            this.lblStat3Nilai.Name = "lblStat3Nilai";
            // pnlStat4
            //
            this.pnlStat4.Location = new System.Drawing.Point(721, 240);
            this.pnlStat4.Size = new System.Drawing.Size(219, 82);
            this.pnlStat4.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStat4.FillColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlStat4.Radius = 14;
            this.pnlStat4.Name = "pnlStat4";
            this.pnlStat4.Controls.Add(this.lblStat4Judul);
            this.pnlStat4.Controls.Add(this.lblStat4Nilai);
            // lblStat4Judul
            //
            this.lblStat4Judul.Location = new System.Drawing.Point(16, 14);
            this.lblStat4Judul.AutoSize = true;
            this.lblStat4Judul.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat4Judul.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat4Judul.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStat4Judul.Text = "Perlu restok";
            this.lblStat4Judul.Name = "lblStat4Judul";
            // lblStat4Nilai
            //
            this.lblStat4Nilai.Location = new System.Drawing.Point(16, 40);
            this.lblStat4Nilai.AutoSize = true;
            this.lblStat4Nilai.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStat4Nilai.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblStat4Nilai.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblStat4Nilai.Text = "4 barang";
            this.lblStat4Nilai.Name = "lblStat4Nilai";
            // pnlStokPerBarang
            //
            this.pnlStokPerBarang.Location = new System.Drawing.Point(28, 336);
            this.pnlStokPerBarang.Size = new System.Drawing.Size(450, 300);
            this.pnlStokPerBarang.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlStokPerBarang.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStokPerBarang.Radius = 14;
            this.pnlStokPerBarang.Name = "pnlStokPerBarang";
            this.pnlStokPerBarang.Controls.Add(this.lblStokJudul);
            this.pnlStokPerBarang.Controls.Add(this.lblStokNama1);
            this.pnlStokPerBarang.Controls.Add(this.lblStokNilai1);
            this.pnlStokPerBarang.Controls.Add(this.pnlStok1Track);
            this.pnlStokPerBarang.Controls.Add(this.lblStokNama2);
            this.pnlStokPerBarang.Controls.Add(this.lblStokNilai2);
            this.pnlStokPerBarang.Controls.Add(this.pnlStok2Track);
            this.pnlStokPerBarang.Controls.Add(this.lblStokNama3);
            this.pnlStokPerBarang.Controls.Add(this.lblStokNilai3);
            this.pnlStokPerBarang.Controls.Add(this.pnlStok3Track);
            this.pnlStokPerBarang.Controls.Add(this.lblStokNama4);
            this.pnlStokPerBarang.Controls.Add(this.lblStokNilai4);
            this.pnlStokPerBarang.Controls.Add(this.pnlStok4Track);
            // lblStokJudul
            //
            this.lblStokJudul.Location = new System.Drawing.Point(18, 14);
            this.lblStokJudul.AutoSize = true;
            this.lblStokJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblStokJudul.Text = "Stok per barang";
            this.lblStokJudul.Name = "lblStokJudul";
            // lblStokNama1
            //
            this.lblStokNama1.Location = new System.Drawing.Point(18, 52);
            this.lblStokNama1.AutoSize = true;
            this.lblStokNama1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNama1.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokNama1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStokNama1.Text = "Buku tulis";
            this.lblStokNama1.Name = "lblStokNama1";
            // lblStokNilai1
            //
            this.lblStokNilai1.Location = new System.Drawing.Point(250, 52);
            this.lblStokNilai1.Size = new System.Drawing.Size(184, 20);
            this.lblStokNilai1.AutoSize = false;
            this.lblStokNilai1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNilai1.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStokNilai1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStokNilai1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblStokNilai1.Text = "42 / min 10";
            this.lblStokNilai1.Name = "lblStokNilai1";
            // pnlStok1Track
            //
            this.pnlStok1Track.Location = new System.Drawing.Point(18, 80);
            this.pnlStok1Track.Size = new System.Drawing.Size(416, 8);
            this.pnlStok1Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStok1Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlStok1Track.Radius = 4;
            this.pnlStok1Track.Name = "pnlStok1Track";
            this.pnlStok1Track.Controls.Add(this.pnlStok1Isi);
            // pnlStok1Isi
            //
            this.pnlStok1Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlStok1Isi.Size = new System.Drawing.Size(349, 8);
            this.pnlStok1Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlStok1Isi.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlStok1Isi.Radius = 4;
            this.pnlStok1Isi.Name = "pnlStok1Isi";
            // lblStokNama2
            //
            this.lblStokNama2.Location = new System.Drawing.Point(18, 112);
            this.lblStokNama2.AutoSize = true;
            this.lblStokNama2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNama2.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokNama2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStokNama2.Text = "Pulpen hitam";
            this.lblStokNama2.Name = "lblStokNama2";
            // lblStokNilai2
            //
            this.lblStokNilai2.Location = new System.Drawing.Point(250, 112);
            this.lblStokNilai2.Size = new System.Drawing.Size(184, 20);
            this.lblStokNilai2.AutoSize = false;
            this.lblStokNilai2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNilai2.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblStokNilai2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStokNilai2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblStokNilai2.Text = "60 / min 15";
            this.lblStokNilai2.Name = "lblStokNilai2";
            // pnlStok2Track
            //
            this.pnlStok2Track.Location = new System.Drawing.Point(18, 140);
            this.pnlStok2Track.Size = new System.Drawing.Size(416, 8);
            this.pnlStok2Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStok2Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlStok2Track.Radius = 4;
            this.pnlStok2Track.Name = "pnlStok2Track";
            this.pnlStok2Track.Controls.Add(this.pnlStok2Isi);
            // pnlStok2Isi
            //
            this.pnlStok2Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlStok2Isi.Size = new System.Drawing.Size(416, 8);
            this.pnlStok2Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlStok2Isi.FillColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.pnlStok2Isi.Radius = 4;
            this.pnlStok2Isi.Name = "pnlStok2Isi";
            // lblStokNama3
            //
            this.lblStokNama3.Location = new System.Drawing.Point(18, 172);
            this.lblStokNama3.AutoSize = true;
            this.lblStokNama3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNama3.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokNama3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStokNama3.Text = "Mi instan";
            this.lblStokNama3.Name = "lblStokNama3";
            // lblStokNilai3
            //
            this.lblStokNilai3.Location = new System.Drawing.Point(250, 172);
            this.lblStokNilai3.Size = new System.Drawing.Size(184, 20);
            this.lblStokNilai3.AutoSize = false;
            this.lblStokNilai3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNilai3.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStokNilai3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblStokNilai3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblStokNilai3.Text = "9 / min 15";
            this.lblStokNilai3.Name = "lblStokNilai3";
            // pnlStok3Track
            //
            this.pnlStok3Track.Location = new System.Drawing.Point(18, 200);
            this.pnlStok3Track.Size = new System.Drawing.Size(416, 8);
            this.pnlStok3Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStok3Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlStok3Track.Radius = 4;
            this.pnlStok3Track.Name = "pnlStok3Track";
            this.pnlStok3Track.Controls.Add(this.pnlStok3Isi);
            // pnlStok3Isi
            //
            this.pnlStok3Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlStok3Isi.Size = new System.Drawing.Size(124, 8);
            this.pnlStok3Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlStok3Isi.FillColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlStok3Isi.Radius = 4;
            this.pnlStok3Isi.Name = "pnlStok3Isi";
            // lblStokNama4
            //
            this.lblStokNama4.Location = new System.Drawing.Point(18, 232);
            this.lblStokNama4.AutoSize = true;
            this.lblStokNama4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNama4.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblStokNama4.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblStokNama4.Text = "Beras 5 kg";
            this.lblStokNama4.Name = "lblStokNama4";
            // lblStokNilai4
            //
            this.lblStokNilai4.Location = new System.Drawing.Point(250, 232);
            this.lblStokNilai4.Size = new System.Drawing.Size(184, 20);
            this.lblStokNilai4.AutoSize = false;
            this.lblStokNilai4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblStokNilai4.ForeColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblStokNilai4.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblStokNilai4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblStokNilai4.Text = "3 / min 10";
            this.lblStokNilai4.Name = "lblStokNilai4";
            // pnlStok4Track
            //
            this.pnlStok4Track.Location = new System.Drawing.Point(18, 260);
            this.pnlStok4Track.Size = new System.Drawing.Size(416, 8);
            this.pnlStok4Track.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlStok4Track.FillColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlStok4Track.Radius = 4;
            this.pnlStok4Track.Name = "pnlStok4Track";
            this.pnlStok4Track.Controls.Add(this.pnlStok4Isi);
            // pnlStok4Isi
            //
            this.pnlStok4Isi.Location = new System.Drawing.Point(0, 0);
            this.pnlStok4Isi.Size = new System.Drawing.Size(49, 8);
            this.pnlStok4Isi.BackColor = System.Drawing.Color.FromArgb(10, 17, 38);
            this.pnlStok4Isi.FillColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.pnlStok4Isi.Radius = 4;
            this.pnlStok4Isi.Name = "pnlStok4Isi";
            // pnlAktivitas
            //
            this.pnlAktivitas.Location = new System.Drawing.Point(490, 336);
            this.pnlAktivitas.Size = new System.Drawing.Size(452, 300);
            this.pnlAktivitas.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.pnlAktivitas.FillColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlAktivitas.Radius = 14;
            this.pnlAktivitas.Name = "pnlAktivitas";
            this.pnlAktivitas.Controls.Add(this.lblAktivitasJudul);
            this.pnlAktivitas.Controls.Add(this.lblAktJenis1);
            this.pnlAktivitas.Controls.Add(this.lblAktBarang1);
            this.pnlAktivitas.Controls.Add(this.lblAktTgl1);
            this.pnlAktivitas.Controls.Add(this.pnlGarisAkt1);
            this.pnlAktivitas.Controls.Add(this.lblAktJenis2);
            this.pnlAktivitas.Controls.Add(this.lblAktBarang2);
            this.pnlAktivitas.Controls.Add(this.lblAktTgl2);
            this.pnlAktivitas.Controls.Add(this.pnlGarisAkt2);
            this.pnlAktivitas.Controls.Add(this.lblAktJenis3);
            this.pnlAktivitas.Controls.Add(this.lblAktBarang3);
            this.pnlAktivitas.Controls.Add(this.lblAktTgl3);
            this.pnlAktivitas.Controls.Add(this.pnlGarisAkt3);
            this.pnlAktivitas.Controls.Add(this.lblAktJenis4);
            this.pnlAktivitas.Controls.Add(this.lblAktBarang4);
            this.pnlAktivitas.Controls.Add(this.lblAktTgl4);
            // lblAktivitasJudul
            //
            this.lblAktivitasJudul.Location = new System.Drawing.Point(18, 14);
            this.lblAktivitasJudul.AutoSize = true;
            this.lblAktivitasJudul.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblAktivitasJudul.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblAktivitasJudul.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblAktivitasJudul.Text = "Aktivitas terbaru";
            this.lblAktivitasJudul.Name = "lblAktivitasJudul";
            // lblAktJenis1
            //
            this.lblAktJenis1.Location = new System.Drawing.Point(18, 54);
            this.lblAktJenis1.Size = new System.Drawing.Size(76, 26);
            this.lblAktJenis1.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblAktJenis1.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblAktJenis1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblAktJenis1.Radius = 8;
            this.lblAktJenis1.Text = "Masuk";
            this.lblAktJenis1.Name = "lblAktJenis1";
            // lblAktBarang1
            //
            this.lblAktBarang1.Location = new System.Drawing.Point(108, 56);
            this.lblAktBarang1.AutoSize = true;
            this.lblAktBarang1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblAktBarang1.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblAktBarang1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblAktBarang1.Text = "Beras 5 kg × 50";
            this.lblAktBarang1.Name = "lblAktBarang1";
            // lblAktTgl1
            //
            this.lblAktTgl1.Location = new System.Drawing.Point(366, 58);
            this.lblAktTgl1.Size = new System.Drawing.Size(68, 20);
            this.lblAktTgl1.AutoSize = false;
            this.lblAktTgl1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblAktTgl1.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblAktTgl1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblAktTgl1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblAktTgl1.Text = "03/10";
            this.lblAktTgl1.Name = "lblAktTgl1";
            // pnlGarisAkt1
            //
            this.pnlGarisAkt1.Location = new System.Drawing.Point(18, 94);
            this.pnlGarisAkt1.Size = new System.Drawing.Size(416, 1);
            this.pnlGarisAkt1.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGarisAkt1.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGarisAkt1.Radius = 0;
            this.pnlGarisAkt1.Name = "pnlGarisAkt1";
            // lblAktJenis2
            //
            this.lblAktJenis2.Location = new System.Drawing.Point(18, 112);
            this.lblAktJenis2.Size = new System.Drawing.Size(76, 26);
            this.lblAktJenis2.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblAktJenis2.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblAktJenis2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblAktJenis2.Radius = 8;
            this.lblAktJenis2.Text = "Keluar";
            this.lblAktJenis2.Name = "lblAktJenis2";
            // lblAktBarang2
            //
            this.lblAktBarang2.Location = new System.Drawing.Point(108, 114);
            this.lblAktBarang2.AutoSize = true;
            this.lblAktBarang2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblAktBarang2.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblAktBarang2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblAktBarang2.Text = "Mi instan × 20";
            this.lblAktBarang2.Name = "lblAktBarang2";
            // lblAktTgl2
            //
            this.lblAktTgl2.Location = new System.Drawing.Point(366, 116);
            this.lblAktTgl2.Size = new System.Drawing.Size(68, 20);
            this.lblAktTgl2.AutoSize = false;
            this.lblAktTgl2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblAktTgl2.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblAktTgl2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblAktTgl2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblAktTgl2.Text = "03/10";
            this.lblAktTgl2.Name = "lblAktTgl2";
            // pnlGarisAkt2
            //
            this.pnlGarisAkt2.Location = new System.Drawing.Point(18, 152);
            this.pnlGarisAkt2.Size = new System.Drawing.Size(416, 1);
            this.pnlGarisAkt2.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGarisAkt2.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGarisAkt2.Radius = 0;
            this.pnlGarisAkt2.Name = "pnlGarisAkt2";
            // lblAktJenis3
            //
            this.lblAktJenis3.Location = new System.Drawing.Point(18, 170);
            this.lblAktJenis3.Size = new System.Drawing.Size(76, 26);
            this.lblAktJenis3.BackColor = System.Drawing.Color.FromArgb(107, 140, 255);
            this.lblAktJenis3.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblAktJenis3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblAktJenis3.Radius = 8;
            this.lblAktJenis3.Text = "Masuk";
            this.lblAktJenis3.Name = "lblAktJenis3";
            // lblAktBarang3
            //
            this.lblAktBarang3.Location = new System.Drawing.Point(108, 172);
            this.lblAktBarang3.AutoSize = true;
            this.lblAktBarang3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblAktBarang3.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblAktBarang3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblAktBarang3.Text = "Buku tulis × 100";
            this.lblAktBarang3.Name = "lblAktBarang3";
            // lblAktTgl3
            //
            this.lblAktTgl3.Location = new System.Drawing.Point(366, 174);
            this.lblAktTgl3.Size = new System.Drawing.Size(68, 20);
            this.lblAktTgl3.AutoSize = false;
            this.lblAktTgl3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblAktTgl3.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblAktTgl3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblAktTgl3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblAktTgl3.Text = "02/10";
            this.lblAktTgl3.Name = "lblAktTgl3";
            // pnlGarisAkt3
            //
            this.pnlGarisAkt3.Location = new System.Drawing.Point(18, 210);
            this.pnlGarisAkt3.Size = new System.Drawing.Size(416, 1);
            this.pnlGarisAkt3.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.pnlGarisAkt3.FillColor = System.Drawing.Color.FromArgb(36, 50, 90);
            this.pnlGarisAkt3.Radius = 0;
            this.pnlGarisAkt3.Name = "pnlGarisAkt3";
            // lblAktJenis4
            //
            this.lblAktJenis4.Location = new System.Drawing.Point(18, 228);
            this.lblAktJenis4.Size = new System.Drawing.Size(76, 26);
            this.lblAktJenis4.BackColor = System.Drawing.Color.FromArgb(255, 200, 61);
            this.lblAktJenis4.ForeColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.lblAktJenis4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblAktJenis4.Radius = 8;
            this.lblAktJenis4.Text = "Keluar";
            this.lblAktJenis4.Name = "lblAktJenis4";
            // lblAktBarang4
            //
            this.lblAktBarang4.Location = new System.Drawing.Point(108, 230);
            this.lblAktBarang4.AutoSize = true;
            this.lblAktBarang4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblAktBarang4.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.lblAktBarang4.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblAktBarang4.Text = "Air mineral × 12";
            this.lblAktBarang4.Name = "lblAktBarang4";
            // lblAktTgl4
            //
            this.lblAktTgl4.Location = new System.Drawing.Point(366, 232);
            this.lblAktTgl4.Size = new System.Drawing.Size(68, 20);
            this.lblAktTgl4.AutoSize = false;
            this.lblAktTgl4.BackColor = System.Drawing.Color.FromArgb(17, 27, 52);
            this.lblAktTgl4.ForeColor = System.Drawing.Color.FromArgb(143, 163, 214);
            this.lblAktTgl4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblAktTgl4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblAktTgl4.Text = "01/10";
            this.lblAktTgl4.Name = "lblAktTgl4";
            //
            // ucLaporanGudang
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(11, 18, 36);
            this.Size = new System.Drawing.Size(970, 720);
            this.Name = "ucLaporanGudang";
            this.Controls.Add(this.lblJudul);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.btnCetak);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.pnlTabs);
            this.Controls.Add(this.lblDari);
            this.Controls.Add(this.txtDari);
            this.Controls.Add(this.lblSampai);
            this.Controls.Add(this.txtSampai);
            this.Controls.Add(this.btnTampilkan);
            this.Controls.Add(this.pnlStat1);
            this.Controls.Add(this.pnlStat2);
            this.Controls.Add(this.pnlStat3);
            this.Controls.Add(this.pnlStat4);
            this.Controls.Add(this.pnlStokPerBarang);
            this.Controls.Add(this.pnlAktivitas);
            this.pnlTabs.ResumeLayout(false);
            this.pnlStat1.ResumeLayout(false);
            this.pnlStat2.ResumeLayout(false);
            this.pnlStat3.ResumeLayout(false);
            this.pnlStat4.ResumeLayout(false);
            this.pnlStokPerBarang.ResumeLayout(false);
            this.pnlStok1Track.ResumeLayout(false);
            this.pnlStok2Track.ResumeLayout(false);
            this.pnlStok3Track.ResumeLayout(false);
            this.pnlStok4Track.ResumeLayout(false);
            this.pnlAktivitas.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Label lblJudul;
        private System.Windows.Forms.Label lblSub;
        private SMKMart.Controls.RoundedButton btnCetak;
        private SMKMart.Controls.RoundedButton btnSimpan;
        private SMKMart.Controls.RoundedPanel pnlTabs;
        private SMKMart.Controls.RoundedButton btnTabPenjualan;
        private SMKMart.Controls.RoundedButton btnTabGudang;
        private System.Windows.Forms.Label lblDari;
        private SMKMart.Controls.RoundedTextBox txtDari;
        private System.Windows.Forms.Label lblSampai;
        private SMKMart.Controls.RoundedTextBox txtSampai;
        private SMKMart.Controls.RoundedButton btnTampilkan;
        private SMKMart.Controls.RoundedPanel pnlStat1;
        private System.Windows.Forms.Label lblStat1Judul;
        private System.Windows.Forms.Label lblStat1Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat2;
        private System.Windows.Forms.Label lblStat2Judul;
        private System.Windows.Forms.Label lblStat2Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat3;
        private System.Windows.Forms.Label lblStat3Judul;
        private System.Windows.Forms.Label lblStat3Nilai;
        private SMKMart.Controls.RoundedPanel pnlStat4;
        private System.Windows.Forms.Label lblStat4Judul;
        private System.Windows.Forms.Label lblStat4Nilai;
        private SMKMart.Controls.RoundedPanel pnlStokPerBarang;
        private System.Windows.Forms.Label lblStokJudul;
        private System.Windows.Forms.Label lblStokNama1;
        private System.Windows.Forms.Label lblStokNilai1;
        private SMKMart.Controls.RoundedPanel pnlStok1Track;
        private SMKMart.Controls.RoundedPanel pnlStok1Isi;
        private System.Windows.Forms.Label lblStokNama2;
        private System.Windows.Forms.Label lblStokNilai2;
        private SMKMart.Controls.RoundedPanel pnlStok2Track;
        private SMKMart.Controls.RoundedPanel pnlStok2Isi;
        private System.Windows.Forms.Label lblStokNama3;
        private System.Windows.Forms.Label lblStokNilai3;
        private SMKMart.Controls.RoundedPanel pnlStok3Track;
        private SMKMart.Controls.RoundedPanel pnlStok3Isi;
        private System.Windows.Forms.Label lblStokNama4;
        private System.Windows.Forms.Label lblStokNilai4;
        private SMKMart.Controls.RoundedPanel pnlStok4Track;
        private SMKMart.Controls.RoundedPanel pnlStok4Isi;
        private SMKMart.Controls.RoundedPanel pnlAktivitas;
        private System.Windows.Forms.Label lblAktivitasJudul;
        private SMKMart.Controls.RoundedLabel lblAktJenis1;
        private System.Windows.Forms.Label lblAktBarang1;
        private System.Windows.Forms.Label lblAktTgl1;
        private SMKMart.Controls.RoundedPanel pnlGarisAkt1;
        private SMKMart.Controls.RoundedLabel lblAktJenis2;
        private System.Windows.Forms.Label lblAktBarang2;
        private System.Windows.Forms.Label lblAktTgl2;
        private SMKMart.Controls.RoundedPanel pnlGarisAkt2;
        private SMKMart.Controls.RoundedLabel lblAktJenis3;
        private System.Windows.Forms.Label lblAktBarang3;
        private System.Windows.Forms.Label lblAktTgl3;
        private SMKMart.Controls.RoundedPanel pnlGarisAkt3;
        private SMKMart.Controls.RoundedLabel lblAktJenis4;
        private System.Windows.Forms.Label lblAktBarang4;
        private System.Windows.Forms.Label lblAktTgl4;
    }
}
